# Evaluation evidence

The original six CSV/YAML files are preserved. They are supplied results, not results reproduced by this update. No labelled dataset or original evaluation code was included.

The supplied external evaluation reports recall of about 19.5% and mAP50 of about 9.9% on tire/water-tank classes. Tire recall is zero in its per-class table. The repeated per-class mAP50-95 values should be checked against the original export. No accuracy improvement is claimed by this application update.

`training_data.yaml` points to a Kaggle path that does not exist on a local Windows installation. It is training metadata, not the app configuration.

To repeat evaluation, provide a local labelled YOLO dataset, adjust its dataset YAML paths, and preserve the model's class IDs:

```
0: cocunut_shell
1: drum
2: other_containers
3: tire
4: water_tank
```

From the app folder after setup:

```powershell
$mwPython = .\run.bat --print-python
& $mwPython evaluation\run_evaluation.py --data (Read-Host "Path to an existing labelled YOLO dataset YAML") --split test --device cpu
```

The script refuses dataset download scripts and mismatched classes, creates a separate evaluation run under `.local/evaluation`, and exports per-class metrics plus model/dataset hashes, versions, device, and aggregate metrics. It does not train or overwrite weights. It has been syntax-checked, but cannot be run without the missing labelled dataset. Labels from external datasets must be mapped consistently before using it.

The original speed CSV contains GPU measurements. It does not predict CPU performance on another computer. Risk-rule calibration, image-quality cutoffs, overlapping-view counting, and field verification need their own validation; object-detection metrics alone do not validate inspection priorities.
