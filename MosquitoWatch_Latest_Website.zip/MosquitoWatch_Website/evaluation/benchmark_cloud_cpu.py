"""CPU hosting preflight; synthetic image tests speed/resources, not accuracy."""
from pathlib import Path
import hashlib
import json
import platform
import statistics
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT
sys.path.insert(0, str(APP))
import psutil

process = psutil.Process()
peak = [process.memory_info().rss]
finished = threading.Event()


def sample():
    while not finished.wait(.02):
        peak[0] = max(peak[0], process.memory_info().rss)


thread = threading.Thread(target=sample, daemon=True)
thread.start()
try:
    started = time.perf_counter()
    import numpy as np
    from PIL import Image
    import torch
    torch.set_num_threads(2)
    from services.detector import load_model, detect_image
    model_path = APP / 'model/mosquitowatch_yolo26s_best.pt'
    before = hashlib.sha256(model_path.read_bytes()).hexdigest()
    model = load_model(model_path).to('cpu')
    load_seconds = time.perf_counter() - started
    image = Image.fromarray(np.random.default_rng(42).integers(0, 256, (960, 1280, 3), dtype=np.uint8))
    timings = []
    for index in range(5):
        started = time.perf_counter()
        detect_image(model, image)
        timings.append(time.perf_counter() - started)
    peak[0] = max(peak[0], process.memory_info().rss)
    assert hashlib.sha256(model_path.read_bytes()).hexdigest() == before
    report = {
        'platform': platform.platform(), 'python': platform.python_version(),
        'device': 'cpu', 'torch_threads': 2, 'inference_image_size': 1024,
        'input': 'Synthetic seeded noise, 1280 x 960; no accuracy assessment.',
        'load_seconds_including_imports': round(load_seconds, 3),
        'first_inference_seconds': round(timings[0], 3),
        'warm_inference_seconds': [round(t, 3) for t in timings[1:]],
        'median_warm_inference_seconds': round(statistics.median(timings[1:]), 3),
        'sampled_peak_process_rss_mib': round(peak[0] / 1024**2, 1),
        'model_sha256': before, 'weights_unchanged': True,
        'limitations': 'Local Windows CPU preflight. Excludes Streamlit, network, concurrent sessions and large upload batches. Linux cloud performance must be measured separately.'
    }
    output = ROOT / 'evaluation/cloud_cpu_preflight.json'
    output.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
finally:
    finished.set()
    thread.join()
