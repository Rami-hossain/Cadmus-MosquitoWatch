"""Re-run object detection evaluation on a user-supplied labelled dataset.

No training, export, or changes to the supplied model weights.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path, help="Existing local YOLO dataset YAML; class IDs must match the model.")
    parser.add_argument("--split", default="test", choices=("train", "val", "test"))
    parser.add_argument("--device", default="cpu", help="cpu, or a CUDA device such as 0")
    args = parser.parse_args()
    data_path = args.data.resolve(strict=True)
    import yaml
    from services.detector import DISPLAY_NAMES, load_model

    dataset = yaml.safe_load(data_path.read_text(encoding="utf-8"))
    if not isinstance(dataset, dict) or "download" in dataset:
        raise ValueError("Use a local dataset YAML without a download script.")
    names = dataset.get("names", {})
    names = dict(enumerate(names)) if isinstance(names, list) else {int(k): v for k, v in names.items()}
    expected = dict(enumerate(DISPLAY_NAMES))
    if names != expected:
        raise ValueError("Dataset class IDs/names must match all five model classes. Map external labels before evaluation.")
    model_path = ROOT / "model/mosquitowatch_yolo26s_best.pt"
    before = hashlib.sha256(model_path.read_bytes()).hexdigest()
    metrics = load_model(model_path).val(data=str(data_path), split=args.split, device=args.device,
                                         imgsz=1024, batch=1, workers=0, plots=False, save_json=True,
                                         project=str(ROOT / ".local/evaluation"), name="evaluation", exist_ok=False)
    rows = metrics.summary(decimals=8)
    destination = Path(metrics.save_dir)
    if rows:
        with (destination / "per_class.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    metadata = {"dataset": str(data_path), "dataset_yaml_sha256": hashlib.sha256(data_path.read_bytes()).hexdigest(),
                "split": args.split, "device": args.device, "image_size": 1024, "batch": 1,
                "model_sha256": before, "python": platform.python_version(), "platform": platform.platform(),
                "packages": {name: importlib.metadata.version(name) for name in ("ultralytics", "torch", "torchvision", "numpy")},
                "aggregate_metrics": {k: float(v) for k, v in metrics.results_dict.items()}}
    (destination / "evaluation_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    if hashlib.sha256(model_path.read_bytes()).hexdigest() != before:
        raise RuntimeError("Model integrity changed unexpectedly.")
    print(f"Evaluation saved to {destination}. Model weights are unchanged.")


if __name__ == "__main__":
    main()
