# MosquitoWatch AI

A Streamlit prototype for reporting potential Aedes breeding-risk objects in
drone images from Bangladesh. YOLO detects coconut shells, drums, other
containers, tires and water tanks. It does not directly detect mosquitoes,
larvae, standing water or dengue.

The public panel accepts photos and a site location, combines object counts
with previous 72-hour weather, and provides inspection priority and Bangla
recommendations. A private tracking code opens report history and follow-up
surveys. The admin panel supports site review, comments, priority decisions,
workflow updates and deletion.

## Cloud deployment

Deploy **cloud_app.py** with Python 3.13 on Streamlit Community Cloud.
Read [deploy/README.md](deploy/README.md) for Supabase schema, private Storage,
deployment secrets, live verification and backup steps. Docker is optional.
Root requirements select locked Linux CPU dependencies.

No real reports, uploaded photos or credentials belong in this repository.
The supplied model is unchanged; its checksum is recorded in SHA256SUMS.txt.
The original Windows release and its run.bat remain in the separate local
project folder. Windows installer files are intentionally absent here.

## Verification

The cloud application has 95 local regression checks, including report access,
private storage handling and original-model integrity. The dependency audit
found zero known vulnerabilities in the locked package set when checked.
GitHub Actions runs Linux CPU installation, tests and an inference benchmark.
Before opening public access, verify actual Supabase connectivity, report/photo
persistence across app restarts, admin authentication and object deletion.

The detector was trained on drone imagery; phone-photo accuracy needs separate
evaluation. Risk logic is a prototype and requires field verification.
Free hosting and storage quotas apply.
