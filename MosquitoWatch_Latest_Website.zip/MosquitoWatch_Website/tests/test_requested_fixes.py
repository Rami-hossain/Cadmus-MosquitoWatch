import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from services.location import reverse_location, clear_reverse_cache
from services.store import ReportStore


class PlaceNameTests(unittest.TestCase):
    def setUp(self):
        clear_reverse_cache()

    def test_area_name_keeps_exact_pin_separate_and_caches_requests(self):
        response={"features":[{"properties":{"name":"Uttara", "city":"Dhaka", "country":"Bangladesh", "countrycode":"BD"}}]}
        with patch("services.location.get_json",return_value=response) as request:
            self.assertEqual(reverse_location(23.87591,90.37951),"Uttara, Dhaka, Bangladesh")
            self.assertEqual(reverse_location(23.87592,90.37952),"Uttara, Dhaka, Bangladesh")
            self.assertEqual(request.call_count,1)
            self.assertEqual(request.call_args.args[1]["lat"],23.876)

    def test_non_bangladesh_or_missing_names_are_not_invented(self):
        with patch("services.location.get_json",return_value={"features":[{"properties":{"name":"Elsewhere","countrycode":"IN"}}]}), self.assertRaises(ValueError):
            reverse_location(23.8,90.4)


class AdminCodeTests(unittest.TestCase):
    def test_code_and_password_are_both_required_and_stored_as_hashes(self):
        with tempfile.TemporaryDirectory() as folder:
            store=ReportStore(Path(folder))
            store.set_local_admin("test-access-88","test-passphrase-789")
            self.assertIsNone(store.login("test-passphrase-789","wrong-code"))
            self.assertIsNone(store.login("test-passphrase-789"))
            self.assertTrue(store.login("test-passphrase-789","test-access-88"))
            raw=store.path.read_bytes()
            self.assertNotIn(b"test-access-88",raw)
            self.assertNotIn(b"test-passphrase-789",raw)

    def test_short_password_requires_explicit_local_demo_override(self):
        with tempfile.TemporaryDirectory() as folder:
            store=ReportStore(Path(folder))
            with self.assertRaises(ValueError):
                store.set_local_admin("test-code","short")
            store.set_local_admin("test-code","short",allow_short_password=True)
            token=store.login("short","test-code")
            self.assertTrue(token)
            store.set_local_admin("next-code","another-long-password")
            with self.assertRaises(PermissionError):
                store.sites(token)
