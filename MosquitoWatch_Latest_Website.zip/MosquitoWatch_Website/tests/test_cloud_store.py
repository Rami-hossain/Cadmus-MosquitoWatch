"""Cloud adapter tests; live database/storage checks are a separate deployment gate."""
from contextlib import contextmanager
import ast
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import unittest
from unittest.mock import Mock, patch

from services.cloud_store import CloudReportStore, Database, PrivatePayloads, Row, postgres_sql, MAX_PAYLOAD, startup_diagnostic
from services.store import ReportStore, encode

ROOT = Path(__file__).resolve().parents[1]


class Response:
    ok = True
    def __init__(self, data):
        self.data = data
    def __enter__(self):
        return self
    def __exit__(self, *args):
        pass
    def iter_content(self, size):
        return iter([self.data])
    def close(self):
        pass


class CloudAdapterTests(unittest.TestCase):
    def test_database_tls_uses_bundled_supabase_ca_and_verifies_hostname(self):
        store = CloudReportStore.__new__(CloudReportStore)
        store.connection_values = {}
        with patch('psycopg.connect') as connect:
            with store.raw_connection():
                pass
        options = connect.call_args.kwargs
        self.assertEqual(options['sslmode'], 'verify-full')
        self.assertNotIn('options', options)
        connection = connect.return_value.__enter__.return_value
        self.assertEqual(connection.execute.call_args_list[0].args,
                         ('SET LOCAL search_path TO mosquitowatch, pg_catalog',))
        certificate = Path(options['sslrootcert'])
        self.assertEqual(certificate, ROOT/'deploy/supabase-ca.crt')
        import ssl
        ssl.PEM_cert_to_DER_cert(certificate.read_text())

    def test_startup_diagnostics_never_echo_secrets(self):
        private = 'sensitive-test-only-value'
        for error, expected in (
            (RuntimeError('certificate verify failed '+private), 'database_tls_certificate'),
            (RuntimeError('password authentication failed '+private), 'database_password'),
            (KeyError(private), 'missing_deployment_setting'),
            (RuntimeError(private), 'storage_initialization'),
        ):
            self.assertEqual(startup_diagnostic(error), expected)
            self.assertNotIn(private, startup_diagnostic(error))

    def test_original_model_integrity(self):
        digest = hashlib.sha256((ROOT/'model/mosquitowatch_yolo26s_best.pt').read_bytes()).hexdigest()
        self.assertEqual(digest, '9cab40066fcc48411555fb146873a26c269cdf436f7eb52c6b759c2823a6b91c')

    def payloads(self):
        return PrivatePayloads('https://sztwamikbzttyizpnehl.supabase.co', 'sb_secret_test_only_' + 'x'*50)

    def test_modern_secret_is_not_sent_as_a_jwt(self):
        self.assertNotIn('Authorization', self.payloads().headers)
        self.assertTrue(self.payloads().headers['apikey'].startswith('sb_secret_'))
        with self.assertRaises(ValueError):
            PrivatePayloads('https://sztwamikbzttyizpnehl.supabase.co', 'sb_publishable_'+'x'*50)

    def test_separate_database_password_preserves_special_characters(self):
        class ConnectionProbe(CloudReportStore):
            @contextmanager
            def raw_connection(self):
                yield Mock()
            def configured(self):
                return True
            def cleanup(self):
                pass
        password = 'test-only@password:#%with-symbols'
        store = ConnectionProbe({'database_url': 'postgresql://postgres.sztwamikbzttyizpnehl@aws-0-ap-southeast-2.pooler.supabase.com:5432/postgres',
                                 'database_password': password, 'url': 'https://sztwamikbzttyizpnehl.supabase.co',
                                 'secret_key': 'sb_secret_test_only_'+'x'*50})
        self.assertEqual(store.connection_values['password'], password)
        self.assertEqual(store.connection_values['user'], 'postgres.sztwamikbzttyizpnehl')

    def test_rejects_foreign_origin_redirect_and_arbitrary_object_path(self):
        for url in ('http://example.org', 'https://supabase.co.evil.org', 'https://user@x.supabase.co', 'https://x.supabase.co/?key=x'):
            with self.assertRaises(ValueError):
                PrivatePayloads(url, 'x'*50)
        for path in ('../../private', 'https://example.org/a', 'reports/a/b.json.gz'):
            with self.assertRaises(ValueError):
                self.payloads().download(path)
        with patch('services.cloud_store.requests.request', return_value=Response(b'')) as request:
            self.payloads()._request('GET', 'object/test')
            self.assertFalse(request.call_args.kwargs['allow_redirects'])

    def test_private_payload_round_trip_preserves_image_bytes(self):
        report = {'images': [{'original_png': b'original', 'annotated_png': b'annotation'}], 'counts': {'drum': 1}}
        raw = json.dumps(report, default=encode).encode()
        path = 'reports/' + 'a'*24 + '/' + hashlib.sha256(raw).hexdigest() + '.json.gz'
        with patch.object(PrivatePayloads, '_request', return_value=Response(gzip.compress(raw))):
            self.assertEqual(self.payloads().download(path), report)

    def test_rejects_tampered_payload_and_decompression_bomb(self):
        path = 'reports/' + 'a'*24 + '/' + 'b'*64 + '.json.gz'
        with patch.object(PrivatePayloads, '_request', return_value=Response(gzip.compress(b'{}'))):
            with self.assertRaisesRegex(ValueError, 'integrity'):
                self.payloads().download(path)
        with patch('services.cloud_store.MAX_PAYLOAD', 32), patch.object(PrivatePayloads, '_request', return_value=Response(gzip.compress(b'x'*33))):
            with self.assertRaisesRegex(ValueError, 'size'):
                self.payloads().download(path)

    def test_connection_errors_do_not_expose_credentials(self):
        import requests
        with patch('services.cloud_store.requests.request', side_effect=requests.ConnectionError('secret-value')):
            with self.assertRaises(RuntimeError) as caught:
                self.payloads()._request('GET', 'object/test')
            self.assertNotIn('secret-value', str(caught.exception))

    def test_row_preserves_shared_store_access_patterns(self):
        row = Row(expires='tomorrow', token='hashed')
        self.assertEqual(row[0], row['expires'])
        self.assertEqual(dict(row), {'expires': 'tomorrow', 'token': 'hashed'})

    def test_all_shared_sql_parses_as_postgres(self):
        from pglast import parse_sql
        parse_sql((ROOT/'deploy/schema.sql').read_text())
        tree = ast.parse((ROOT/'services/store.py').read_text())
        count = 0
        shared_methods = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
                          and node.name not in {'__init__', 'connection', 'setup_admin', 'set_local_admin'}]
        calls = [call for method in shared_methods for call in ast.walk(method)]
        for call in calls:
            if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == 'execute' and call.args and isinstance(call.args[0], ast.Constant):
                query = call.args[0].value
                if isinstance(query, str):
                    parse_sql(postgres_sql(query).replace('%s', 'NULL'))
                    count += 1
        for columns in ('*', "id,site_id,observed_at,submitted_at,water,notes,json_remove(result,'$.images') AS result"):
            parse_sql(postgres_sql(f'SELECT {columns} FROM observations WHERE site_id=? ORDER BY observed_at,submitted_at').replace('%s', 'NULL'))
        self.assertGreater(count, 30)

    def test_cloud_store_inherits_auth_validation_and_atomic_updates(self):
        for method in ('login', 'authorize', 'submit', 'update_site', 'delete_site', 'case', 'admin_case'):
            self.assertIs(getattr(CloudReportStore, method), getattr(ReportStore, method))
        self.assertIn('pg_advisory_xact_lock', postgres_sql('BEGIN IMMEDIATE'))
        self.assertIn('ON CONFLICT (key)', postgres_sql("INSERT OR REPLACE INTO config VALUES ('failures', ?)"))

    def test_reserved_upload_precedes_storage_and_metadata_commit(self):
        events = []
        reservation = Mock()
        reservation.execute.side_effect = lambda *args: events.append('reserve')
        @contextmanager
        def connect():
            yield reservation
        store = Mock()
        store.raw_connection = connect
        store.payloads.upload.side_effect = lambda *args: events.append('upload')
        database = Mock()
        database.execute.side_effect = lambda *args: events.append('write') or Mock()
        raw = json.dumps({'images': [{'original_png': b'png'}], 'counts': {'drum': 1}}, default=encode)
        Database(store, database).execute('INSERT INTO observations VALUES (?,?,?,?,?,?,?,?)', ('a'*24, 'site', 'date', 'date', 'Unsure', '', raw, 'idempotency'))
        self.assertEqual(events, ['reserve', 'upload', 'write', 'write'])
        metadata = json.loads(database.execute.call_args_list[0].args[1][6])
        self.assertNotIn('images', metadata)
        self.assertTrue(metadata['_cloud_payload'].startswith('reports/'))

    def test_failed_upload_does_not_insert_observation(self):
        store = Mock()
        @contextmanager
        def connect():
            yield Mock()
        store.raw_connection = connect
        store.payloads.upload.side_effect = RuntimeError('storage offline')
        database = Mock()
        with self.assertRaises(RuntimeError):
            Database(store, database).execute('INSERT INTO observations VALUES (?,?,?,?,?,?,?,?)', ('a'*24, 'site', 'date', 'date', 'Unsure', '', '{}', 'key'))
        database.execute.assert_not_called()

    def test_summary_does_not_download_photos(self):
        store = object.__new__(CloudReportStore)
        store.payloads = Mock()
        case = {'observations': [{'result': {'_cloud_payload': 'opaque-reference'}}]}
        with patch.object(ReportStore, '_case', return_value=case):
            store._case(None, None, include_images=False)
            store.payloads.download.assert_not_called()
            store._case(None, None, include_images=True)
            store.payloads.download.assert_called_once_with('opaque-reference')

    def test_deleted_site_queues_photos_before_cascade(self):
        db = Mock()
        wrapper = Database(Mock(), db)
        wrapper.execute('DELETE FROM sites WHERE id=?', ('selected-site',))
        self.assertTrue(wrapper.deleted)
        self.assertIn('cleanup_after', db.execute.call_args_list[0].args[0])
        self.assertEqual(db.execute.call_args_list[1].args[1], ('selected-site',))

    def test_cloud_entrypoint_requires_cloud_storage_and_no_secrets_are_bundled(self):
        text = (ROOT/'cloud_app.py').read_text()
        self.assertIn("os.environ['MOSQUITOWATCH_STORAGE'] = 'supabase'", text)
        self.assertFalse((ROOT/'.streamlit/secrets.toml').exists())
        schema = (ROOT/'deploy/schema.sql').read_text()
        self.assertEqual(schema.count('ENABLE ROW LEVEL SECURITY'), 7)
        self.assertIn("'mosquitowatch-private', 'mosquitowatch-private', false", schema)

    def test_cloud_connection_failure_never_opens_sqlite(self):
        from streamlit.testing.v1 import AppTest
        at = AppTest.from_file(str(ROOT/'cloud_app.py'), default_timeout=30)
        at.secrets['supabase'] = {'database_url': '', 'url': '', 'service_role_key': ''}
        with patch.dict(os.environ, {}, clear=False), patch('services.cloud_store.CloudReportStore', side_effect=RuntimeError('test outage')) as cloud, patch('services.store.ReportStore') as local:
            at.run()
            cloud.assert_called_once()
            local.assert_not_called()
        self.assertFalse(at.exception)
        self.assertTrue(any('Report storage is unavailable' in item.value for item in at.error))


if __name__ == '__main__':
    unittest.main()
