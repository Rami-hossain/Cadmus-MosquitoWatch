from __future__ import annotations

import copy
import io
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import numpy as np
from PIL import Image, PngImagePlugin

from reports.bangla_report import build_bangla_report
from reports.export import build_text_report
from risk.risk_engine import calculate_risk, classify_risk
from services.analysis import SurveyImage, analyze_images, open_survey_image, input_signature
from services.location import LocationUnavailable, find_locations, geocode_location
from services.weather import WeatherUnavailable, fetch_previous_72h_weather

NOW = datetime(2026, 10, 16, 13, 37, tzinfo=timezone.utc)
WEATHER = {"hours": 72, "coverage_complete": True, "avg_temperature_c": 28., "avg_humidity_percent": 85., "total_rainfall_mm": 35.,
           "start_time": "2026-10-13T19:00:00+06:00", "end_time": "2026-10-16T19:00:00+06:00"}


def weather_payload():
    start = NOW.replace(minute=0) - timedelta(hours=72)
    return {"hourly": {"time": [int((start + timedelta(hours=i + 1)).timestamp()) for i in range(72)],
                       "temperature_2m": [28.] * 72, "relative_humidity_2m": [85.] * 72, "precipitation": [1.] * 72}}


def image_bytes(*, flat=False, metadata=False):
    image = Image.new("RGB", (640, 640), (120, 120, 120)) if flat else Image.fromarray(np.random.default_rng(4).integers(40, 210, (640, 640, 3), dtype=np.uint8))
    output = io.BytesIO()
    info = PngImagePlugin.PngInfo()
    if metadata:
        info.add_text("description", "Same pixels, different encoding")
    image.save(output, format="PNG", pnginfo=info)
    return output.getvalue()


def fake_detect(model, image):
    return {"counts": {"tire": 2}, "annotated_rgb": np.asarray(image), "quality": {"usable": True}}


def place(identifier=1, name="Mirpur", district="Dhaka District", country="BD", lat=23.8, lon=90.36):
    return {"id": identifier, "name": name, "admin2": district, "admin1": "Dhaka Division", "country_code": country, "latitude": lat, "longitude": lon}


class WeatherTests(unittest.TestCase):
    def fetch(self, payload):
        with patch("services.weather.get_json", return_value=payload):
            return fetch_previous_72h_weather(23.7, 90.4, now=NOW)

    def test_complete_window_and_timezone(self):
        result = self.fetch(weather_payload())
        self.assertEqual(result["hours"], 72)
        self.assertEqual(result["total_rainfall_mm"], 72.)
        self.assertEqual(result["start_time"], "2026-10-13T19:00:00+06:00")
        self.assertEqual(result["last_sample_time"], "2026-10-16T19:00:00+06:00")

    def test_rainfall_uses_hour_closing_timestamps(self):
        data = weather_payload()
        data["hourly"]["precipitation"][-1] = 7
        data["hourly"]["time"].insert(0, int((NOW.replace(minute=0) - timedelta(hours=72)).timestamp()))
        data["hourly"]["temperature_2m"].insert(0, 28)
        data["hourly"]["relative_humidity_2m"].insert(0, 85)
        data["hourly"]["precipitation"].insert(0, 999)
        # Exclude the interval before the window, include the latest completed one.
        self.assertEqual(self.fetch(data)["total_rainfall_mm"], 78)

    def test_missing_hour_rejected(self):
        data = weather_payload()
        for values in data["hourly"].values():
            values.pop(12)
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_single_hour_rejected(self):
        data = weather_payload()
        data["hourly"] = {key: values[:1] for key, values in data["hourly"].items()}
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_mismatched_arrays_rejected(self):
        data = weather_payload(); data["hourly"]["precipitation"].pop()
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_duplicate_hour_rejected(self):
        data = weather_payload(); data["hourly"]["time"][1] = data["hourly"]["time"][0]
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_stale_window_rejected(self):
        data = weather_payload(); data["hourly"]["time"] = [t - 3600 for t in data["hourly"]["time"]]
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_invalid_values_rejected(self):
        for key, invalid in (("temperature_2m", None), ("temperature_2m", float("nan")), ("relative_humidity_2m", 101), ("precipitation", -1)):
            with self.subTest(key=key, invalid=invalid):
                data = weather_payload(); data["hourly"][key][3] = invalid
                with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_future_hour_does_not_replace_missing_hour(self):
        data = weather_payload(); data["hourly"]["time"][0] = int((NOW.replace(minute=0) + timedelta(hours=1)).timestamp())
        with self.assertRaises(WeatherUnavailable): self.fetch(data)

    def test_extra_future_hour_ignored(self):
        data = weather_payload()
        data["hourly"]["time"].append(int((NOW.replace(minute=0) + timedelta(hours=1)).timestamp()))
        for key in ("temperature_2m", "relative_humidity_2m", "precipitation"):
            data["hourly"][key].append(9999)
        self.assertEqual(self.fetch(data)["total_rainfall_mm"], 72.)

    def test_invalid_coordinates_rejected_without_network(self):
        with patch("services.weather.get_json") as network:
            with self.assertRaises(WeatherUnavailable): fetch_previous_72h_weather(float("nan"), 90, now=NOW)
            network.assert_not_called()


class LocationTests(unittest.TestCase):
    def find(self, items, query="Mirpur"):
        with patch("services.location.get_json", return_value={"results": items}) as network:
            result = find_locations(query)
            self.assertEqual(network.call_args.args[1]["countryCode"], "BD")
            return result

    def test_foreign_result_rejected(self):
        with self.assertRaises(LocationUnavailable): self.find([place(country="GB")])

    def test_impossible_coordinates_rejected(self):
        with self.assertRaises(LocationUnavailable): self.find([place(lat=51)])

    def test_exact_name_avoids_fuzzy_fallback(self):
        result = self.find([place(name="Dhaka"), place(2, name="Dhakail")], "Dhaka, Bangladesh")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["name"], "Dhaka")

    def test_district_qualifier_preferred(self):
        result = self.find([place(), place(2, district="Gazipur District")], "Mirpur, Dhaka")
        self.assertEqual(result[0]["district"], "Dhaka District")
        self.assertEqual(len(result), 1)

    def test_ambiguous_places_remain_choices(self):
        self.assertEqual(len(self.find([place(), place(2, district="Gazipur District")])), 2)

    def test_ambiguity_not_silently_selected(self):
        with patch("services.location.find_locations", return_value=[place(), place(2)]):
            with self.assertRaises(LocationUnavailable): geocode_location("Mirpur")

    def test_blank_location(self):
        with self.assertRaises(LocationUnavailable): find_locations(" ")


class RiskTests(unittest.TestCase):
    def test_priority_thresholds(self):
        for score, expected in ((0, "LOW"), (34, "LOW"), (35, "MEDIUM"), (64, "MEDIUM"), (65, "HIGH"), (100, "HIGH")):
            self.assertEqual(classify_risk(score)[0], expected)

    def test_weather_alone_never_high_and_explained(self):
        result = calculate_risk({}, WEATHER)
        self.assertEqual(result["risk_level"], "MEDIUM")
        bn = build_bangla_report({}, WEATHER, result)
        self.assertTrue(any("আবহাওয়ার কারণে" in reason for reason in bn["reasons"]))

    def test_missing_weather_withholds_priority(self):
        result = calculate_risk({"tire": 8}, {})
        self.assertEqual(result["status"], "UNABLE_TO_ASSESS")
        self.assertEqual(result["cause"], "weather")

    def test_incomplete_weather_withholds_priority(self):
        weather = dict(WEATHER, hours=71)
        self.assertEqual(calculate_risk({}, weather)["status"], "UNABLE_TO_ASSESS")

    def test_all_unusable_withholds_priority(self):
        result = calculate_risk({"tire": 10}, WEATHER, all_images_unusable=True)
        self.assertEqual(result["cause"], "images")

    def test_invalid_counts_rejected(self):
        for counts in ({"tire": -1}, {"tire": 1.5}, {"larvae": 1}, {"drum": True}):
            with self.subTest(counts=counts):
                with self.assertRaises(ValueError): calculate_risk(counts, WEATHER)

    def test_high_requires_visual_evidence(self):
        result = calculate_risk({"tire": 3, "drum": 3, "water_tank": 3}, WEATHER)
        self.assertEqual(result["risk_level"], "HIGH")
        self.assertLessEqual(result["total_score"], 100)


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.good = image_bytes()

    @patch("services.analysis.detect_image", side_effect=fake_detect)
    def test_corrupt_image_does_not_abort_batch(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good), SurveyImage("bad.jpg", b"broken")], object(), WEATHER)
        self.assertEqual(result["counts"]["tire"], 2)
        self.assertEqual(result["usable_images"], 1)
        self.assertEqual(result["images"][1]["status"], "failed")
        self.assertTrue(result["partial_coverage"])

    @patch("services.analysis.detect_image", side_effect=fake_detect)
    def test_poor_quality_does_not_contribute(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good), SurveyImage("blur.png", image_bytes(flat=True))], object(), WEATHER)
        self.assertEqual(result["counts"]["tire"], 2)
        self.assertEqual(result["images"][1]["status"], "excluded")
        self.assertEqual(detect.call_count, 1)

    @patch("services.analysis.detect_image", side_effect=fake_detect)
    def test_duplicate_pixels_with_different_metadata_count_once(self, detect):
        result = analyze_images([SurveyImage("a.png", self.good), SurveyImage("b.png", image_bytes(metadata=True))], object(), WEATHER)
        self.assertEqual(result["counts"]["tire"], 2)
        self.assertEqual(result["duplicate_images"], 1)
        self.assertFalse(result["partial_coverage"])
        self.assertEqual(detect.call_count, 1)

    @patch("services.analysis.detect_image", side_effect=fake_detect)
    def test_weather_failure_keeps_images_without_priority(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good)], object(), None)
        self.assertEqual(result["counts"]["tire"], 2)
        self.assertEqual(result["risk"]["status"], "UNABLE_TO_ASSESS")
        self.assertTrue(result["images"][0]["annotated_png"])

    @patch("services.analysis.detect_image", side_effect=RuntimeError("inference failed"))
    def test_inference_failure_has_no_low_priority(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good)], object(), WEATHER)
        self.assertEqual(result["risk"]["status"], "UNABLE_TO_ASSESS")
        self.assertEqual(result["images"][0]["status"], "failed")

    @patch("services.analysis.detect_image", return_value={"counts": {"tire": 20}, "annotated_rgb": None})
    def test_failed_annotation_does_not_contribute_counts(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good)], object(), WEATHER)
        self.assertEqual(result["counts"]["tire"], 0)
        self.assertEqual(result["usable_images"], 0)
        self.assertEqual(result["risk"]["status"], "UNABLE_TO_ASSESS")

    def test_too_many_images_not_silently_truncated(self):
        with self.assertRaises(ValueError): analyze_images([SurveyImage("a", b"x")] * 11, object(), WEATHER)

    def test_batch_size_limit(self):
        with patch("services.analysis.MAX_BATCH_BYTES", 5):
            with self.assertRaises(ValueError): analyze_images([SurveyImage("a", b"123456")], object(), WEATHER)

    def test_file_size_limit(self):
        with patch("services.analysis.MAX_FILE_BYTES", 5):
            with self.assertRaises(ValueError): open_survey_image(self.good)

    def test_disguised_gif_rejected(self):
        output = io.BytesIO(); Image.new("RGB", (640,640)).save(output, format="GIF")
        with self.assertRaises(ValueError): open_survey_image(output.getvalue())

    def test_exif_orientation_applied(self):
        source = Image.new("RGB", (400, 600)); exif = source.getexif(); exif[274] = 6
        output = io.BytesIO(); source.save(output, format="JPEG", exif=exif)
        self.assertEqual(open_survey_image(output.getvalue()).size, (600, 400))

    def test_signature_changes_with_inputs(self):
        inputs = [SurveyImage("a.png", self.good)]
        self.assertNotEqual(input_signature(inputs, "Dhaka"), input_signature(inputs, "Banani"))
        self.assertEqual(input_signature(inputs, " Dhaka "), input_signature(inputs, "dhaka"))

    @patch("services.analysis.detect_image", side_effect=fake_detect)
    def test_download_report_has_bangla_without_internal_settings(self, detect):
        result = analyze_images([SurveyImage("good.png", self.good)], object(), WEATHER)
        result["location"] = {"display_name": "Banani, Dhaka, Bangladesh", "latitude": 23.79142, "longitude": 90.40491}
        text = build_text_report(result)
        self.assertIn("করণীয়", text)
        self.assertIn("field", text.lower())
        for hidden in ("23.79142", "90.40491", "visual_score", "total_score", "confidence", "NMS"):
            self.assertNotIn(hidden, text)


if __name__ == "__main__":
    unittest.main()
