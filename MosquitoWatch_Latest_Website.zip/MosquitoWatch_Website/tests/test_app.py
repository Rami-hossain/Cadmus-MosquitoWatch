"""Streamlit state and public-interface regression checks (no model/network)."""
from pathlib import Path
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from services.analysis import SurveyImage, analyze_images, input_signature
from tests.test_core import WEATHER, fake_detect, image_bytes

ROOT = Path(__file__).resolve().parents[1]


class AppTests(unittest.TestCase):
    def start(self):
        return AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()

    def seed_result(self, at, weather=WEATHER):
        with patch("services.analysis.detect_image", side_effect=fake_detect):
            result = analyze_images([SurveyImage("test.png", image_bytes())], object(), weather)
        result.update(location={"display_name": "Dhaka, Bangladesh", "latitude": 23.7104, "longitude": 90.40744},
                      signature=input_signature([], "Dhaka, Bangladesh"))
        at.session_state["survey_area"] = "Dhaka, Bangladesh"
        at.session_state["analysis"] = result
        return at.run()

    def test_initial_screen_and_no_image_validation(self):
        at = self.start()
        self.assertFalse(at.exception)
        at.button(key="analyze_area").click().run()
        self.assertFalse(at.exception)
        self.assertTrue(any("Upload at least one" in warning.value for warning in at.warning))

    def test_saved_result_survives_reruns(self):
        at = self.seed_result(self.start())
        self.assertFalse(at.exception)
        at.run()
        self.assertFalse(at.exception)
        self.assertTrue(any("Survey results" == title.value for title in at.header))
        self.assertTrue(any("inspection priority" in block.value for block in at.markdown))
        tables = [block.value for block in at.markdown if 'class="mw-summary-table"' in block.value]
        self.assertEqual(len(tables),2)
        self.assertIn('aria-label="Detected objects"',tables[0])
        self.assertIn('aria-label="Survey-date weather"',tables[1])
        self.assertIn('Average humidity',tables[1])
        self.assertIn('Period starts',tables[1])

    def test_changed_location_marks_previous_report(self):
        at = self.seed_result(self.start())
        at.text_input(key="survey_area").set_value("Banani, Dhaka").run()
        self.assertFalse(at.exception)
        self.assertTrue(any("previous report" in warning.value for warning in at.warning))
        self.assertIn("analysis", at.session_state)

    def test_missing_weather_does_not_hide_detections(self):
        at = self.seed_result(self.start(), weather=None)
        self.assertFalse(at.exception)
        text = " ".join(block.value for block in at.markdown)
        self.assertIn("Unable to assign", text)
        self.assertTrue(any("Detected objects" == h.value for h in at.subheader))
        self.assertTrue(any("No priority has been assigned" in w.value for w in at.warning))
        weather_table=next(block.value for block in at.markdown if 'aria-label="Survey-date weather"' in block.value)
        self.assertEqual(weather_table.count('Unavailable'),5)

    def test_public_output_hides_settings_and_coordinates(self):
        at = self.seed_result(self.start())
        text = " ".join(block.value for block in at.markdown)
        for forbidden in ("23.7104", "90.40744", "visual_score", "total_score", "NMS IoU", "Environmental risk score"):
            self.assertNotIn(forbidden, text)
        self.assertFalse(at.slider)
        self.assertFalse(at.number_input)
        self.assertFalse(at.exception)

    def test_html_location_and_filename_are_not_executed(self):
        at = self.seed_result(self.start())
        result = at.session_state["analysis"]
        result["images"][0]["name"] = '<script>alert("x")</script>.png'
        at.run()
        text = " ".join(block.value for block in at.markdown)
        self.assertNotIn('<script>alert("x")</script>', text)
        self.assertIn("&lt;script&gt;", text)
        self.assertFalse(at.exception)


if __name__ == "__main__":
    unittest.main()
