from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile
import unittest

from services.history import followup_priority
from services.store import ReportStore

NOW = datetime.now(timezone.utc).replace(microsecond=0)


def observation(days, water="Water present", level="LOW", fingerprint=None):
    return {"observed_at": (NOW - timedelta(days=days)).isoformat(), "water": water,
            "result": {"risk": {"status": "OK", "risk_level": level},
                       "fingerprints": [fingerprint or str(days)]}}


class HistoryTests(unittest.TestCase):
    def test_three_days_raises_one_level_without_changing_base(self):
        rows = [observation(4), observation(0)]
        result = followup_priority(rows)
        self.assertEqual(result["level"], "MEDIUM")
        self.assertEqual(result["base_level"], "LOW")
        self.assertEqual(result["span_days"], 4)
        self.assertEqual(rows[-1]["result"]["risk"]["risk_level"], "LOW")

    def test_dry_resets_and_unknown_does_not_count_as_water(self):
        self.assertFalse(followup_priority([observation(6), observation(2, "Dry"), observation(0)])["raised"])
        self.assertFalse(followup_priority([observation(6, "Unsure"), observation(0)])["raised"])
        self.assertFalse(followup_priority([observation(6), observation(0, "Unsure")])["raised"])

    def test_duplicate_photos_and_single_old_observation_do_not_escalate(self):
        self.assertFalse(followup_priority([observation(6, fingerprint="same"), observation(0, fingerprint="same")])["raised"])
        self.assertFalse(followup_priority([observation(20)])["raised"])
        self.assertFalse(followup_priority([observation(8), observation(4), observation(0, fingerprint="4")])["raised"])

    def test_missing_weather_stays_unassigned_and_no_compounding(self):
        rows = [observation(8), observation(4), observation(0)]
        self.assertEqual(followup_priority(rows)["level"], "MEDIUM")
        rows[-1]["result"]["risk"]["status"] = "UNABLE_TO_ASSESS"
        self.assertIsNone(followup_priority(rows)["level"])


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.store = ReportStore(Path(self.folder.name))
        code = (Path(self.folder.name) / "admin_setup_code.txt").read_text().strip()
        self.store.setup_admin(code, "A long test password 123!")
        self.admin = self.store.login("A long test password 123!")

    def tearDown(self):
        self.folder.cleanup()

    def save(self, **kwargs):
        return self.store.submit(area="Test site", latitude=23.8, longitude=90.4, location_source="Map pin",
                                 observed_at=NOW.isoformat(), water="Water present", notes="Test report",
                                 result=observation(0)["result"], **kwargs)

    def test_private_case_and_followup_persist_without_public_listing(self):
        site, code = self.save()
        self.assertIsNone(self.store.case("wrong"))
        with self.assertRaises(PermissionError):
            self.store.sites("wrong")
        self.assertEqual(self.store.case(code)["id"], site)
        self.save(tracking_code=code)
        self.assertEqual(len(self.store.case(code)["observations"]), 2)
        self.assertEqual(len(self.store.sites(self.admin)), 1)
        self.assertNotIn(code, (Path(self.folder.name) / "reports.sqlite3").read_bytes().decode("latin1"))

    def test_setup_and_admin_actions_require_credentials(self):
        self.assertIsNone(self.store.login("wrong"))
        with self.assertRaises(PermissionError):
            self.store.setup_admin("anything", "Another long password")
        site, code = self.save()
        with self.assertRaises(PermissionError):
            self.store.update_site("wrong", site, "Resolved", "")
        self.store.update_site(self.admin, site, "Resolved", "Water removed")
        self.assertEqual(self.store.case(code)["status"], "Resolved")
        self.assertEqual(len(self.store.case(code)["events"]), 1)
        self.store.logout(self.admin)
        with self.assertRaises(PermissionError):
            self.store.sites(self.admin)

    def test_invalid_or_future_report_is_rejected(self):
        with self.assertRaises(ValueError):
            self.store.submit(area="x", latitude=float("nan"), longitude=90, location_source="Map pin",
                              observed_at=(NOW + timedelta(days=1)).isoformat(), water="Water present", notes="", result={})

    def test_delete_removes_case_and_images(self):
        site, code = self.save()
        self.store.delete_site(self.admin, site)
        self.assertIsNone(self.store.case(code))
        self.assertEqual(self.store.sites(self.admin), [])

    def test_admin_priority_is_authorized_persisted_and_separate_from_model(self):
        site,code=self.save()
        with self.assertRaises(PermissionError):
            self.store.update_site("wrong",site,"Scheduled","Unauthorized",priority="HIGH")
        self.assertIsNone(self.store.case(code)["admin_priority"])
        self.store.update_site(self.admin,site,"Scheduled","Inspect first",priority="HIGH")
        reopened=ReportStore(Path(self.folder.name))
        saved=reopened.admin_case(self.admin,site)
        self.assertEqual(saved["admin_priority"],"HIGH")
        self.assertEqual(saved["observations"][0]["result"]["risk"]["risk_level"],"LOW")
        self.assertIn("Admin inspection priority: High",saved["events"][-1]["note"])
        reopened.update_site(self.admin,site,"Inspected","Status only")
        self.assertEqual(reopened.case(code)["admin_priority"],"HIGH")
        with self.assertRaises(ValueError):
            reopened.update_site(self.admin,site,"Resolved","Bad priority",priority="INVALID")
        self.assertEqual(reopened.case(code)["status"],"Inspected")
        reopened.update_site(self.admin,site,"Resolved","Use assessment",priority=None)
        self.assertIsNone(reopened.case(code)["admin_priority"])
        self.assertIn("Using automated",reopened.case(code)["events"][-1]["note"])
        reopened.update_site(self.admin,site,"Resolved","",priority="LOW")
        reopened.delete_site(self.admin,site)
        with reopened.connection() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM admin_priorities").fetchone()[0],0)

    def test_bearer_codes_are_not_embedded_in_saved_result(self):
        site, code = self.save()
        self.store.submit(area="Test site",latitude=23.8,longitude=90.4,location_source="Saved site",
            observed_at=NOW.isoformat(),water="Dry",notes="",tracking_code=code,
            result={**observation(0)["result"],"followup_code":code,"context":"private form state","submission_key":"internal"})
        self.assertNotIn("followup_code",self.store.case(code)["observations"][-1]["result"])
        self.assertNotIn(code,(Path(self.folder.name)/"reports.sqlite3").read_bytes().decode("latin1"))

    def test_expired_sessions_and_login_lockout(self):
        from services.store import token_hash
        with self.store.connection() as db:
            db.execute("UPDATE sessions SET expires=? WHERE token=?",((NOW-timedelta(hours=1)).isoformat(),token_hash(self.admin)))
        with self.assertRaises(PermissionError):
            self.store.sites(self.admin)
        for _ in range(5):
            self.assertIsNone(self.store.login("wrong"))
        self.assertIsNone(self.store.login("A long test password 123!"))

    def test_resolved_site_reopens_only_for_a_newer_wet_report(self):
        site,code=self.save()
        self.store.update_site(self.admin,site,"Resolved","Cleared")
        for when in (NOW-timedelta(days=2), NOW+timedelta(seconds=1)):
            self.store.submit(area="Test site",latitude=23.8,longitude=90.4,location_source="Saved site",observed_at=when.isoformat(),water="Water present",notes="",result=observation(0)["result"],tracking_code=code)
            expected="Resolved" if when<NOW else "New"
            self.assertEqual(self.store.case(code)["status"],expected)


if __name__ == "__main__":
    unittest.main()
