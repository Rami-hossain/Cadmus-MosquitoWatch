from datetime import timedelta
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from services.store import ReportStore
from tests.test_reporting import NOW, observation

ROOT = Path(__file__).resolve().parents[1]


class ReportingUITests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"MOSQUITOWATCH_DATA_DIR":self.folder.name})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.folder.cleanup()

    def start(self):
        return AppTest.from_file(str(ROOT/"app.py"), default_timeout=30).run()

    def configure(self):
        store=ReportStore(Path(self.folder.name))
        code=(Path(self.folder.name)/"admin_setup_code.txt").read_text()
        store.setup_admin(code,"A reporting test password 123")
        return store,store.login("A reporting test password 123")

    def test_admin_setup_is_gated_and_public_does_not_expose_data(self):
        at=self.start()
        self.assertFalse(at.exception)
        at.radio(key="workspace").set_value("Inspection dashboard").run()
        self.assertTrue(any("Local setup code"==i.label for i in at.text_input))
        self.assertFalse(at.dataframe)

    def test_admin_dashboard_history_and_logout(self):
        store,token=self.configure()
        site,code=store.submit(area="TEST site only",latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=(NOW-timedelta(days=4)).isoformat(),water="Water present",notes="First test visit",result=observation(4)["result"])
        store.submit(area="TEST site only",latitude=23.8,longitude=90.4,location_source="Saved site",observed_at=NOW.isoformat(),water="Water present",notes="Second test visit",result=observation(0)["result"],tracking_code=code)
        at=self.start()
        at.session_state["admin_token"]=token
        at.radio(key="workspace").set_value("Inspection dashboard").run()
        self.assertFalse(at.exception)
        self.assertFalse(at.dataframe)
        at.button(key="admin_open_"+site).click().run()
        self.assertFalse(at.exception)
        text=" ".join(m.value for m in at.markdown)
        self.assertIn("Medium inspection priority",text)
        self.assertTrue(any(item.value=="TEST site only" for item in at.title))
        self.assertTrue(at.dataframe)
        at.button(key="admin_back_to_sites").click().run()
        at.button(key="admin_logout").click().run()
        self.assertFalse(at.exception)
        self.assertFalse(at.dataframe)
        self.assertTrue(any(i.label=="Admin password" for i in at.text_input))

    def test_tracking_requires_code_and_followup_keeps_site(self):
        store,_=self.configure()
        site,code=store.submit(area="TEST private site",latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=NOW.isoformat(),water="Unsure",notes="",result=observation(0)["result"])
        at=self.start()
        at.radio(key="workspace").set_value("Track a report").run()
        text=" ".join(m.value for m in at.markdown)
        self.assertNotIn("TEST private site",text)
        at.text_input(key="tracking_code").set_value(code).run()
        self.assertFalse(at.dataframe)
        at.button(key="open_tracking_report").click().run()
        self.assertFalse(at.exception)
        self.assertFalse(any(b.label.startswith("Open my report") for b in at.button))
        at.run()
        self.assertFalse(any(b.label.startswith("Open my report") for b in at.button))
        next(b for b in at.button if b.label.startswith("Add a follow-up")).click().run()
        self.assertFalse(at.exception)
        self.assertEqual(at.radio(key="workspace").value,"Report a site")
        self.assertEqual(at.text_input(key="survey_area").value,"TEST private site")
        self.assertTrue(at.text_input(key="survey_area").disabled)

    def test_admin_cards_open_details_and_save_separate_priority(self):
        store,token=self.configure()
        site,_=store.submit(area="TEST numbered card",latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=NOW.isoformat(),water="Unsure",notes="",result=observation(0)["result"])
        at=self.start()
        at.session_state["admin_token"]=token
        at.radio(key="workspace").set_value("Inspection dashboard").run()
        self.assertFalse(at.exception)
        self.assertTrue(any('Site counts by priority' in item.value for item in at.markdown))
        self.assertFalse(any(item.label=="Open site" for item in at.selectbox))
        at.button(key="admin_open_"+site).click().run()
        self.assertFalse(any('aria-label="Site counts by priority"' in item.value or '<dl class="mw-dashboard-counts' in item.value for item in at.markdown))
        self.assertFalse(any(item.value=="Admin Access" for item in at.title))
        self.assertFalse(any(button.label=="Sign out" for button in at.button))
        self.assertTrue(any(item.value=="TEST numbered card" for item in at.title))
        at.session_state["admin_status_"+site]="Scheduled"
        at.session_state["admin_priority_"+site]="HIGH"
        at.text_area(key="admin_note_"+site).set_value("TEST inspection comment <script>unsafe()</script>")
        next(button for button in at.button if button.label=="Save inspection update").click().run()
        self.assertFalse(at.exception)
        saved=store.admin_case(token,site)
        self.assertEqual(saved["status"],"Scheduled")
        self.assertEqual(saved["admin_priority"],"HIGH")
        self.assertEqual(saved["observations"][0]["result"]["risk"]["risk_level"],"LOW")
        self.assertIn("TEST inspection comment",saved["events"][-1]["note"])
        text=" ".join(item.value for item in at.markdown)
        self.assertIn("High inspection priority",text)
        self.assertIn('class="mw-timeline-entry mw-admin-update"',text)
        self.assertIn("Admin update",text)
        self.assertIn("Report submission",text)
        self.assertIn("&lt;script&gt;unsafe()&lt;/script&gt;",text)
        self.assertNotIn("<script>unsafe()</script>",text)
        at.button(key="admin_back_to_sites").click().run()
        self.assertFalse(at.exception)
        self.assertTrue(at.button(key="admin_open_"+site))
        matrix=next(item.value for item in at.markdown if 'Site counts by priority' in item.value)
        self.assertIn('<dt>High</dt><dd>1</dd>',matrix)
        self.assertNotIn('<table',matrix)

    def test_default_observation_time_stays_fixed_across_reruns(self):
        at=self.start()
        value=at.time_input(key="survey_time").value
        initial=at.session_state["public_default_datetime"]
        at.run()
        self.assertEqual(at.time_input(key="survey_time").value,value)
        self.assertEqual(at.session_state["public_default_datetime"],initial)

    def test_done_shows_thanks_without_resubmitting_and_can_start_new_report(self):
        from services.analysis import SurveyImage,analyze_images,input_signature
        from tests.test_core import WEATHER,fake_detect,image_bytes
        store,token=self.configure()
        with patch("services.analysis.detect_image",side_effect=fake_detect):
            result=analyze_images([SurveyImage("test.png",image_bytes())],object(),WEATHER)
        area="TEST completion site"
        result.update(location={"display_name":area,"latitude":23.8,"longitude":90.4},signature=input_signature([],area),submission_key="done-test",observed_at=NOW.isoformat(),water="Unsure",notes="",location_source="Map pin")
        site,tracking=store.submit(area=area,latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=NOW.isoformat(),water="Unsure",notes="",result=result,submission_key="done-test")
        at=self.start()
        at.session_state["survey_area"]=area
        at.session_state["analysis"]=result
        at.session_state["report_saved_key"]="done-test"
        at.session_state["report_receipt"]={"site_id":site,"tracking":tracking}
        at.run()
        self.assertFalse(at.exception)
        at.button(key="report_done").click().run()
        self.assertFalse(at.exception)
        text=" ".join(item.value for item in at.markdown)
        self.assertIn("Thank you for submitting a report.",text)
        self.assertIn('class="mw-thank-you-brand"',text)
        self.assertIn("<svg",text)
        self.assertFalse(any(button.label=="Analyze Area" for button in at.button))
        self.assertEqual(len(store.sites(token)),1)
        self.assertEqual(len(store.case(tracking)["observations"]),1)
        at.button(key="thank_you_new_report").click().run()
        self.assertFalse(at.exception)
        self.assertTrue(at.button(key="analyze_area"))
        self.assertNotIn("report_receipt",at.session_state)

    def test_admin_map_includes_all_sites_even_when_card_filters_match_none(self):
        store,token=self.configure()
        sites=[]
        for area,status in [("TEST open site","New"),("TEST resolved site","Resolved")]:
            site,_=store.submit(area=area,latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=NOW.isoformat(),water="Unsure",notes="",result=observation(0)["result"])
            store.update_site(token,site,status,"")
            sites.append(site)
        at=self.start()
        at.session_state["admin_token"]=token
        at.session_state["admin_status_filter"]="Inspected"
        with patch("ui.admin.site_map",return_value=None) as map_widget:
            at.radio(key="workspace").set_value("Inspection dashboard").run()
        self.assertFalse(at.exception)
        self.assertEqual({marker["id"] for marker in map_widget.call_args.kwargs["markers"]},set(sites))
        self.assertFalse(any(button.label=="View site →" for button in at.button))
        self.assertTrue(any("No sites match" in item.value for item in at.info))
        self.assertTrue(any("all statuses, including resolved" in item.value for item in at.caption))

    def test_bottom_delete_removes_selected_site_and_returns_to_cards(self):
        store,token=self.configure()
        entries=[]
        for area in ["TEST delete this site","TEST keep this site"]:
            entries.append(store.submit(area=area,latitude=23.8,longitude=90.4,location_source="Map pin",observed_at=NOW.isoformat(),water="Unsure",notes="",result=observation(0)["result"]))
        site,code=entries[0]
        at=self.start()
        at.session_state["admin_token"]=token
        at.radio(key="workspace").set_value("Inspection dashboard").run()
        at.button(key="admin_open_"+site).click().run()
        self.assertEqual(at.button[-1].label,"Delete")
        self.assertFalse(at.button[-1].disabled)
        at.button(key="delete_site_"+site).click().run()
        self.assertFalse(at.exception)
        self.assertIsNone(store.case(code))
        self.assertIsNotNone(store.case(entries[1][1]))
        self.assertNotIn("admin_selected_site",at.session_state)
        self.assertTrue(any(item.value=="Site deleted." for item in at.success))
        self.assertTrue(at.button(key="admin_open_"+entries[1][0]))

    def test_observations_are_visible_and_photo_guidance_removed(self):
        at=self.start()
        self.assertFalse(at.exception)
        self.assertTrue(at.radio(key="survey_water"))
        self.assertTrue(at.time_input(key="survey_time"))
        self.assertFalse(any("This pin marks" in checkbox.label or "Ask for location" in checkbox.label for checkbox in at.checkbox))
        self.assertFalse(any("Photo guidance" in exp.label or "Observation details" in exp.label for exp in at.expander))

    def test_detected_pin_updates_area_label_without_changing_precision(self):
        at=self.start()
        point={"latitude":23.87591,"longitude":90.37951,"source":"Device location"}
        at.session_state["public_pin"]=point
        with patch("ui.public.reverse_location",return_value="Uttara, Dhaka, Bangladesh"):
            at.run()
        self.assertFalse(at.exception)
        self.assertEqual(at.text_input(key="survey_area").value,"Uttara, Dhaka, Bangladesh")
        self.assertEqual(at.session_state["public_pin"]["latitude"],23.87591)

    def test_automatic_area_name_recovers_if_the_text_widget_sends_a_blank(self):
        at=self.start()
        at.session_state["public_pin"]={"latitude":23.87591,"longitude":90.37951,"source":"Device location"}
        with patch("ui.public.reverse_location",return_value="Uttara, Dhaka, Bangladesh") as lookup:
            at.run()
            at.text_input(key="survey_area").set_value("").run()
        self.assertFalse(at.exception)
        self.assertEqual(at.text_input(key="survey_area").value,"Uttara, Dhaka, Bangladesh")
        self.assertEqual(lookup.call_count,1)

    def test_changed_pin_drops_old_name_and_analyze_retries_failed_lookup(self):
        at=self.start()
        at.session_state["public_pin"]={"latitude":23.87591,"longitude":90.37951,"source":"Map pin"}
        with patch("ui.public.reverse_location",side_effect=["Uttara, Dhaka, Bangladesh",ValueError("Temporary outage"),"Mirpur, Dhaka, Bangladesh"]) as lookup:
            at.run()
            at.session_state["public_pin"]={"latitude":23.81,"longitude":90.36,"source":"Map pin"}
            at.run()
            self.assertFalse(at.exception)
            self.assertEqual(at.text_input(key="survey_area").value,"")
            self.assertTrue(at.session_state["public_name_unavailable"])
            at.button(key="analyze_area").click().run()
        self.assertFalse(at.exception)
        self.assertEqual(at.text_input(key="survey_area").value,"Mirpur, Dhaka, Bangladesh")
        self.assertEqual(at.session_state["public_pin"]["latitude"],23.81)
        self.assertEqual(lookup.call_count,3)

    def test_tracking_landing_has_only_requested_form(self):
        at=self.start()
        at.radio(key="workspace").set_value("Track a report").run()
        self.assertFalse(at.exception)
        self.assertEqual(len(at.text_input),1)
        self.assertEqual(len(at.button),1)
        self.assertTrue(at.button[0].label.startswith("Open my report"))
        self.assertEqual(len(at.expander),1)
        self.assertTrue(at.expander[0].label.startswith("About this tool & privacy"))

    def test_photo_gps_is_automatic_and_old_map_event_cannot_override_it(self):
        from types import SimpleNamespace
        at=self.start()
        nonce=at.session_state["public_map_nonce"]
        at.session_state["public_location_map_"+nonce]={"latitude":23.8,"longitude":90.4,"source":"Map pin","event_id":"old"}
        photo=SimpleNamespace(name="drone.jpg",getvalue=lambda:b"test-image-content")
        with patch("ui.public.st.file_uploader",return_value=[photo]), patch("ui.public.photo_metadata",return_value={"latitude":23.87591,"longitude":90.37951}), patch("ui.public.reverse_location",return_value="Uttara, Dhaka, Bangladesh"):
            at.run()
            self.assertFalse(at.exception)
            self.assertEqual(at.session_state["public_pin"]["source"],"Photo GPS")
            self.assertEqual(at.session_state["public_pin"]["latitude"],23.87591)
            self.assertEqual(at.text_input(key="survey_area").value,"Uttara, Dhaka, Bangladesh")
            self.assertTrue(any("1 photo uploaded" in item.value for item in at.caption))
        with patch("ui.public.st.file_uploader",return_value=[SimpleNamespace(name="screenshot.png",getvalue=lambda:b"different-content")]), patch("ui.public.photo_metadata",return_value={}):
            at.run()
            self.assertFalse(at.exception)
            self.assertNotIn("public_pin",at.session_state)
            self.assertEqual(at.text_input(key="survey_area").value,"")
            self.assertTrue(any("No GPS found" in item.value for item in at.caption))

    def test_missing_photo_gps_automatically_requests_device_then_fills_area(self):
        from types import SimpleNamespace
        at=self.start()
        photo=SimpleNamespace(name="screenshot.png",getvalue=lambda:b"no-gps-photo")
        with patch("ui.public.st.file_uploader",return_value=[photo]), patch("ui.public.photo_metadata",return_value={}), patch("ui.public.site_map",return_value=None) as map_widget:
            at.run()
            self.assertFalse(at.exception)
            self.assertTrue(map_widget.call_args.kwargs["request_location"])
            self.assertFalse(map_widget.call_args.kwargs["controls"])
            nonce=at.session_state["public_map_nonce"]
            at.session_state["public_location_map_"+nonce]={"latitude":23.87591,"longitude":90.37951,"source":"Device location","event_id":"device-response"}
            with patch("ui.public.reverse_location",return_value="Uttara, Dhaka, Bangladesh"):
                at.run()
            self.assertFalse(at.exception)
            self.assertEqual(at.text_input(key="survey_area").value,"Uttara, Dhaka, Bangladesh")
            self.assertFalse(map_widget.call_args.kwargs["request_location"])
            self.assertTrue(any("may differ" in item.value for item in at.caption))


if __name__=="__main__":
    unittest.main()
