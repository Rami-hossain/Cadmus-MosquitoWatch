from datetime import datetime, timedelta, timezone
import io
import unittest
from unittest.mock import patch

from PIL import Image
from PIL.TiffImagePlugin import IFDRational

from services.map_widget import valid_pin
from services.analysis import open_survey_image, preview_png
from services.photo_metadata import photo_metadata
from services.weather import ARCHIVE_URL, WeatherUnavailable, fetch_previous_72h_weather, fetch_rainfall_history


class MetadataTests(unittest.TestCase):
    def test_gps_is_optional_validated_and_not_a_water_inference(self):
        image=Image.new("RGB",(640,640),"green")
        exif=Image.Exif()
        exif[306]="2026:10:12 10:15:00"
        exif[34853]={1:"N",2:(IFDRational(23),IFDRational(48),IFDRational(0)),3:"E",4:(IFDRational(90),IFDRational(24),IFDRational(0))}
        output=io.BytesIO();image.save(output,"JPEG",exif=exif)
        metadata=photo_metadata(output.getvalue())
        self.assertAlmostEqual(metadata["latitude"],23.8)
        self.assertAlmostEqual(metadata["longitude"],90.4)
        self.assertIn("2026-10-12",metadata["capture_time_hint"])
        self.assertNotIn("water",metadata)
        self.assertEqual(photo_metadata(b"bad image"),{})
        normalized=open_survey_image(output.getvalue())
        saved=preview_png(normalized)
        with Image.open(io.BytesIO(saved)) as preview:
            self.assertFalse(preview.getexif())
        self.assertNotIn("latitude",photo_metadata(saved))
        normalized.close()

    def test_map_values_reject_invalid_coordinates_or_sources(self):
        self.assertTrue(valid_pin({"latitude":23.8,"longitude":90.4,"source":"Map pin"}))
        for latitude in (True,float("nan"),10,None):
            self.assertFalse(valid_pin({"latitude":latitude,"longitude":90.4,"source":"Map pin"}))
        self.assertFalse(valid_pin({"latitude":23.8,"longitude":90.4,"source":"untrusted"}))


class HistoricalWeatherTests(unittest.TestCase):
    def test_old_survey_uses_its_own_complete_window(self):
        anchor=(datetime.now(timezone.utc)-timedelta(days=30)).replace(minute=0,second=0,microsecond=0)
        stamps=[int((anchor-timedelta(hours=71-i)).timestamp()) for i in range(72)]
        data={"hourly":{"time":stamps,"temperature_2m":[28]*72,"relative_humidity_2m":[70]*72,"precipitation":[1]*72}}
        with patch("services.weather.get_json",return_value=data) as request:
            weather=fetch_previous_72h_weather(23.8,90.4,now=anchor)
        self.assertEqual(request.call_args.args[0],ARCHIVE_URL)
        self.assertEqual(datetime.fromisoformat(weather["end_time"]).timestamp(),anchor.timestamp())
        self.assertEqual(weather["total_rainfall_mm"],72)

    def test_rainfall_interval_requires_every_hour_and_rejects_duplicates(self):
        end=datetime.now(timezone.utc).replace(minute=0,second=0,microsecond=0)
        start=end-timedelta(hours=4)
        stamps=[int((start+timedelta(hours=i+1)).timestamp()) for i in range(4)]
        data={"hourly":{"time":stamps,"precipitation":[0,1,2,0]}}
        with patch("services.weather.get_json",return_value=data):
            rows=fetch_rainfall_history(23.8,90.4,start,end)
            self.assertEqual(sum(row["Rainfall (mm)"] for row in rows),3)
        for invalid in ({"time":stamps[:-1],"precipitation":[0,1,2]}, {"time":stamps+[stamps[0]],"precipitation":[0]*5}, {"time":stamps,"precipitation":[0,None,1,0]}):
            with patch("services.weather.get_json",return_value={"hourly":invalid}), self.assertRaises(WeatherUnavailable):
                fetch_rainfall_history(23.8,90.4,start,end)


if __name__=="__main__":
    unittest.main()
