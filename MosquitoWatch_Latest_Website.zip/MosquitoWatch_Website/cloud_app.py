"""Streamlit Community Cloud entrypoint; never starts a local database."""
import os
from pathlib import Path
import runpy

os.environ['MOSQUITOWATCH_STORAGE'] = 'supabase'
# Avoid excessive CPU thread contention on shared free hosting.
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('MKL_NUM_THREADS', '2')
runpy.run_path(str(Path(__file__).resolve().with_name('app.py')), run_name='__main__')
