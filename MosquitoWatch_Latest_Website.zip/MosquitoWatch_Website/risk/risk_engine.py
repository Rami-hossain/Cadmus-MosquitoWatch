from __future__ import annotations

from typing import Any

from services.weather import WeatherUnavailable, validate_weather


# Prototype, explainable decision-support weights.
# These are NOT calibrated probabilities and should be tuned with literature/
# entomology expertise before operational deployment.
VISUAL_RULES = {
    "tire": {"per_item": 6, "cap": 18, "label": "Tire"},
    "water_tank": {"per_item": 5, "cap": 15, "label": "Water tank"},
    "drum": {"per_item": 4, "cap": 12, "label": "Drum"},
    "other_containers": {"per_item": 3, "cap": 10, "label": "Other containers"},
    "cocunut_shell": {"per_item": 2, "cap": 5, "label": "Coconut shell"},
}


def calculate_visual_score(counts: dict[str, int]) -> dict[str, Any]:
    breakdown: dict[str, int] = {}
    score = 0

    for class_name, rule in VISUAL_RULES.items():
        count = max(0, int(counts.get(class_name, 0)))
        contribution = min(count * rule["per_item"], rule["cap"])
        breakdown[class_name] = int(contribution)
        score += contribution

    score = min(int(score), 60)
    return {"score": score, "breakdown": breakdown}


def calculate_weather_score(weather: dict[str, float]) -> dict[str, Any]:
    validate_weather(weather)
    rainfall = float(weather.get("total_rainfall_mm", 0.0))
    temperature = float(weather.get("avg_temperature_c", 0.0))
    humidity = float(weather.get("avg_humidity_percent", 0.0))

    # Rainfall: 0–18
    if rainfall >= 30:
        rain_score = 18
    elif rainfall >= 10:
        rain_score = 12
    elif rainfall > 0:
        rain_score = 6
    else:
        rain_score = 0

    # Temperature: 0–12
    if 25 <= temperature <= 32:
        temperature_score = 12
    elif 20 <= temperature < 25 or 32 < temperature <= 35:
        temperature_score = 6
    else:
        temperature_score = 2

    # Humidity: 0–10
    if humidity >= 80:
        humidity_score = 10
    elif humidity >= 65:
        humidity_score = 6
    elif humidity >= 50:
        humidity_score = 3
    else:
        humidity_score = 0

    total = min(rain_score + temperature_score + humidity_score, 40)
    return {
        "score": int(total),
        "breakdown": {
            "rainfall": int(rain_score),
            "temperature": int(temperature_score),
            "humidity": int(humidity_score),
        },
    }


def classify_risk(score: int) -> tuple[str, str]:
    if score >= 65:
        return "HIGH", "Priority field inspection"
    if score >= 35:
        return "MEDIUM", "Inspection recommended"
    return "LOW", "Routine monitoring"


def calculate_risk(
    counts: dict[str, int],
    weather: dict[str, float],
    all_images_unusable: bool = False,
) -> dict[str, Any]:
    weather_valid = True
    try:
        validate_weather(weather or {})
    except WeatherUnavailable:
        weather_valid = False
    for name, value in counts.items():
        if name not in VISUAL_RULES or isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("Counts must be nonnegative integers for the five trained classes.")

    if all_images_unusable or not weather_valid:
        return {
            "status": "UNABLE_TO_ASSESS",
            "cause": "images" if all_images_unusable else "weather",
            "visual_score": None,
            "weather_score": None,
            "total_score": None,
            "risk_level": "UNABLE TO ASSESS",
            "inspection_priority": "Re-survey required",
            "visual_breakdown": {},
            "weather_breakdown": {},
        }

    visual = calculate_visual_score(counts)
    weather_result = calculate_weather_score(weather)

    total = min(visual["score"] + weather_result["score"], 100)
    level, priority = classify_risk(total)

    # By construction weather is capped at 40, so weather alone can never create
    # a HIGH classification. This is an explicit safeguard against treating
    # favorable weather as proof of a breeding habitat.
    return {
        "status": "OK",
        "visual_score": visual["score"],
        "weather_score": weather_result["score"],
        "total_score": int(total),
        "risk_level": level,
        "inspection_priority": priority,
        "visual_breakdown": visual["breakdown"],
        "weather_breakdown": weather_result["breakdown"],
    }
