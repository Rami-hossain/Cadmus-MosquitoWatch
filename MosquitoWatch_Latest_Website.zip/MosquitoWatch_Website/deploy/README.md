# Cloud deployment

This copy adds Supabase persistence without changing the original model or
the working Windows release. Streamlit runs both the UI and Python inference.

## Current state

The supplied Supabase project has seven app tables in the private
`mosquitowatch` schema, all with row-level security enabled. Its
`mosquitowatch-private` Storage bucket is private. The schema was applied
through the signed-in dashboard and verified with a live read-only query.

The app is not live. A private GitHub repository has been created for publishing.
Database credentials and the server-only Storage key have not been read or
configured. No existing local reports or credentials have been copied online.

## Deployment procedure

1. Run `schema.sql` in the Supabase SQL Editor if deploying to a new project.
   This step is already complete for the supplied project.
2. In Supabase **Connect**, use the **Session pooler** URI (port 5432).
   Enter the saved password separately as `database_password`; no URI encoding
   is needed when using the separate password field in the secrets template.
   The app requires verified TLS; do not disable certificate checking.
3. Put the values described in `secrets.example.toml` into Streamlit's Secrets
   settings. Keep the database password and `sb_secret_` key server-only.
   Modern secret keys are sent on `apikey`, never as JWT bearer tokens.
   Set a new cloud admin code and a password of at least 12 characters.
   First startup stores salted credential hashes in Postgres. Subsequent
   startup does not silently replace an existing admin password.
4. Push source to the user's private GitHub repository. Exclude `.local`,
   virtual environments, secrets and real report/image data. Preserve the
   original `.pt` file byte for byte. No Git LFS is needed for its current size.
5. Run GitHub's Linux CPU checks and inspect the benchmark. The Windows
   preflight is not a substitute for Linux installation and inference tests.
6. In Streamlit Community Cloud select Python 3.13 and `cloud_app.py` as the
   entrypoint. Root `requirements.txt` selects CPU-only PyTorch and psycopg.
7. Test a clearly synthetic report: submit, save tracking receipt, reopen by
   private code, add a follow-up, log in as admin, comment/change priority,
   restart the app and verify persistence. Test deletion and Storage cleanup.
   Do not advertise public availability before these checks pass.

## Storage behaviour

Postgres stores metadata, hashed tracking codes and authenticated admin
sessions. Full report payloads, including original and annotated preview
images, are compressed into private Storage objects. The server downloads
them only after an authorized report lookup. Summary lists omit photos.
No public or signed object URL is sent to uploaders.

Every upload has a committed reservation before bytes leave the server.
If a save is interrupted, the orphan becomes eligible for cleanup after
24 hours. Deleting a site cascades report data and queues its objects for
immediate cleanup. Storage errors leave durable retry entries. Cleanup runs
on startup and authenticated admin overview loads, in batches of three.
If offline or idle, object deletion can remain pending until the app runs
again. Verify the cleanup queue is empty before promising erasure completion.

Cloud connection failures show a storage error. They never fall back to an
ephemeral SQLite database. Original local reports remain on the Windows PC;
data migration requires a separate reviewed transfer.

## Checks and limitations

The local CPU preflight measured a 1.632-second warm median and 542.8 MiB
sampled peak RSS on a synthetic image. It excludes Streamlit, larger batches,
network I/O and concurrent sessions. The Linux wheel resolution was performed
from Windows; Linux-specific environment markers still need the Linux CI run.
Free plan sleep, memory, database and storage quotas apply.

The 95-test cloud suite includes shared auth/report tests, SQL parsing and
cloud adapter mocks. Those tests do not prove live database, TLS or Storage
connectivity. A live round-trip and restart test remain release gates.

The locked dependency set passed its advisory audit. Before opening public access, verify upload/CPU limits
under concurrent load, review admin access, and arrange off-platform backups.
Database backups do not include Storage objects; back up both separately.

## Rollback

Keep the local application running while cloud validation is pending. If a
deployment fails, disable public access or restore the previous Git commit.
Leave Supabase data in place; do not drop tables or delete the bucket as a
rollback. New cloud reports must be preserved. The migration only added app
tables and a private bucket; no billing or compute upgrade was enabled.

The nine Windows installer checks remain with the local release. They do not
apply to this Linux cloud source. Model integrity remains covered here.

The nine Windows installer checks remain with the local release. They do not
apply to this Linux cloud source. Model integrity remains covered here.

The nine Windows installer checks remain with the local release. They do not
apply to this Linux cloud source. Model integrity remains covered here.
