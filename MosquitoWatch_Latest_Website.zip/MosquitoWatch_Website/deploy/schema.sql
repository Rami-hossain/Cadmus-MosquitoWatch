-- Apply once in the project's SQL Editor before starting the cloud app.
-- This schema is not exposed through Supabase's public Data API.
BEGIN;
CREATE SCHEMA IF NOT EXISTS mosquitowatch;
REVOKE ALL ON SCHEMA mosquitowatch FROM PUBLIC, anon, authenticated;
CREATE TABLE IF NOT EXISTS mosquitowatch.config (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mosquitowatch.sessions (token TEXT PRIMARY KEY, expires TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mosquitowatch.sites (
    id TEXT PRIMARY KEY, tracking TEXT UNIQUE NOT NULL, area TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL, longitude DOUBLE PRECISION NOT NULL,
    location_source TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mosquitowatch.observations (
    id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES mosquitowatch.sites(id) ON DELETE CASCADE,
    observed_at TEXT NOT NULL, submitted_at TEXT NOT NULL, water TEXT NOT NULL,
    notes TEXT NOT NULL, result TEXT NOT NULL, submission_key TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS mosquitowatch.events (
    site_id TEXT NOT NULL REFERENCES mosquitowatch.sites(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL, status TEXT NOT NULL, note TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mosquitowatch.admin_priorities (
    site_id TEXT PRIMARY KEY REFERENCES mosquitowatch.sites(id) ON DELETE CASCADE,
    priority TEXT NOT NULL CHECK(priority IN ('HIGH','MEDIUM','LOW')), updated_at TEXT NOT NULL);
-- Reservations make interrupted uploads discoverable. Deletions remain queued
-- until both the private object and its reservation have been removed.
CREATE TABLE IF NOT EXISTS mosquitowatch.cloud_files (
    path TEXT PRIMARY KEY, site_id TEXT REFERENCES mosquitowatch.sites(id) ON DELETE SET NULL,
    cleanup_after TIMESTAMPTZ NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '24 hours'));
CREATE INDEX IF NOT EXISTS mw_observations_site ON mosquitowatch.observations(site_id, observed_at, submitted_at);
CREATE INDEX IF NOT EXISTS mw_events_site ON mosquitowatch.events(site_id, created_at);
CREATE INDEX IF NOT EXISTS mw_cleanup ON mosquitowatch.cloud_files(cleanup_after) WHERE site_id IS NULL;
ALTER TABLE mosquitowatch.config ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.sites ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.admin_priorities ENABLE ROW LEVEL SECURITY;
ALTER TABLE mosquitowatch.cloud_files ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA mosquitowatch FROM PUBLIC, anon, authenticated;
-- The application uses the database owner through the encrypted session pooler.
-- Do not expose its connection string or Storage service-role key to browsers.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('mosquitowatch-private', 'mosquitowatch-private', false, 47185920, ARRAY['application/gzip'])
ON CONFLICT (id) DO NOTHING;
COMMIT;
