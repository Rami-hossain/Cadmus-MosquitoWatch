from __future__ import annotations

from datetime import datetime, timezone
import os
import logging
from pathlib import Path

import streamlit as st

from services.detector import load_model
from services.location import find_locations
from services.cloud_store import CloudReportStore, startup_diagnostic
from services.store import ReportStore
from services.weather import fetch_previous_72h_weather
from ui.admin import render_admin
from ui.cases import render_tracking
from ui.public import render_public

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / 'model/mosquitowatch_yolo26s_best.pt'

st.set_page_config(page_title='MosquitoWatch AI', page_icon=str(BASE_DIR / 'assets/favicon.png'), layout='wide', initial_sidebar_state='collapsed')
st.markdown('<style>' + (BASE_DIR / 'assets/style.css').read_text(encoding='utf-8') + '</style>', unsafe_allow_html=True)


@st.cache_resource(show_spinner=False)
def get_model():
    return load_model(MODEL_PATH)


@st.cache_resource(show_spinner=False)
def get_store(directory, backend):
    if backend == 'supabase':
        # cloud_app.py always enables this; missing secrets never fall back to SQLite.
        return CloudReportStore(dict(st.secrets['supabase']))
    return ReportStore(Path(directory))


@st.cache_data(ttl=86400, max_entries=100, show_spinner=False)
def get_locations(name):
    return find_locations(name)


@st.cache_data(ttl=600, max_entries=100, show_spinner=False)
def get_weather(latitude, longitude, hour_key):
    anchor = datetime.strptime(hour_key, '%Y-%m-%dT%H').replace(tzinfo=timezone.utc)
    return fetch_previous_72h_weather(latitude, longitude, now=anchor)


logo = (BASE_DIR / 'assets/mosquito.svg').read_text(encoding='utf-8').replace('<svg ', '<svg aria-hidden="true" ')
st.markdown('<div class="mw-topbar"><div class="mw-brand">' + logo + 'MosquitoWatch<span class="mw-ai">AI</span></div><span class="mw-topnote">Bangladesh</span></div>', unsafe_allow_html=True)
page = st.radio('Workspace / প্যানেল', ['Report a site', 'Track a report', 'Inspection dashboard'], horizontal=True, key='workspace', label_visibility='collapsed', format_func=lambda name: 'Admin Access' if name == 'Inspection dashboard' else name)
try:
    store = get_store(os.environ.get('MOSQUITOWATCH_DATA_DIR', str(BASE_DIR / '.local')), os.environ.get('MOSQUITOWATCH_STORAGE', 'sqlite'))
except Exception as error:
    logging.getLogger(__name__).error('Report storage startup failed: %s', startup_diagnostic(error))
    st.error('Report storage is unavailable. Ask the administrator to check the cloud database, private storage and deployment secrets.')
    st.stop()

if page == 'Inspection dashboard':
    render_admin(store)
elif page == 'Track a report':
    render_tracking(store)
else:
    render_public(store, get_model, get_locations, get_weather)

if page == 'Report a site' and not st.session_state.get('public_submission_done'):
    st.caption('Potential breeding-risk objects only. Field inspection required.')
if page == 'Track a report':
    with st.expander('About this tool & privacy / ব্যবহার ও গোপনীয়তা'):
        st.write('MosquitoWatch does not directly detect mosquitoes, larvae, water, or dengue. Inspection priorities use prototype rules and require field verification.')
        st.write('Phone photos are accepted, but the detector was trained on drone imagery. Phone-photo accuracy needs separate evaluation.')
        st.write('Submitted reports and photos are stored in the project’s Supabase database and private storage. Streamlit hosts this application. Your private tracking code gives access to your report; admins can review and delete it. Selected locations go to Open-Meteo for weather and OpenStreetMap for map tiles; rounded coordinates go to Photon for area names. Free-service terms apply. This prototype is not connected to a government reporting service.')
