const select=document.getElementById('choice');
const send=(type,data={})=>window.parent.postMessage({isStreamlitMessage:true,type,...data},'*');
select.addEventListener('change',()=>send('streamlit:setComponentValue',{value:select.value,dataType:'json'}));
window.addEventListener('message',event=>{
  if(event.source!==window.parent||event.data?.type!=='streamlit:render')return;
  const args=event.data.args||{};
  document.getElementById('label').textContent=args.label||'';
  select.replaceChildren();
  for(const item of args.options||[]){
    const option=document.createElement('option');option.value=item.value;option.textContent=item.label;select.appendChild(option);
  }
  select.value=args.value;
  select.disabled=Boolean(event.data.disabled);
  send('streamlit:setFrameHeight',{height:document.body.scrollHeight+4});
});
send('streamlit:componentReady',{apiVersion:1});
send('streamlit:setFrameHeight',{height:75});
