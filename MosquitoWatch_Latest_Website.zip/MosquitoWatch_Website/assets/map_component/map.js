/* Streamlit v1 JSON bridge; protocol follows streamlit/component-lib 1.45.1. */
const send=(type,data={})=>window.parent.postMessage({isStreamlitMessage:true,type,...data},'*');
const publish=value=>send('streamlit:setComponentValue',{value,dataType:'json'});
const hint=document.getElementById('hint');
let map, layers, pinMarker, args={}, lastPin='', lastMarkers='', lastReset='', requested=new Set();
let mapOpen=null;
function sendHeight(){
  const open=!args.compact||mapOpen;
  const mapHeight=Math.max(160,Math.min(600,Number(args.height)||360));
  const minimum=open?mapHeight+60+(args.controls!==false&&args.editable?90:0):90;
  send('streamlit:setFrameHeight',{height:Math.max(document.body.scrollHeight+4,minimum)});
}
function updateLayout(){
  const open=!args.compact||mapOpen;
  document.getElementById('map').style.height=`${Math.max(160,Math.min(600,Number(args.height)||360))}px`;
  document.getElementById('map-panel').hidden=!open;
  document.getElementById('tools').style.display=args.controls!==false&&(args.editable||args.compact)?'flex':'none';
  hint.style.display=args.controls===false?(args.request_location&&!args.pin?'block':'none'):(args.editable||args.compact?'block':'none');
  document.getElementById('map').setAttribute('aria-label',args.controls===false?'Site map. Click the site to place a pin; use arrow keys to pan and plus or minus to zoom.':'Site map. Use arrow keys to pan, plus and minus to zoom; use the map centre button to place a pin.');
  document.getElementById('caption').textContent=args.controls===false?(args.pin?.source==='Device location'?'Device location marks the upload position. Adjust the pin if the photo site is elsewhere.':'Click the map to adjust the site if needed.'):(args.editable?'Check the ground location before confirming.':'Reported site location.');
  document.getElementById('locate').style.display=args.editable?'block':'none';
  document.getElementById('confirm').style.display=args.editable&&open?'block':'none';
  const toggle=document.getElementById('toggle-map');
  toggle.style.display=args.compact?'block':'none';
  toggle.textContent=open?'Hide map':'View on map';
  toggle.setAttribute('aria-expanded',String(Boolean(open)));
  if(map)setTimeout(()=>map.invalidateSize(),0);
  sendHeight();
}
document.getElementById('toggle-map').onclick=()=>{mapOpen=!mapOpen;updateLayout();};
function pin(lat,lon,source,accuracy){
  if(!(lat>=20.5&&lat<=26.7&&lon>=88&&lon<=92.7)){hint.textContent='Choose a site inside Bangladesh / বাংলাদেশের স্থান বাছুন';return;}
  const point={latitude:lat,longitude:lon,source,accuracy:accuracy||null,event_id:crypto.randomUUID()};
  drawPin(point);hint.textContent=source==='Device location'?`Device estimate, accuracy about ${Math.round(accuracy)} m. Check the site pin.`:'Pin selected. Confirm the site below the map / নিচে অবস্থান নিশ্চিত করুন।';
  publish(point);
}
function drawPin(p){
  if(pinMarker)map.removeLayer(pinMarker);
  if(!p)return;
  pinMarker=L.circleMarker([p.latitude,p.longitude],{radius:10,color:'#102f26',weight:3,fillColor:'#61d4b6',fillOpacity:1}).addTo(map);
}
function locate(){
  if(!window.isSecureContext||!navigator.geolocation){hint.textContent='Device location needs HTTPS or localhost. Place a pin on the map instead.';return;}
  hint.textContent='Waiting for your browser’s location permission…';
  navigator.geolocation.getCurrentPosition(p=>{pin(p.coords.latitude,p.coords.longitude,'Device location',p.coords.accuracy);map.setView([p.coords.latitude,p.coords.longitude],17);},error=>{
    hint.textContent=error.code===1?'Location permission denied. You can still place a map pin / মানচিত্রে পিন দিন।':'Location unavailable or timed out. Place a map pin instead.';
  },{enableHighAccuracy:true,timeout:12000,maximumAge:0});
}
document.getElementById('locate').onclick=locate;
document.getElementById('confirm').onclick=()=>{const p=map.getCenter();pin(p.lat,p.lng,'Map pin');};
window.addEventListener('message',event=>{
  if(event.source!==window.parent||event.data?.type!=='streamlit:render')return;
  args=event.data.args||{};
  if(!map){
    map=L.map('map',{scrollWheelZoom:false,zoomControl:true}).setView([23.8,90.4],7);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'}).addTo(map).on('tileerror',()=>{hint.textContent='Map tiles unavailable. Check your internet connection; a saved pin is still retained.';});
    layers=L.layerGroup().addTo(map);
    map.on('click',e=>{if(args.editable)pin(e.latlng.lat,e.latlng.lng,'Map pin');});
  }
  if(mapOpen===null)mapOpen=!args.compact;
  updateLayout();
  const reset=String(args.reset_id||'');
  if(reset!==lastReset){lastReset=reset;drawPin(null);lastPin='';hint.textContent='Choose a location or view the map.';}
  const p=JSON.stringify(args.pin||null);
  if(p!==lastPin){lastPin=p;drawPin(args.pin);if(args.pin)map.setView([args.pin.latitude,args.pin.longitude],16);}
  const m=JSON.stringify(args.markers||[]);
  if(m!==lastMarkers){
    lastMarkers=m;layers.clearLayers();
    const bounds=[];
    (args.markers||[]).forEach(item=>{
      const point=[item.latitude,item.longitude];bounds.push(point);
      const colors={HIGH:'#e46f76',MEDIUM:'#edbf63',LOW:'#61d4b6'};
      const marker=L.circleMarker(point,{radius:9,color:'#132b27',weight:2,fillColor:colors[item.level]||'#91a8b0',fillOpacity:.95}).addTo(layers);
      const label=document.createElement('div');label.textContent=`${item.area} · ${item.level||'Unassigned'} · ${item.status}`;
      marker.bindPopup(label);
      marker.on('click',()=>publish({selected_id:item.id,event_id:crypto.randomUUID()}));
    });
    if(bounds.length)map.fitBounds(bounds,{padding:[35,35],maxZoom:16});
  }
  if(args.request_location&&args.request_id&&!requested.has(args.request_id)){
    requested.add(args.request_id);locate();
  }
  setTimeout(()=>map.invalidateSize(),0);
  sendHeight();
});
if(typeof ResizeObserver!=='undefined'){
  let visibleWidth=0,visibleHeight=0;
  new ResizeObserver(()=>{
    const rect=document.getElementById('map').getBoundingClientRect();
    if(map){
      map.invalidateSize();
      if(rect.width>0&&rect.height>0&&(visibleWidth<=0||visibleHeight<=0)){
        const points=(args.markers||[]).map(item=>[item.latitude,item.longitude]);
        if(points.length)map.fitBounds(points,{padding:[35,35],maxZoom:16});
      }
    }
    visibleWidth=rect.width;visibleHeight=rect.height;sendHeight();
  }).observe(document.getElementById('map'));
}
send('streamlit:componentReady',{apiVersion:1});
send('streamlit:setFrameHeight',{height:460});
