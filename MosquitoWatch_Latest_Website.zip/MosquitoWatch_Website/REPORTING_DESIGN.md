# Site reporting and inspection workflow

Agreed with the project owner on 16 October 2026 through the grill-me interview.

The release remains a local Windows application. Public internet hosting is a separate deployment task. The server continues to bind only to 127.0.0.1; phones on other computers cannot connect to this address.

## Public reporting

One report represents one site, with up to ten drone or phone photos. There is no public account, email, or phone-number collection. Phone photos are accepted for reporting, but the drone-trained detector needs separate evaluation on this image domain.

Photo upload automatically uses valid embedded GPS when available. When photo GPS is missing, it automatically requests browser device-location permission. Device positions are labelled as upload locations and may differ from the capture site. Missing GPS leaves manual map-click tagging and area entry available. A photo selector is shown for multiple geotagged photos. The uploader reviews the ground-site pin; camera/drone/device positions are not assumed to be object positions. Raw coordinates and detector settings are not displayed to uploaders.

The uploader confirms a survey date/time in Bangladesh time, supplies a water observation (Water present, Dry, Unsure), reviews analysis, and explicitly consents before saving. EXIF dates are suggestions only; an assumed camera timezone is never silently applied as the survey date. Original EXIF metadata is not retained in saved previews.

## Persistence and privacy

SQLite stores sites, immutable observations, metadata-free photo previews, annotated previews, and inspection events in `.local/reports.sqlite3`. Data remains until an admin confirms deletion. The local folder, report data, setup codes, and credentials are excluded from release ZIPs.

A random private tracking code permits reading and adding observations to its single site. Only its SHA-256 digest is stored. Anyone possessing the code has that site's access; there is no identity recovery because no contact information is collected. Neighbouring pins are not automatically merged. Follow-ups use the saved site location.

Admin setup requires a one-time code from a local file and a password chosen by the owner. Passwords use salted PBKDF2-HMAC-SHA256 with 600,000 iterations. Sessions are random, stored as digests, expire after eight hours, and are checked by every admin operation. Five failed logins trigger a one-minute lockout. Admins see all sites, precise pins, photos, history, and statuses New / Scheduled / Inspected / Resolved. Newer water-present follow-ups reopen resolved sites; adding an older survey does not reopen them. Resolving a case alone does not assert a dry observation.

## Time and priority

Object/weather priority retains the original prototype rules. Its complete 72-hour weather interval ends at the survey hour. Older surveys use the historical weather service and are labelled historical; missing or invalid weather leaves priority unassigned while preserving detections.

Water is reported by a person, not inferred by YOLO. Within the observations after the last Dry report, distinct-photo water-present visits at least 72 hours apart raise the latest valid base priority by one level, at most once. High remains High. Unsure is not a wet visit, a latest Unsure or reused photo cannot trigger escalation, and a single old report does not age automatically into a higher priority. No increase is assigned when the latest base assessment is incomplete.

The timeline shows the span between wet observations, never confirmed water age. Continuous water between visits is explicitly unconfirmed. A dry observation ends the period. Backdated reports are sorted by observation time.

Rainfall charts can request a complete hourly interval between two visits (1 hour to 90 days). Missing hours are never interpreted as zero; unavailable intervals are labelled unavailable. Rainfall does not establish that containers filled or remained wet. The complete 72-hour weather preceding each visit is also retained in the observation table.

## Free resources and deployment limits

- Leaflet 1.9.4 is bundled locally with its BSD license. Map tiles are fetched normally from OpenStreetMap with visible attribution; no prefetching or offline tile downloads.
- Open-Meteo supplies area search, current weather history, and historical reanalysis. Free endpoints are for non-commercial use and have request limits. Existing response caches reduce repeat calls.
- Browser geolocation requires permission and a secure context (HTTPS or localhost). Permission is not bypassed. Remote phone uploads require a later HTTPS deployment and review of hosting capacity, access controls, backups, and service terms.

Sources: https://leafletjs.com/download.html ; https://operations.osmfoundation.org/policies/tiles/ ; https://open-meteo.com/en/terms ; https://open-meteo.com/en/docs/historical-weather-api ; https://developer.mozilla.org/en-US/docs/Web/API/Geolocation_API

The model file is unchanged and its original SHA-256 remains enforced by the launcher and release builder. The app does not directly detect mosquitoes, larvae, water, or dengue.

## Requested page fixes — 18 October 2026

Report a site now displays a readable area name for the selected device/photo/map position. Photon reverse lookup uses rounded coordinates, cached responses, an identifying User-Agent, and paced cache misses. The exact selected pin is retained separately and shown on the always-visible map. Names can be corrected manually; failed lookup retains the pin and offers retry. No default Dhaka position is presented as a detected upload location. Area-name source attribution and external-service disclosure are retained.

The native upload box places drag/drop instructions above Browse files and the file-size limit below it. Photo guidance has been removed. Water observations, survey date/time, and notes have their own permanently visible bordered section. A single Analyze Area action follows the observations on all screen sizes.

Track a report now opens with Follow the same site, the private-code explanation, tracking-code input, and Open my report. Report content appears only after a valid lookup. The unrelated hero and footer sections are removed from this landing page.

The navigation and sign-in page display Admin Access. Login supports an admin code plus password, stored as separate salted PBKDF2 hashes. Failed-code attempts use the same lockout as failed passwords. Local credential reconfiguration revokes existing sessions and preserves reports. The owner explicitly requested short demo credentials for the localhost copy; they were configured only in private runtime databases, with a stated weak-password caveat. No owner credential values or runtime databases are distributed. New installations retain the ordinary setup flow and password-length requirement.

Free area-name lookup uses the Photon public demo API at modest interactive volume with caching; availability is not guaranteed. Source/API terms: https://github.com/komoot/photon and https://github.com/komoot/photon/blob/master/docs/api-v1.md . MOSQUITOWATCH_REVERSE_URL can select a compatible self-hosted endpoint for a later deployment. This is not an IP geolocation service; camera coordinates and the current device position remain distinct sources.


Latest layout adjustment: the pin-confirmation checkbox is removed. A valid site pin is still required before analysis; uploaded GPS supplies it automatically. Upload details/files and the photo-count summary use separate gray panels.


Admin review uses a card list and explicit detail navigation. Status totals cover all sites; the priority matrix breaks down High/Medium/Low/Unassigned across workflow statuses. Cards and the optional overview map respect the filters. Priority overrides live in admin_priorities, protected by the same server-side authorization as status updates. Status, priority and comment updates are one SQLite transaction with an inspection event; clearing the override returns to the automated assessment. Original observation risk JSON is never modified. Deleting a site cascades to its override. Private tracking shows admin priority with an explicit label, while full survey assessments retain the original automatic result.


The latest admin overview uses compact priority totals rather than a workflow matrix. A bundled selection-only component supplies native selects for the fixed admin choices. The component checks parent render messages, renders labels using textContent, and Python validates returned values against the offered options. Admin save operations retain server-side authorization and priority validation.


Focused admin site details: View site now opens a separate view containing only the selected site title/ID, Back to sites, admin editing controls and the site history/map/photos. Admin Access heading, sign-out, dashboard caption, global status totals, priority totals and overview filters are shown only on the overview. Authentication is still checked before any site details render.


Admin deletion control: a bright red Delete button now appears at the end of each admin site-detail page. Clicking it deletes the selected site and its saved observations/photos, inspection events and priority override, then returns to the site list with a success message. The previous expander and confirmation checkbox are removed. Server-side admin authorization and SQLite cascading deletion remain in force.


Admin map: View sites on map appears directly below Sites to review and stays collapsed until the admin opens it. The map includes every reported site, including resolved reports, regardless of card filters. Selecting any marker opens that site. The map remains available when the current card filters match no sites.


Automatic area-name repair: successfully resolved place names are retained separately from the text widget and tied to the exact selected pin. A blank form update restores the cached name without another request. Moving the pin clears the old name; failed lookup retries on Analyze Area or a later form rerun, with bounded retry timing. A temporary lookup outage no longer asks the uploader to type the site name. The precise pin is preserved. No new service or model changes were introduced.


Submission completion: a Done button follows Save tracking receipt after a report is saved. Done shows a centered mosquito logo, MosquitoWatch name and Thank you for submitting a report message. It does not resubmit the report. Report another site clears the form state for a fresh report; saved database records are retained.


History entry styling: uploader/drone report observations use red circles and a Report submission label. Admin inspection updates use green circles, bold text and a light green background. Automatic reopening after a new water-present report remains labelled Report update with a red circle, rather than being attributed to an admin. Notes are HTML-escaped and preserve line breaks. This is a presentation change; stored reports and assessments are unchanged.
