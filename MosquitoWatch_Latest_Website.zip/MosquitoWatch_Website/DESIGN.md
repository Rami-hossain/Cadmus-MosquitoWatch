# MosquitoWatch interface

This update refines the original dark/teal Streamlit interface. It remains an inspection tool for Bangladesh survey teams.

- Surface: `#0E1718`; grouped controls/results: `#152225`; separating lines: `#34494B`.
- Text: `#EEF4F1`; secondary text: `#B0C3BE`; action/focus accent: `#61D4B6`.
- Primary button text: `#0B2620`, with a visible focus outline `#8CEBD1`.
- Use Segoe UI and Nirmala UI system fallbacks. No external fonts or image assets are requested.
- One task per screen: upload images, locate area, analyze. Show a place-name choice only when needed to resolve ambiguity.
- Use a single framed input group, then a priority statement, object counts, weather, Bangla guidance, and image review. Avoid dashboard controls or developer settings.
- At widths below 700px, stack native columns, show two object-count columns, and stack weather rows. Keep body text at normal reading size.
- Priority uses words and Bangla text as well as color. Unknown assessment and provisional coverage are explicit states.
- Store report state in the browser session's server memory; changed inputs label the previous report. Browser refresh starts a new session.

CSS is in `assets/style.css`; Streamlit theme values are in `.streamlit/config.toml`. This is a local application interface, not a claim of government approval or operational validation.

## Minimal interface revision — 18 October 2026

The supplied reference informed a light surface, navy typography, coral main action, and fewer simultaneous instructions. The new line-drawn mosquito SVG replaces the target icon; a matching favicon is bundled. The initial public screen focuses on photos, a site pin, and Analyze Area. Water observations, dates, and notes remain in Observation details; image limits/domain caveats remain in Photo guidance; privacy and model limitations remain accessible in About this tool & privacy. A compact date/water summary remains visible so collapsed fields are not silently hidden. Existing validation, consent, private tracking, and admin access checks remain active.

Palette: page #FCFCFA, panel #F1F4F3, navy #14243A, secondary text #526074, border #DCE3E2, action #C93E48. System Segoe UI / Nirmala UI keep English and Bangla readable without remote fonts. The main action sits below the upload controls instead of beneath the full map.
