# Validation and remaining limits

Checked on 16 October 2026, Bangladesh time.

## Completed

- Inspected the complete original ZIP before source edits. The original Downloads ZIP is unchanged. The inspection copy has been restored byte-for-byte after its runtime-generated caches were used.
- Parsed all 18 Python source files in the updated app, excluding installed dependencies.
- Fresh Windows setup completed through `run.bat --setup-only`, using registered Python 3.13.7 and a private `.venv`.
- `pip check` reported no broken requirements.
- Full package versions are locked for Windows Python 3.13. A separate Windows Python 3.12 lock was resolved and checked for wheel availability; Python 3.12 was not installed/tested here. Python 3.11 is accepted by the launcher but was not freshly tested.
- All **54 offline regression tests passed** in the fresh private environment. Negative tests deliberately simulate corrupt images and inference errors; their captured terminal diagnostics are expected.
- Normal `run.bat` startup used the private environment and served HTTP 200 from the default port's health endpoint.
- The fresh app completed browser upload, local model inference, live location lookup, full 72-hour completed-interval weather collection, priority assignment, Bangla guidance, image display, and report download using a synthetic random-image fixture. No target objects were detected in that fixture. This confirms execution, not accuracy.
- Downloaded UTF-8 report contained Bangla recommendations, omitted internal scores/settings/coordinates, and did not clear the displayed result.
- Real-browser input changes preserved the previous result and labelled it as a previous report. A regression test also covers changing a place-name match while retaining the same search query.
- Checked the interface at 1280 x 900 and 390 x 844 browser viewports. At 390px, the document width was 390px and weather rows stacked into one column. These were browser-emulated viewports, not a physical phone.
- Corrected primary-button contrast and the fixed header overlapping the brand. The final primary-button contrast is 8.84:1, secondary authored text is 9.87:1, and main text on the result panel is 14.64:1. Keyboard focus styling and reduced-motion behavior are included. No formal screen-reader audit was performed.
- The final private-environment server log had no app error traceback after the synthetic analysis; disabling the source watcher avoids the earlier PyTorch module-inspection warning.
- Model bytes match the original ZIP. SHA-256: `9cab40066fcc48411555fb146873a26c269cdf436f7eb52c6b759c2823a6b91c`.

## Regression coverage

Weather: the preceding-hour precipitation timestamp convention, complete coverage, one-hour/incomplete windows, gaps, stale timestamps, duplicate hours, mismatched arrays, null/non-finite/out-of-range values, future-hour exclusion, and invalid coordinates.

Locations: Bangladesh restriction, invalid coordinates, exact-name preference, district disambiguation, and ambiguity retained as a user choice.

Images and scoring: corrupt uploads, image format/size limits, EXIF orientation, pixel-identical duplicates with differing metadata, poor-quality exclusion, inference/annotation failure, missing weather, provisional coverage, and priority thresholds.

Interface and startup: initial validation, saved results, stale reports, hidden settings/coordinates, escaped filenames, read-only checks, original model integrity, interpreter selection, and child-process exit-code propagation.

## Limits that require data or field work

The original model's detection accuracy has not been improved or independently measured. No representative labelled drone images were supplied. The original external evaluation tables show low recall and need to be reproduced; see `evaluation/README.md` and its evaluation script. Those original tables were not altered to make the results appear better.

The inspection rules and image-quality thresholds remain prototype heuristics. They are not calibrated probabilities, an entomological finding, or a dengue forecast. A field study is needed before operational reliance. Weather is modelled area-level data, not a direct measurement at each detected container.

Exact duplicate images are skipped, but different views of the same object cannot be matched reliably with this project alone. No surveyed-area measurements, georeferenced object coordinates, or image-overlap data were supplied. The UI therefore reports detections and explicitly avoids unique-object/density claims.

No model training, conversion, replacement, or weight edits were performed. The evaluation helper can be run only after a labelled dataset with the correct class mapping is provided; it was syntax-checked but not run here.

First setup and location/weather retrieval depend on internet access and third-party service availability. When complete weather is unavailable, the app retains visual detections but does not assign an inspection priority.

## Windows long-path repair verification

The user's extra extraction folder made a torch header path exceed the Windows path limit. The prior successful setup used a shorter folder and did not cover this case.

The updated launcher chooses a project-specific environment under Documents/MosquitoWatch/venvs when the local .venv would exceed a conservative path budget for the pinned torch wheel. This also avoids Windows Store LocalAppData redirection. An explicit MOSQUITOWATCH_ENV_ROOT can select another short writable root. No registry changes or administrator settings are required.

The repair was installed successfully from the exact affected extracted folder. The previously missing torch header exists, pip check found no broken requirements, all 54 tests passed through the repaired environment, and torch/torchvision/Streamlit/Ultralytics imports succeeded. Normal run.bat startup returned HTTP 200 from the Streamlit health endpoint. The failed local .venv was retained and is no longer used by that copy. Model integrity was verified again.

## Site reporting edition verification — 16 October 2026

- All 30 project Python files parse. All 73 offline regression tests passed in the existing tested Windows Python 3.13 private environment; no new Python dependencies were added.
- Added tests cover private tracking, persisted follow-ups, password setup, salted password verification, expiring sessions, logout, failed-login throttling, admin authorization, deletion, reopening only for newer wet reports, dry resets, unknown observations, reused-photo suppression, one-level escalation without compounding, and an incomplete base assessment remaining unassigned.
- EXIF GPS/date hints were tested using a generated JPEG. Saved previews are explicitly stripped of EXIF; a regression test checks that GPS does not survive PNG conversion. Default survey time remains stable across reruns.
- The real browser completed a synthetic photo upload, manual map tagging, pin confirmation, real model inference, complete live survey-date weather, consent, SQLite persistence, and private receipt creation in an isolated test database. Synthetic images produced no detections; this is execution evidence, not an accuracy measurement.
- A separate synthetic repeat-survey case rendered the admin map/queue, a four-day observation timeline, original photo comparison, and the Low-to-Medium follow-up explanation. These synthetic reports are outside the deliverable and never added to the user's report database.
- Live Open-Meteo checks returned a complete 72-hour window for a 30-day-old survey and a complete 96-hour rainfall interval between test visits. Both used a generic Dhaka test point, not device location.
- A standalone map-bridge harness checked opt-in behavior, denied geolocation, one request per upload, manual fallback, Bangladesh bounds, safe popup text, and marker selection. Real device location permission was not accepted by the agent.
- The model SHA-256 remains the original value. Private runtime data and admin setup/credentials are excluded from the ZIP; each packaged source file is checked against SHA256SUMS.txt.

This release is a local prototype, not a public HTTPS service. Mobile layout checks use browser viewport emulation, not a physical phone. No formal accessibility certification, penetration test, new model evaluation, or scientific calibration of the three-day follow-up rule is claimed. The local SQLite database is not encrypted at rest; protect the computer and the .local folder. A camera GPS hint or confirmed site pin is not a georeferenced coordinate for every detected object. Repeated water reports and rainfall do not prove continuous water retention.

Final browser pass: the password-gated dashboard rendered its map and queue, live rainfall chart, survey comparisons, and a saved inspection note. Rainfall output survived the note-save rerun. The public map/form was checked at 390 x 844; body and document widths were both 390px. No browser console errors were captured in the isolated QA tab. The viewport override was restored. These are browser-emulated checks; permission-denial behavior was exercised by the map harness rather than accepting the computer's real location permission.

## Minimal interface verification — 18 October 2026

The existing 73 regression tests passed after adding the mosquito logo/favicon and moving supporting controls into expandable sections. The main action, observation state, privacy consent, and admin gating remain covered by the existing interface tests. Authored action text contrast is 4.92:1; secondary text on the page is 6.23:1. This revision changes presentation only; the model and risk rules are unchanged.

Final responsive pass: 11 interface smoke tests passed after the responsive action placement. Browser checks confirmed one visible Analyze action on desktop and mobile, accessible expandable observation controls, and a 390px document width at a 390px viewport. Previews were saved and the viewport override was restored.

## Requested fixes verification — 18 October 2026

All 80 offline regression tests passed. Added checks cover readable place labels, lookup caching and coordinate rounding without pin changes, invalid-country responses, code-and-password login, short-password override isolation, token revocation, permanently visible observation fields, and the reduced tracking form. A live lookup with a generic public Dhaka-area point returned an area/city/country label. Browser checks verified map reveal, pin-to-area updates, stacked native upload controls, and the simplified tracking landing. The map bridge harness passed compact-map reveal/collapse as well as consent, denied-location fallback, bounds, safe labels, and marker selection. The agent did not accept device-location permission.


## Compact upload verification — 18 October 2026

All 80 current regression tests passed. The retired area-search test was replaced with an automatic photo-GPS test covering precise coordinates, area naming, stale component events, photo count, and removal of old GPS when the next batch has none. The browser accepted two generated GPS JPEGs without saving a report; the readable name populated and both filenames/count remained inside the upload box. The map bridge passed always-visible toolbar-free rendering. No real device-location permission was requested.


Follow-up adjustment: removed the site-pin confirmation checkbox and split upload details from the photo-count panel. All 14 affected public/tracking interface tests passed; GPS/map pin validation remains required.


Automatic location correction: photo GPS is preferred; uploads without GPS automatically request browser geolocation permission, with no checkbox or location toolbar. Device results fill the area/map and are labelled as upload locations, not capture coordinates. Denied and successful location responses were exercised in the JavaScript harness; Streamlit tests verify the request and area update. Real device permission was not accepted by the agent.


Balanced layout: all 15 affected interface tests passed, including count/weather table rendering and five Unavailable rows for absent weather. Browser DOM measurements found both public panels to be 301.5px wide and 240px high at the current viewport. Synthetic results were rendered in an isolated temporary preview without writing to the report database.


Tracking button removal: all 9 reporting-interface checks passed, including private-code lookup and follow-up routing without a lookup button.


Tracking clarification: Open my report is available for the initial lookup, then disappears after a successful open. Follow-up and report history remain. Changing the code clears the open report and restores the lookup button. All 9 reporting-interface tests passed, including click-to-open, hidden button after open/rerun, and follow-up routing. This supersedes the earlier automatic-lookup behavior.


Admin card release: all 83 regression tests passed. Tests cover explicit card navigation, status and effective-priority counts, priority updates, automatic-priority restoration, authorization, transactional persistence, audit notes and unchanged automated risk results. Browser checks used an isolated synthetic database and verified View site, the editing form and a saved inspection comment. A SQLite backup of each existing local database was saved under work/db-backups before the additive storage change. No synthetic records were added to the user database.


Compact admin controls: all 83 regression tests passed after replacing the matrix with four priority totals and using native selection-only dropdowns. The browser filtered synthetic records by Resolved, changed a priority inside the inspection form, saved a comment, and confirmed both the saved priority and updated count. The native controls expose select/options rather than a text input. Synthetic tests stayed outside the user report database.


Focused detail view: all 10 reporting-interface tests passed. Checks confirm that opening a card hides the global totals and Admin Access title, retains site editing, and returns to the card overview before sign-out.


Delete button: all 11 reporting-interface tests passed. A temporary-database test clicks the final Delete button, verifies the selected tracking code no longer opens a report, preserves another report, and verifies return to the site cards. No real user report was deleted during testing.


All-sites admin map: all 12 reporting-interface checks passed. A temporary-store regression verifies open and resolved sites are supplied to the map even when an Inspected card filter yields no results. The map expander defaults to collapsed.


The map bridge now retains a minimum usable frame height when its Streamlit expander is initially hidden, and refits all site markers when the map becomes visible. The standalone bridge harness checks the hidden-parent height fallback as well as existing bounds, marker selection and automatic-location behavior.


Automatic-name regression: reproduced the blank text-widget state before the fix. All 20 affected interface tests passed afterward, covering restoration without another lookup, removal of stale names after a pin move, successful retry after a simulated lookup outage, and existing analysis/tracking behavior. A live generic Dhaka-area lookup returned Nalbhog, Dhaka, Bangladesh; it was not the user device location.


Completion flow: all 15 reporting-interface tests passed, including a saved synthetic report reaching the thank-you screen through Done, remaining a single observation, and returning to a fresh form.


Update-source styling: all 15 reporting-interface tests passed. Existing admin-edit checks now verify distinct report/admin markup and that script-like note text stays escaped. Synthetic history was used for visual verification.
