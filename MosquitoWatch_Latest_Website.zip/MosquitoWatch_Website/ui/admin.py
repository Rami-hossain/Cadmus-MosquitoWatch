from html import escape

import streamlit as st

from services.history import followup_priority
from services.choice_widget import select_choice
from services.map_widget import site_map
from services.store import STATUSES, PRIORITIES
from ui.cases import render_history
from ui.results import local_time


def render_admin(store):
    token = st.session_state.get("admin_token")
    selected = st.session_state.get("admin_selected_site")
    if token and selected:
        try:
            render_site_details(store, token, selected)
        except PermissionError:
            st.session_state.pop("admin_token", None)
            st.session_state.pop("admin_selected_site", None)
            st.rerun()
        return
    st.title("Admin Access")
    if not store.configured():
        st.write("Set up admin access on this computer. Public uploaders cannot read the setup code.")
        st.info("Open the local file .local/admin_setup_code.txt inside the project folder. Copy its code here, then choose your admin password. Keep the project’s .local folder private.")
        with st.form("admin_setup", clear_on_submit=True):
            code = st.text_input("Local setup code", type="password")
            access_code = st.text_input("Choose admin code",type="password",max_chars=128)
            password = st.text_input("Choose admin password (at least 12 characters)", type="password", max_chars=200)
            confirm = st.text_input("Confirm admin password", type="password", max_chars=200)
            if st.form_submit_button("Create admin access", type="primary"):
                if password != confirm:
                    st.warning("The passwords do not match.")
                else:
                    try:
                        store.setup_admin(code, password, access_code=access_code)
                        st.session_state["admin_token"] = store.login(password,access_code)
                        st.rerun()
                    except (ValueError, PermissionError) as exc:
                        st.warning(str(exc))
        return
    if not token:
        with st.form("admin_login", clear_on_submit=True):
            access_code = st.text_input("Admin code",type="password",max_chars=128)
            password = st.text_input("Admin password", type="password", max_chars=200)
            if st.form_submit_button("Sign in", type="primary"):
                token = store.login(password,access_code)
                if token:
                    st.session_state["admin_token"] = token
                    st.session_state.pop("admin_selected_site", None)
                    st.rerun()
                else:
                    st.warning("Sign-in failed. Check the password; after five failed attempts wait one minute.")
        return
    try:
        cases = store.summaries(token)
    except PermissionError:
        st.session_state.pop("admin_token", None)
        st.rerun()
    if st.button("Sign out", key="admin_logout"):
        store.logout(token)
        st.session_state.pop("admin_token", None)
        st.session_state.pop("admin_selected_site", None)
        st.rerun()
    if st.session_state.pop("admin_site_deleted", False):
        st.success("Site deleted.")
    st.caption("Private admin dashboard · priorities describe the latest survey date · field verification required")
    for case in cases:
        case["decision"] = followup_priority(case["observations"])
    for case in cases:
        case["queue_priority"] = case.get("admin_priority") or case["decision"]["level"]
    active = [case for case in cases if case["status"] != "Resolved"]
    metrics = [("Open sites",len(active)),
               ("Awaiting first visit",sum(c["status"]=="New" for c in active)),
               ("Resolved",len(cases)-len(active))]
    st.markdown('<dl class="mw-dashboard-counts mw-admin-status-counts">' + ''.join(f'<div><dt>{label}</dt><dd>{value}</dd></div>' for label,value in metrics) + '</dl>', unsafe_allow_html=True)
    with st.container(border=True, key="admin_priority_overview"):
        st.subheader("Inspection priorities")
        counts=[(label,sum(c["queue_priority"]==level for c in cases)) for label,level in [("High","HIGH"),("Medium","MEDIUM"),("Low","LOW"),("Unassigned",None)]]
        st.markdown('<dl class="mw-priority-counts" aria-label="Site counts by priority">'+''.join(f'<div><dt>{label}</dt><dd>{count}</dd></div>' for label,count in counts)+'</dl>',unsafe_allow_html=True)
        st.caption("Site totals across all statuses.")
    status_col, priority_col, search_col = st.columns([1,1,1.4])
    with status_col:
        status_filter = select_choice("Workflow status", ["Open sites", "All statuses", *STATUSES], key="admin_status_filter")
    with priority_col:
        priority_filter = select_choice("Inspection priority", ["All priorities", "HIGH", "MEDIUM", "LOW", "Unassigned"], format_func=lambda value:value.title() if value in PRIORITIES else value, key="admin_priority_filter")
    with search_col:
        search = st.text_input("Find an area or site ID", max_chars=160)
    filtered = [c for c in cases if (status_filter=="All statuses" or (status_filter=="Open sites" and c["status"]!="Resolved") or c["status"]==status_filter)
                and (priority_filter=="All priorities" or c["queue_priority"]==priority_filter or (priority_filter=="Unassigned" and c["queue_priority"] is None))
                and (not search or search.casefold() in (c["area"]+c["id"]).casefold())]
    rank={"HIGH":0,"MEDIUM":1,"LOW":2,None:3}
    filtered.sort(key=lambda c:(rank[c["queue_priority"]], c["created_at"]))
    st.subheader("Sites to review")
    with st.expander("View sites on map", expanded=False):
        selected_map=site_map(key="admin_sites_map",markers=[{**{k:c[k] for k in ("id","area","latitude","longitude","status")},"level":c["queue_priority"]} for c in cases])
        st.caption(f"{len(cases)} reported sites · all statuses, including resolved. Select a marker to open its details.")
        ids={c["id"] for c in cases}
        if selected_map and selected_map.get("selected_id") in ids and selected_map != st.session_state.get("admin_consumed_map"):
            st.session_state["admin_consumed_map"]=selected_map
            select_site(selected_map["selected_id"])
            st.rerun()

    if not filtered:
        st.info("No sites match these filters. New public submissions will appear here after they are saved.")
        return
    st.caption(f"{len(filtered)} sites · ordered by inspection priority")
    for number, case in enumerate(filtered,1):
        with st.container(border=True,key="admin_site_card_"+case["id"]):
            body, action = st.columns([4,1])
            with body:
                level=case["queue_priority"]
                css=level.lower() if level else "incomplete"
                st.markdown(f'<div class="mw-site-card-heading"><span class="mw-site-number">{number}</span><strong>{escape(case["area"])}</strong><span class="mw-badge mw-card-{css}">{level.title() if level else "Unassigned"}</span></div>',unsafe_allow_html=True)
                latest=case["observations"][-1] if case["observations"] else None
                st.caption(case["status"]+" · Site "+case["id"]+(" · Admin-set priority" if case.get("admin_priority") else ""))
                if latest:
                    objects=sum(latest["result"].get("counts",{}).values())
                    visits=len(case["observations"])
                    st.caption(f'{local_time(latest["observed_at"])} · {latest["water"]} · {objects} object detection{"s" if objects!=1 else ""} · {visits} survey visit{"s" if visits!=1 else ""}')
            with action:
                st.button("View site →", key="admin_open_"+case["id"], on_click=select_site,args=(case["id"],))


def select_site(site_id):
    st.session_state["admin_selected_site"] = site_id


def back_to_sites():
    st.session_state.pop("admin_selected_site",None)


def render_site_details(store, token, selected):
    st.button("← Back to sites",on_click=back_to_sites,key="admin_back_to_sites")
    case=store.admin_case(token,selected)
    if not case:
        st.warning("This site was removed. Return to the site list.")
        return
    st.title(case["area"])
    st.caption("Site " + selected)
    if st.session_state.pop("admin_update_saved",False):
        st.success("Inspection update saved.")
    st.subheader("Inspection decision & comments")
    st.caption("Your priority is an admin decision. The original object/weather assessment remains in the survey history.")
    with st.form("inspection_update_"+selected, clear_on_submit=True):
        status_col,priority_col=st.columns(2)
        with status_col:
            status=select_choice("Status",STATUSES,index=STATUSES.index(case["status"]),key="admin_status_"+selected)
        with priority_col:
            options=["Automatic",*PRIORITIES]
            current=case.get("admin_priority") or "Automatic"
            priority=select_choice("Admin inspection priority",options,index=options.index(current),format_func=lambda v:"Use automated assessment" if v=="Automatic" else v.title(),key="admin_priority_"+selected)
        note=st.text_area("Inspection notes",max_chars=2000,placeholder="Record what was checked, action taken, and any follow-up needed.",key="admin_note_"+selected)
        if st.form_submit_button("Save inspection update",type="primary"):
            try:
                store.update_site(token,selected,status,note,priority=None if priority=="Automatic" else priority)
                st.session_state["admin_update_saved"]=True
                st.rerun()
            except (ValueError,PermissionError) as exc:
                st.warning(str(exc))
    st.divider()
    render_history(case,show_map=True,show_heading=False)
    st.divider()
    with st.container(key="admin_delete_action"):
        if st.button("Delete",key="delete_site_"+selected):
            store.delete_site(token,selected)
            back_to_sites()
            st.session_state["admin_site_deleted"] = True
            st.rerun()
