from datetime import datetime, time, timezone
import json
import logging
import secrets
import time as clock_time
from pathlib import Path

import streamlit as st

from services.analysis import MAX_BATCH_BYTES, MAX_IMAGES, SurveyImage, analyze_images, input_signature
from services.location import reverse_location
from services.history import followup_priority
from services.map_widget import site_map, valid_pin
from services.photo_metadata import photo_metadata
from services.weather import BD_TIME
from ui.results import render_result

LOGGER = logging.getLogger(__name__)


def reset_public():
    for key in list(st.session_state):
        if key.startswith(("survey_", "report_", "location_", "matched_", "public_")) or key == "analysis":
            del st.session_state[key]


def finish_report():
    if st.session_state.get("report_saved_key") and st.session_state.get("report_receipt"):
        st.session_state["public_submission_done"] = True


def render_thank_you():
    logo = (Path(__file__).resolve().parents[1]/"assets/mosquito.svg").read_text(encoding="utf-8").replace('<svg ', '<svg aria-hidden="true" ')
    st.markdown('<section class="mw-thank-you" role="status" aria-live="polite"><div class="mw-thank-you-brand">'+logo+'<strong>MosquitoWatch</strong></div><h1>Thank you for submitting a report.</h1></section>',unsafe_allow_html=True)
    _, action, _ = st.columns([1,1,1])
    with action:
        st.button("Report another site",on_click=reset_public,use_container_width=True,key="thank_you_new_report")


def render_public(store, get_model, get_locations, get_weather):
    if st.session_state.get("public_submission_done"):
        render_thank_you()
        return
    nonce = st.session_state.setdefault("public_map_nonce", secrets.token_hex(6))
    followup_code = st.session_state.get("public_followup_code")
    case = store.case(followup_code) if followup_code else None
    if followup_code and not case:
        st.session_state.pop("public_followup_code", None)
        st.warning("This site is no longer available. Start a new report.")
    st.title("Plan the next inspection.")
    st.markdown('<p class="mw-intro">Upload photos. Review the location. See its inspection priority.<br><span lang="bn">ছবি দিন, স্থান চিহ্নিত করুন, অগ্রাধিকার দেখুন।</span></p>', unsafe_allow_html=True)
    if case:
        st.info(f'Follow-up for site {case["id"]} · {case["area"]}. This upload will join its existing timeline.')
        st.button("Start a different site / নতুন স্থান", on_click=reset_public)
    left, right = st.columns(2, gap="large")
    with left:
        st.subheader("Photos / ছবি")
        with st.container(key="photo_upload_box"):
            uploaded = st.file_uploader("Photos from one site / একই স্থানের ছবি", type=["jpg", "jpeg", "png", "webp"], accept_multiple_files=True, key="survey_uploads_"+nonce, label_visibility="collapsed")
        count = len(uploaded or [])
        with st.container(key="photo_uploaded_count"):
            st.caption(f"{count} photo{'s' if count != 1 else ''} uploaded · Up to 10 from one site")
    uploads = [SurveyImage(item.name, item.getvalue()) for item in (uploaded or [])]
    batch_key = input_signature(uploads, "")
    # Metadata is a hint only. Never persist original EXIF or adopt capture dates silently.
    metadata = [photo_metadata(item.data) for item in uploads[:MAX_IMAGES]] if sum(len(u.data) for u in uploads) <= MAX_BATCH_BYTES else []
    gps = [(i, info) for i, info in enumerate(metadata) if "latitude" in info]
    map_key = "public_location_map_"+nonce
    if not case and batch_key != st.session_state.get("public_photo_batch"):
        st.session_state["public_photo_batch"] = batch_key
        st.session_state["public_consumed_map"] = st.session_state.get(map_key)
        st.session_state["public_gps_selected"] = gps[0][0] if gps else None
        st.session_state["public_pin_confirmed"] = False
        if gps:
            info = gps[0][1]
            st.session_state["public_pin"] = {"latitude":info["latitude"], "longitude":info["longitude"], "source":"Photo GPS"}
        elif st.session_state.get("public_pin", {}).get("source") in {"Photo GPS", "Device location"}:
            # Never reuse the previous photo/device position for an unrelated batch.
            st.session_state.pop("public_pin", None)
            st.session_state.pop("public_name_pin_key", None)
            st.session_state["survey_area"] = ""
            st.session_state["public_area_label"] = ""
    with right:
        pending_pin = st.session_state.get(map_key)
        if not case and valid_pin(pending_pin) and pending_pin != st.session_state.get("public_consumed_map"):
            st.session_state["public_pin"] = pending_pin
            st.session_state["public_consumed_map"] = pending_pin
            st.session_state["public_pin_confirmed"] = False
        active_pin = ({"latitude":case["latitude"],"longitude":case["longitude"],"source":"Saved site"} if case else st.session_state.get("public_pin"))
        if active_pin and not case:
            point = (float(active_pin["latitude"]),float(active_pin["longitude"]))
            resolved = st.session_state.get("public_resolved_area", {})
            has_name = resolved.get("point") == point and bool(resolved.get("label"))
            changed = point != st.session_state.get("public_name_pin_key")
            retry = not has_name and not st.session_state.get("survey_area", "").strip() and (
                st.session_state.get("analyze_area") or clock_time.monotonic()-st.session_state.get("public_name_attempt_at",0) >= 15)
            if changed or retry:
                st.session_state["public_name_pin_key"] = point
                st.session_state["public_name_attempt_at"] = clock_time.monotonic()
                if changed:
                    st.session_state["survey_area"] = ""
                    st.session_state["public_area_label"] = ""
                try:
                    with st.spinner("Finding the area name…"):
                        label = reverse_location(*point).strip()
                        if not label:
                            raise ValueError("Empty area-name response")
                        st.session_state["public_resolved_area"] = {"point":point,"label":label}
                        st.session_state["survey_area"] = label
                    st.session_state["public_name_unavailable"] = False
                except Exception:
                    LOGGER.warning("Area-name lookup unavailable; site pin retained")
                    st.session_state["public_name_unavailable"] = True
            resolved = st.session_state.get("public_resolved_area", {})
            if resolved.get("point") == point and resolved.get("label") and not st.session_state.get("survey_area", "").strip():
                st.session_state["survey_area"] = resolved["label"]
                st.session_state["public_name_unavailable"] = False
        st.subheader("Location / স্থান")
        if "survey_area" not in st.session_state and st.session_state.get("public_area_label"):
            st.session_state["survey_area"] = st.session_state["public_area_label"]
        area_name = st.text_input("Area or location in Bangladesh", value=case["area"] if case else "", placeholder="Area name appears automatically", max_chars=160, key="survey_area", disabled=bool(case), label_visibility="collapsed")
        st.session_state["public_area_label"] = area_name
        pin = ({"latitude":case["latitude"], "longitude":case["longitude"], "source":"Saved site"}
               if case else st.session_state.get("public_pin"))
        if gps and not case:
            if len(gps) > 1:
                chosen = st.selectbox("Photo location / ছবির অবস্থান", [i for i,_ in gps],
                                      format_func=lambda i:uploads[i].name, key="public_gps_choice_"+batch_key)
                info = metadata[chosen]
                point = {"latitude":info["latitude"], "longitude":info["longitude"], "source":"Photo GPS"}
                if chosen != st.session_state.get("public_gps_selected"):
                    st.session_state["public_gps_selected"] = chosen
                    st.session_state["public_pin"] = point
                    st.session_state["public_pin_confirmed"] = False
                    st.rerun()
            if any(abs(info["latitude"]-gps[0][1]["latitude"]) > .001 or abs(info["longitude"]-gps[0][1]["longitude"]) > .001 for _,info in gps):
                st.warning("These photos have different GPS positions. Submit separate reports for different sites.")
            st.caption("Photo GPS marks the camera/drone position. Check the site pin.")
        elif uploads and not case:
            if not pin:
                st.caption("No GPS found in these photos. Allow the browser location request to fill your upload location automatically.")
            elif pin["source"] == "Device location":
                st.caption("Using this device’s upload location. It may differ from where the drone photo was taken.")
        location_value = site_map(key=map_key, pin=pin, editable=not bool(case),
                                  reset_id=(followup_code or "new")+batch_key, controls=False, height=240,
                                  request_id=batch_key if uploads else "",
                                  request_location=bool(uploads and not gps and not pin and not case))
        if not case and valid_pin(location_value) and location_value != st.session_state.get("public_consumed_map"):
            if location_value != st.session_state.get("public_pin"):
                st.session_state["public_pin_confirmed"] = False
            pin = location_value
            st.session_state["public_pin"] = pin
            st.session_state["public_consumed_map"] = location_value
            st.rerun()
        if pin:
            st.caption({"Device location":"Upload location · device position", "Photo GPS":"Photo location · GPS metadata", "Map pin":"Site location · selected pin", "Saved site":"Saved site location"}.get(pin["source"],"Site location"))
            if st.session_state.get("public_name_unavailable"):
                st.info("The map location is ready. Area-name lookup is temporarily unavailable; retry here or click Analyze Area to try again automatically.")
                if st.button("Retry area name",key="retry_area_name"):
                    st.session_state.pop("public_name_pin_key",None)
                    st.rerun()
            st.caption("Area names: [© OpenStreetMap contributors](https://www.openstreetmap.org/copyright) via Photon.")
    now = datetime.fromisoformat(st.session_state.setdefault("public_default_datetime", datetime.now(BD_TIME).isoformat()))
    with st.container(border=True, key="observation_details"):
        st.subheader("Observation details / পর্যবেক্ষণের তথ্য")
        water_col, date_col, time_col = st.columns([2,1,1])
        with water_col:
            water = st.radio("Did you see water? / পানি দেখেছেন?", ["Unsure", "Water present", "Dry"], horizontal=True,
                format_func=lambda v: {"Unsure":"Unsure / নিশ্চিত নই", "Water present":"Water present / পানি আছে", "Dry":"Dry / শুকনো"}[v], key="survey_water")
        with date_col:
            survey_date = st.date_input("Survey date / দেখার তারিখ", value=now.date(), min_value=datetime(2020,1,1).date(), max_value=datetime.now(BD_TIME).date(),key="survey_date")
        with time_col:
            survey_time = st.time_input("Time / সময় (Bangladesh)",value=time(now.hour,now.minute),key="survey_time")
        notes = st.text_area("Site details / স্থানের বিবরণ",placeholder="Example: uncovered drum beside the north gate",max_chars=2000,key="survey_notes")
    hints = [m["capture_time_hint"] for m in metadata if "capture_time_hint" in m]
    if hints:
        st.info("Photo metadata suggests " + datetime.fromisoformat(hints[0]).strftime("%d %b %Y, %H:%M") + ". This may have a different camera timezone. Confirm the survey date and time above.")
        if len({hint[:10] for hint in hints}) > 1:
            st.warning("Photo metadata includes different capture dates. Submit different survey visits separately so their timeline remains meaningful.")
    observed = datetime.combine(survey_date, survey_time, tzinfo=BD_TIME)
    signature = input_signature(uploads, area_name)
    context = json.dumps({"pin":pin, "water":water, "observed":observed.isoformat(), "notes":notes, "case":case["id"] if case else None}, sort_keys=True)
    analyze = st.button("Analyze Area",type="primary",key="analyze_area")
    if analyze:
        if not uploads:
            st.warning("Upload at least one drone image or phone photo before analyzing the area.")
        elif len(uploads) > MAX_IMAGES or sum(len(u.data) for u in uploads) > MAX_BATCH_BYTES:
            st.warning("Use at most 10 photos and keep the total below 100 MB.")
        elif not valid_pin(pin):
            st.warning("Waiting for location. Allow location access in your browser; the area and map will fill automatically. Photo GPS can also supply the location. / ব্রাউজারে অবস্থানের অনুমতি দিন।")
        elif observed > datetime.now(BD_TIME):
            st.warning("The survey date and time cannot be in the future.")
        elif not area_name.strip():
            st.warning("The automatic area-name lookup has not finished. Check the connection and click Analyze Area to retry; your map pin is retained.")
        else:
            try:
                with st.status("Reviewing photos and survey-date weather…", expanded=True) as status:
                    model = get_model()
                    try:
                        weather = get_weather(pin["latitude"], pin["longitude"], observed.astimezone(timezone.utc).strftime("%Y-%m-%dT%H"))
                    except Exception:
                        LOGGER.warning("Survey-date weather unavailable; no priority assigned")
                        weather = None
                    bar = st.progress(0, text="Analyzing photos…")
                    result = analyze_images(uploads, model, weather, progress=lambda done,total:bar.progress(done/total, text=f"Reviewed {done} of {total}"))
                    result.update(location={"display_name":area_name.strip(),"latitude":pin["latitude"],"longitude":pin["longitude"]},
                                  signature=signature, context=context, observed_at=observed.isoformat(), water=water,
                                  notes=notes, location_source=pin["source"], submission_key=secrets.token_hex(24), followup_code=followup_code)
                    st.session_state["analysis"] = result
                    status.update(label="Review ready — submit below when you are satisfied", state="complete", expanded=False)
            except Exception:
                LOGGER.exception("Photo analysis failed")
                st.error("The detector could not finish. Restart with run.bat and retry. Your previous report is retained.")
    result = st.session_state.get("analysis")
    if result:
        stale = result["signature"] != signature or ("context" in result and result["context"] != context)
        if result.get("observed_at"):
            label = "Historical assessment" if (datetime.now(BD_TIME)-datetime.fromisoformat(result["observed_at"])).total_seconds() > 86400 else "Survey observation"
            st.caption(label + " · " + datetime.fromisoformat(result["observed_at"]).strftime("%d %b %Y, %H:%M") + " Bangladesh time")
        is_latest = case and result.get("observed_at") and (not case["observations"] or datetime.fromisoformat(result["observed_at"]) >= datetime.fromisoformat(case["observations"][-1]["observed_at"]))
        decision = followup_priority([*case["observations"], {"observed_at":result["observed_at"],"water":result["water"],"result":result}]) if is_latest else None
        render_result(result, stale=stale, decision=decision)
        if result.get("submission_key"):
            st.subheader("3. Send to the inspection queue / প্রতিবেদন জমা দিন")
            consent = st.checkbox("Save these photos, site location, and observations in private cloud storage for admin review / পরিদর্শনের জন্য সংরক্ষণে সম্মতি", key="report_save_consent")
            already_saved = st.session_state.get("report_saved_key") == result["submission_key"]
            if st.button("Submit site report / প্রতিবেদন জমা দিন", type="primary", disabled=stale or not consent or already_saved, key="submit_site"):
                try:
                    site_id, tracking = store.submit(area=result["location"]["display_name"], latitude=result["location"]["latitude"], longitude=result["location"]["longitude"],
                        location_source=result["location_source"], observed_at=result["observed_at"], water=result["water"], notes=result["notes"],
                        result=result, tracking_code=result.get("followup_code"), submission_key=result["submission_key"])
                    st.session_state.update(report_saved_key=result["submission_key"], report_receipt={"site_id":site_id,"tracking":tracking})
                    st.rerun()
                except (ValueError, PermissionError) as exc:
                    st.warning(str(exc))
                except Exception:
                    LOGGER.exception("Report save failed")
                    st.error("The report could not be saved. Please retry; if this continues, ask the administrator to check cloud storage and quota.")
            receipt = st.session_state.get("report_receipt")
            if already_saved and receipt:
                st.success("Saved for admin review / প্রশাসকের পর্যালোচনার জন্য সংরক্ষিত। Site " + receipt["site_id"])
                st.write("Keep this private tracking code. Anyone holding it can view and add observations to this site.")
                st.code(receipt["tracking"], language=None)
                st.download_button("Save tracking receipt", f'MosquitoWatch site {receipt["site_id"]}\nPrivate tracking code: {receipt["tracking"]}\nKeep this code private. Use Track a report for follow-ups.\n', "MosquitoWatch_tracking_receipt.txt")
                st.button("Done",type="primary",on_click=finish_report,key="report_done")
                st.button("Report another site / অন্য স্থানের প্রতিবেদন", on_click=reset_public)
