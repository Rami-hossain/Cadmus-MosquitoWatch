from datetime import datetime
from html import escape
import streamlit as st
from reports.bangla_report import build_bangla_report
from reports.export import build_text_report
from services.detector import DISPLAY_NAMES
from services.weather import BD_TIME

def bangla_list(items: list[str]):
    st.markdown('<ul class="mw-guidance" lang="bn">' + "".join("<li>" + escape(item) + "</li>" for item in items) + "</ul>", unsafe_allow_html=True)


def local_time(value: str) -> str:
    return datetime.fromisoformat(value).astimezone(BD_TIME).strftime("%d %b %Y, %I:%M %p")


def summary_table(label, first_heading, second_heading, rows):
    body = "".join(f'<tr><th scope="row">{escape(str(name))}</th><td>{escape(str(value))}</td></tr>' for name, value in rows)
    st.markdown(f'<table class="mw-summary-table" aria-label="{escape(label)}"><thead><tr><th scope="col">{escape(first_heading)}</th><th scope="col">{escape(second_heading)}</th></tr></thead><tbody>{body}</tbody></table>', unsafe_allow_html=True)


def render_result(result: dict, *, stale: bool, decision=None):
    st.divider()
    st.header("Survey results" if not stale else "Previous survey results")
    st.write(result["location"]["display_name"])
    st.caption("Analyzed " + local_time(result["created_at"]) + " · Bangladesh time")
    if stale:
        st.warning("The images or location have changed. This is the previous report; click Analyze Area for the current survey.")
    if result.get("partial_coverage"):
        st.warning("Provisional result: some images were excluded or could not be analyzed. Priority applies only to usable images. Capture replacement images to complete the survey.")
    risk = dict(result["risk"])
    if decision and decision.get("raised"):
        risk["risk_level"] = decision["level"]
        risk["inspection_priority"] = "Priority field inspection" if decision["level"] == "HIGH" else "Inspection recommended"
        risk["followup_raised"] = True
    bn = build_bangla_report(result["counts"], result["weather"], risk, result["location"]["display_name"])
    if risk["status"] == "OK":
        level = risk["risk_level"].lower()
        heading = risk["risk_level"].title() + " inspection priority"
        message = {"high": "Inspect the identified objects first and check for standing water.",
                   "medium": "Arrange a field inspection and check places where water may collect.",
                   "low": "Continue routine monitoring. A low priority does not confirm the area is free of breeding sites."}[level]
        badge = "Provisional priority" if result["partial_coverage"] else "Inspection priority"
    else:
        level, heading, badge = "incomplete", "Unable to assign inspection priority", "Incomplete assessment"
        message = "Use clearer images and retry." if risk.get("cause") == "images" else "The complete recent weather is unavailable. Image detections are shown below; retry Analyze Area to complete the assessment."
    st.markdown(f'<section class="mw-priority mw-{level}" role="status" aria-live="polite"><span class="mw-badge">{badge}</span><h2>{heading}</h2><p class="bn" lang="bn">{escape(bn["headline"])}</p><p>{message}</p></section>', unsafe_allow_html=True)
    st.caption("Screening support only. The model detects potential breeding-risk objects; it does not directly detect mosquitoes, larvae, or dengue. Field verification is required.")
    if decision and decision.get("raised"):
        st.info(f'Raised once from {decision["base_level"].title()} under the prototype follow-up rule: water reported on distinct-photo visits at least 3 days apart. Continuous water presence is unconfirmed.')
        bangla_list(["ভিন্ন ছবিসহ অন্তত তিন দিনের ব্যবধানে পানি থাকার তথ্য পাওয়ায় অগ্রাধিকার এক ধাপ বেড়েছে। একটানা পানি থাকার প্রমাণ নয়।"])
    st.markdown(f'<div class="mw-coverage">{result["usable_images"]} of {result["submitted_images"]} uploaded images analyzed · {result["duplicate_images"]} duplicate images skipped</div>', unsafe_allow_html=True)

    objects_col, weather_col = st.columns(2, gap="large")
    with objects_col:
        st.subheader("Detected objects")
        order = ["tire", "water_tank", "drum", "other_containers", "cocunut_shell"]
        summary_table("Detected objects", "Object", "Count",
                      [(DISPLAY_NAMES[key], str(result["counts"].get(key, 0))) for key in order])
        st.caption("Detections in usable images. Overlapping views may count the same object more than once.")
        if sum(result["counts"].values()) == 0 and result["usable_images"]:
            st.info("No target objects were detected in the usable images. Small, hidden, or missed objects may still be present.")
        if len(result["images"]) > 1:
            st.caption("Use separate, non-overlapping views of one area. Counts are not adjusted for survey size.")
    with weather_col:
        st.subheader("Weather / আবহাওয়া")
        weather = result.get("weather")
        rows = [
            ("Precipitation, 72 hours", f'{weather["total_rainfall_mm"]:.1f} mm' if weather else "Unavailable"),
            ("Average temperature", f'{weather["avg_temperature_c"]:.1f} °C' if weather else "Unavailable"),
            ("Average humidity", f'{weather["avg_humidity_percent"]:.0f}%' if weather else "Unavailable"),
            ("Period starts", local_time(weather["start_time"]) if weather else "Unavailable"),
            ("Period ends", local_time(weather["end_time"]) if weather else "Unavailable"),
        ]
        summary_table("Survey-date weather", "Weather detail", "Value", rows)
        if weather:
            st.caption("Bangladesh time; period end excluded. The last 72 completed hourly intervals.")
            st.caption("Source: [Open-Meteo](https://open-meteo.com/), weather model estimates for the area, rather than measurements at each object.")
        else:
            st.warning("Recent weather is incomplete or unavailable. Check your internet connection and click Analyze Area to retry. No priority has been assigned.")

    why, action = st.columns(2, gap="large")
    with why:
        st.subheader("Why this priority / কারণ")
        bangla_list(bn["reasons"])
    with action:
        st.subheader("Recommended actions / করণীয়")
        bangla_list(bn["actions"])
        if result["partial_coverage"]:
            bangla_list(["বাদ পড়া ছবির স্থানগুলোতে আবার পরিষ্কার ছবি তুলুন; এই মূল্যায়ন পুরো এলাকার প্রতিনিধিত্ব করে না।"])

    st.download_button("Download survey report", data=build_text_report({**result, "followup":decision}).encode("utf-8-sig"), file_name="MosquitoWatch_survey_report.txt", mime="text/plain; charset=utf-8", key="download_report")
    st.subheader("Image review")
    st.caption("Boxes mark detected objects. Images excluded from scoring are identified below.")
    for index, image in enumerate(result["images"]):
        st.markdown('<p class="mw-file">' + escape(image["name"]) + '</p>', unsafe_allow_html=True)
        if image["status"] == "analyzed":
            st.caption(f'Analyzed · {sum(image["counts"].values())} potential breeding-risk object detections')
        elif image["status"] == "duplicate":
            st.info(" ".join(image["issues"]))
        else:
            st.warning("Excluded from scoring. " + " ".join(image["issues"]))
        if image["annotated_png"]:
            st.image(image["annotated_png"], caption=("Annotated survey image" if image["status"] == "analyzed" else "Excluded image — not scored"), use_container_width=True)
            if image["status"] == "analyzed":
                st.download_button("Download annotated image", data=image["annotated_png"], file_name=f"MosquitoWatch_image_{index+1}.png", mime="image/png", key=f"image_download_{index}")
