from datetime import datetime
from html import escape

import pandas as pd
import streamlit as st

from services.history import followup_priority
from services.map_widget import site_map
from services.weather import BD_TIME, fetch_rainfall_history
from ui.results import local_time, render_result


@st.cache_data(ttl=3600, max_entries=100, show_spinner=False)
def rain_between(latitude, longitude, start, end):
    return fetch_rainfall_history(latitude, longitude, datetime.fromisoformat(start), datetime.fromisoformat(end))


def priority_panel(case):
    decision = followup_priority(case["observations"])
    level = case.get("admin_priority") or decision["level"]
    css = level.lower() if level else "incomplete"
    title = level.title() + " inspection priority" if level else "Priority not assigned"
    st.markdown(f'<section class="mw-priority mw-{css}"><span class="mw-badge">{escape(case["status"])} · Site {escape(case["id"])}</span><h2>{title}</h2><p>{escape(decision.get("reason", ""))}</p></section>', unsafe_allow_html=True)
    if case.get("admin_priority"):
        st.caption("Admin-set inspection priority · automated assessment: " + (decision["level"].title() if decision["level"] else "Unassigned") + ". The automated assessment is retained separately.")
    if decision["raised"]:
        st.caption(f'Object/weather priority: {decision["base_level"].title()} → Automated follow-up priority: {decision["level"].title()}. Raised once, using the latest survey’s base assessment.')
        st.markdown('<p lang="bn">তিন দিন বা তার বেশি ব্যবধানে ভিন্ন ছবিসহ পানি থাকার তথ্য পাওয়ায় পরিদর্শনের অগ্রাধিকার এক ধাপ বাড়ানো হয়েছে। মাঝের সময়ে একটানা পানি ছিল কি না নিশ্চিত নয়।</p>', unsafe_allow_html=True)
    if decision["wet_visits"] > 1:
        elapsed = f'{decision["span_hours"]:g} hours' if decision["span_days"] < 1 else f'{decision["span_days"]:g} days'
        st.caption(f'{decision["wet_visits"]} distinct-photo wet observations · {elapsed} between the first and last in this period. This is an observation span, not confirmed water age.')
    return decision


def render_history(case, *, show_map=True, show_heading=True):
    if show_heading:
        st.subheader(case["area"])
    priority_panel(case)
    observations = case["observations"]
    if not observations:
        st.info("No observations are available for this site.")
        return
    latest = observations[-1]
    age_hours = (datetime.now(BD_TIME) - datetime.fromisoformat(latest["observed_at"])).total_seconds() / 3600
    st.caption("Latest survey: " + local_time(latest["observed_at"]) + ". Assessments describe the survey date; they do not automatically become current inspections.")
    if age_hours > 24:
        st.info("Historical assessment — the latest survey is more than 24 hours old. Arrange a new visit to check current conditions.")
    if show_map:
        site_map(key="case_map_" + case["id"], pin={"latitude":case["latitude"],"longitude":case["longitude"],"source":"Saved site"})
    st.subheader("Observation timeline / পর্যবেক্ষণের ইতিহাস")
    table = []
    for obs in observations:
        weather = obs["result"].get("weather")
        risk = obs["result"].get("risk", {})
        table.append({"Survey (Bangladesh time)":local_time(obs["observed_at"]), "Water reported":obs["water"],
            "Objects detected":sum(obs["result"].get("counts", {}).values()),
            "Rain in preceding 72 h":f'{weather["total_rainfall_mm"]:.1f} mm' if weather else "Unavailable",
            "Object/weather priority":risk.get("risk_level", "Unassigned").title() if risk.get("status")=="OK" else "Unassigned"})
    st.dataframe(table, use_container_width=True, hide_index=True)
    st.caption("Each row is an uploader’s observation. Rain estimates cover the 72 hours before that visit. Similar-looking objects are not automatically matched across photos.")
    for obs in reversed(observations):
        st.markdown('<div class="mw-timeline-entry mw-report-update"><span class="mw-dot" aria-hidden="true"></span><strong>Report submission · ' + escape(local_time(obs["observed_at"])) + '</strong><span class="mw-timeline-label">' + escape(obs["water"]) + '</span><p>' + escape(obs["notes"] or "No site notes supplied.") + '</p></div>', unsafe_allow_html=True)
    if len(observations) > 1:
        with st.expander("Rainfall between visits / দুই পর্যবেক্ষণের মাঝের বৃষ্টি"):
            st.caption("Complete hourly weather estimates for the selected visits, up to 90 days apart. Rain does not confirm a container filled or retained water.")
            first = st.selectbox("From survey", range(len(observations)-1), format_func=lambda i:local_time(observations[i]["observed_at"]), key="rain_start_"+case["id"])
            last = st.selectbox("To survey", range(first+1,len(observations)), index=len(observations)-first-2, format_func=lambda i:local_time(observations[i]["observed_at"]), key="rain_end_"+case["id"])
            interval = (observations[first]["observed_at"], observations[last]["observed_at"])
            saved_rain_key = "rain_loaded_" + case["id"]
            if st.button("Load rainfall between these visits", key="rain_load_"+case["id"]):
                try:
                    with st.spinner("Checking the complete rainfall interval…"):
                        rain = rain_between(case["latitude"],case["longitude"],*interval)
                    st.session_state[saved_rain_key] = {"interval":interval,"rows":rain}
                except Exception:
                    st.session_state.pop(saved_rain_key, None)
                    st.warning("The complete interval is unavailable. Dates must be 1 hour to 90 days apart; older data may arrive later. No missing hours have been treated as zero rain.")
            saved_rain = st.session_state.get(saved_rain_key)
            if saved_rain and saved_rain["interval"] == interval:
                frame = pd.DataFrame(saved_rain["rows"])
                # Rain timestamps close the preceding hourly interval.
                frame["Date"] = (pd.to_datetime(frame["Hour ending"], utc=True).dt.tz_convert("Asia/Dhaka")-pd.Timedelta(hours=1)).dt.floor("D")
                daily = frame.groupby("Date", sort=False)["Rainfall (mm)"].sum()
                st.metric("Estimated rainfall between visits", f'{daily.sum():.1f} mm')
                st.bar_chart(daily, color="#61D4B6")
                st.caption("Open-Meteo weather model estimates · edge days may include only part of a day. No water-duration inference is made from rainfall.")
    if case["events"]:
        st.subheader("Inspection updates")
        for event in reversed(case["events"]):
            report_update = event["status"] == "New" and event["note"] == "Reopened after a newer water-present report."
            css = "mw-report-update" if report_update else "mw-admin-update"
            source = "Report update" if report_update else "Admin update"
            heading = source + " · " + local_time(event["created_at"]) + " · " + event["status"]
            st.markdown('<div class="mw-timeline-entry '+css+'"><span class="mw-dot" aria-hidden="true"></span><strong>'+escape(heading)+'</strong><p>'+escape(event["note"] or "Status updated.")+'</p></div>',unsafe_allow_html=True)
    st.subheader("Compare survey photos / ছবি তুলনা করুন" if len(observations)>1 else "Survey photos / পর্যবেক্ষণের ছবি")
    options = range(len(observations))
    if len(observations)>1:
        a, b = st.columns(2)
        comparisons = ((a,"Earlier visit",0),(b,"Later visit",len(observations)-1))
    else:
        comparisons = ((st.container(),"Survey photo",0),)
        st.caption("Add a follow-up survey to compare visits at this site.")
    for column, name, initial in comparisons:
        with column:
            index = st.selectbox(name, options, index=initial, format_func=lambda i:local_time(observations[i]["observed_at"]), key=f'compare_{name}_{case["id"]}')
            obs = observations[index]
            st.caption(obs["water"])
            images = [image for image in obs["result"].get("images", []) if image.get("original_png") or image.get("annotated_png")]
            if images:
                photo = st.selectbox("Photo — " + name, range(len(images)), format_func=lambda i:images[i]["name"], key=f'photo_{name}_{case["id"]}')
                st.image(images[photo].get("original_png") or images[photo]["annotated_png"], use_container_width=True)
            else:
                st.caption("No usable photo preview for this visit.")
    with st.expander("Open a full survey assessment"):
        index = st.selectbox("Assessment", options, index=len(observations)-1, format_func=lambda i:local_time(observations[i]["observed_at"]), key="assessment_"+case["id"])
        obs = observations[index]
        result = dict(obs["result"])
        result.setdefault("location", {"display_name":case["area"]})
        # Old/minimal records still render a timeline even if they lack an image assessment.
        if "images" in result and "created_at" in result:
            render_result(result, stale=False, decision=followup_priority(observations[:index+1]))


def open_followup(code):
    from ui.public import reset_public
    reset_public()
    st.session_state["public_followup_code"] = code
    st.session_state["workspace"] = "Report a site"


def render_tracking(store):
    st.title("Follow the same site")
    st.write("Use your private tracking code to review the site or add another survey. No public account is required.")
    code = st.text_input("Private tracking code / ব্যক্তিগত ট্র্যাকিং কোড", type="password", max_chars=100,
                         placeholder="Paste your private tracking code", key="tracking_code").strip()
    opened = st.session_state.get("tracking_open_code")
    if opened != code:
        st.session_state.pop("tracking_open_code", None)
        opened = None
    case = store.case(opened) if opened else None
    if not case:
        if opened:
            st.session_state.pop("tracking_open_code", None)
            st.info("This report is no longer available.")
        if st.button("Open my report / প্রতিবেদন দেখুন", type="primary", key="open_tracking_report"):
            if code and store.case(code):
                st.session_state["tracking_open_code"] = code
                st.rerun()
            else:
                st.warning("No report matches that code. Check the receipt; deleted reports cannot be reopened.")
        return
    st.button("Add a follow-up survey / আবার পর্যবেক্ষণ দিন", type="primary", on_click=open_followup, args=(opened,))
    render_history(case)
