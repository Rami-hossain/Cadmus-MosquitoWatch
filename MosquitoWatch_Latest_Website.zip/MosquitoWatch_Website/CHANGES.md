# Changes from the supplied project

- Repaired Python selection and exit-code handling in the Windows launcher. Added a private-environment bootstrap, read-only checks, model-integrity verification, and version checks on every startup.
- Pinned direct packages and included complete Windows Python 3.12/3.13 dependency locks.
- Replaced partial weather summaries with validated 72-hour consecutive windows in UTC; future samples cannot replace missing history. Displayed Bangladesh times and identified weather as model data.
- Restricted geocoding to Bangladesh, preferred exact place names and district matches, and exposed ambiguous matches as place-name choices.
- Added bounded decoding, EXIF rotation, content-format checks, per-image errors, and pixel-identical duplicate handling.
- Excluded unusable images from scoring and marked incomplete image coverage as provisional.
- Rejected missing/invalid weather and invalid counts rather than assigning a misleading Low priority.
- Preserved reports across reruns and marked them stale after image, location, or selected place changes.
- Refined the original dark/teal interface for desktop and mobile. Removed developer settings, numerical internal scores, and public exception details. Used inspection-priority wording and visible field-verification context.
- Displayed Bangla priority statements, reasons, and recommendations. Added UTF-8 text reports and annotated-image downloads.
- Used readable object labels without confidence values on annotations, and protected the shared model predictor from concurrent inference calls.
- Disabled Streamlit telemetry and source watching in the local packaged app; bound the server to localhost.
- Preserved the original evaluation evidence, documented its limits, and added a repeatable evaluation entry point for a future labelled dataset.
- Added 54 regression checks covering the repaired behaviors.

The original model, class mapping, scoring weights, and priority thresholds are retained. The raw class name `cocunut_shell` remains compatible with the model. Detection accuracy, scientific calibration, and cross-view object identity still need evidence; see `VALIDATION.md`.

## Windows extraction-path repair

The reported PyTorch installation failed after extraction added another folder level. The launcher now checks the full path budget for the longest file in the pinned Windows torch package. Long project paths use a short, project-specific environment under Documents/MosquitoWatch/venvs; short paths retain their local .venv. This avoids Windows Store LocalAppData redirection as well as the original path limit. No registry change, administrator setting, model edit, or deletion of an existing environment is needed. run.bat --print-python identifies the environment for diagnostics.

The Windows launcher no longer pauses for a keypress on any exit path. It runs setup/startup automatically and returns the original failure exit code if a command fails.

## Site reporting edition — 16 October 2026

Added bilingual public reporting, optional browser-location requests at upload, EXIF GPS/date hints, confirmed OpenStreetMap pins, private tracking codes, and persistent local report histories. Added password-protected admin setup/login, map and inspection queue, filters, photo comparison, rainfall intervals, status notes, reopening, and confirmed deletion. Weather now follows the confirmed survey date. A separately explained prototype rule raises priority once when distinct-photo wet observations are at least three days apart; dry observations reset the period. Model weights and base scoring are unchanged. No new Python packages were required; Leaflet 1.9.4 is bundled with its license. Private runtime data is excluded from distribution.

## Minimal interface — 18 October 2026

Replaced the opening target icon with a mosquito mark and browser favicon. Changed the interface to a light navy/coral theme inspired by the supplied reference. Reduced repeated guidance on the first screen and grouped supporting information into collapsed sections while retaining all reporting controls and safety/privacy details.

## Requested page fixes — 18 October 2026

Report a site now displays a readable area name for the selected device/photo/map position. Photon reverse lookup uses rounded coordinates, cached responses, an identifying User-Agent, and paced cache misses. The exact selected pin is retained separately and is revealed with View on map. Names can be corrected manually; failed lookup retains the pin and offers retry. No default Dhaka position is presented as a detected upload location. Area-name source attribution and external-service disclosure are retained.

The native upload box places drag/drop instructions above Browse files and the file-size limit below it. Photo guidance has been removed. Water observations, survey date/time, and notes have their own permanently visible bordered section. A single Analyze Area action follows the observations on all screen sizes.

Track a report now opens with Follow the same site, the private-code explanation, tracking-code input, and Open my report. Report content appears only after a valid lookup. The unrelated hero and footer sections are removed from this landing page.

The navigation and sign-in page display Admin Access. Login supports an admin code plus password, stored as separate salted PBKDF2 hashes. Failed-code attempts use the same lockout as failed passwords. Local credential reconfiguration revokes existing sessions and preserves reports. The owner explicitly requested short demo credentials for the localhost copy; they were configured only in private runtime databases, with a stated weak-password caveat. No owner credential values or runtime databases are distributed. New installations retain the ordinary setup flow and password-length requirement.

Free area-name lookup uses the Photon public demo API at modest interactive volume with caching; availability is not guaranteed. Source/API terms: https://github.com/komoot/photon and https://github.com/komoot/photon/blob/master/docs/api-v1.md . MOSQUITOWATCH_REVERSE_URL can select a compatible self-hosted endpoint for a later deployment. This is not an IP geolocation service; camera coordinates and the current device position remain distinct sources.


## Compact photo upload — 18 October 2026

Reduced upload spacing and placed the native file list and photo count inside the gray upload box. Removed the upload-location checkbox, area-search button, device-location button, map toggle, and map-centre button from the public page. Photo GPS now fills the site pin and readable area automatically. Screenshots without GPS show a clear manual map-click fallback. Changing batches cannot reuse stale photo/device positions or old map events. About this tool & privacy is available on both public pages. The trained model and admin credentials are unchanged.


Follow-up adjustment: removed the site-pin confirmation checkbox and split upload details from the photo-count panel. All 14 affected public/tracking interface tests passed; GPS/map pin validation remains required.


Automatic location correction: photo GPS is preferred; uploads without GPS automatically request browser geolocation permission, with no checkbox or location toolbar. Device results fill the area/map and are labelled as upload locations, not capture coordinates. Denied and successful location responses were exercised in the JavaScript harness; Streamlit tests verify the request and area update. Real device permission was not accepted by the agent.


## Balanced upload/map and analysis tables — 18 October 2026

The public upload panel and map now share equal column widths and a 240px height. The file list scrolls inside the upload panel. Object counts and survey-date weather render in separate accessible tables side by side, stacking on narrow screens. Missing weather uses Unavailable rather than zero. The device-location map caption now correctly describes the upload position. Model weights, automatic location and risk rules are unchanged.


Tracking page: removed the redundant Open my report button. Entering the private code and pressing Enter displays the existing report and follow-up option below. Empty or invalid input cannot keep showing a previously opened report.


Tracking clarification: Open my report is available for the initial lookup, then disappears after a successful open. Follow-up and report history remain. Changing the code clears the open report and restores the lookup button. All 9 reporting-interface tests passed, including click-to-open, hidden button after open/rerun, and follow-up routing. This supersedes the earlier automatic-lookup behavior.


## Admin overview and site cards — 18 October 2026

The first admin view now shows Open sites, Awaiting first visit and Resolved, followed by a priority-count table for all workflow statuses. Numbered cards show each location, effective priority, status and latest observation summary. View site opens the complete history, map, photos and inspection editor; Back to sites returns to the filtered cards. Admins can record comments, change status and set or clear an admin priority. Admin priorities are stored separately from automated survey assessments and included in the inspection audit trail. Existing records are preserved by an additive admin_priorities table. Priority counts and filters use the admin value where set.


## Compact admin priority counts — 18 October 2026

Replaced the workflow-by-priority table with a single High/Medium/Low/Unassigned count row. Totals cover all sites. Admin filters and inspection status/priority controls now use native HTML select dropdowns: predefined options only, with no text-entry cursor or searchable input. No new Python dependencies were added.


Focused admin site details: View site now opens a separate view containing only the selected site title/ID, Back to sites, admin editing controls and the site history/map/photos. Admin Access heading, sign-out, dashboard caption, global status totals, priority totals and overview filters are shown only on the overview. Authentication is still checked before any site details render.


Admin deletion control: a bright red Delete button now appears at the end of each admin site-detail page. Clicking it deletes the selected site and its saved observations/photos, inspection events and priority override, then returns to the site list with a success message. The previous expander and confirmation checkbox are removed. Server-side admin authorization and SQLite cascading deletion remain in force.


Admin map: View sites on map appears directly below Sites to review and stays collapsed until the admin opens it. The map includes every reported site, including resolved reports, regardless of card filters. Selecting any marker opens that site. The map remains available when the current card filters match no sites.


Removed About this tool & privacy from Report a site. It remains on Track a report; the brief field-inspection caption remains on the reporting page. All 12 reporting-interface checks passed.


Automatic area-name repair: successfully resolved place names are retained separately from the text widget and tied to the exact selected pin. A blank form update restores the cached name without another request. Moving the pin clears the old name; failed lookup retries on Analyze Area or a later form rerun, with bounded retry timing. A temporary lookup outage no longer asks the uploader to type the site name. The precise pin is preserved. No new service or model changes were introduced.


Submission completion: a Done button follows Save tracking receipt after a report is saved. Done shows a centered mosquito logo, MosquitoWatch name and Thank you for submitting a report message. It does not resubmit the report. Report another site clears the form state for a fresh report; saved database records are retained.


History entry styling: uploader/drone report observations use red circles and a Report submission label. Admin inspection updates use green circles, bold text and a light green background. Automatic reopening after a new water-present report remains labelled Report update with a red circle, rather than being attributed to an admin. Notes are HTML-escaped and preserve line breaks. This is a presentation change; stored reports and assessments are unchanged.


Report submissions now match the admin update card style, using a red circle, light red background and bold dark red text. Admin entries retain their green styling. This changes presentation only.
