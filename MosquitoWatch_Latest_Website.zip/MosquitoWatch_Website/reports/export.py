from services.detector import DISPLAY_NAMES
from reports.bangla_report import build_bangla_report


def build_text_report(result: dict) -> str:
    risk = dict(result["risk"])
    followup = result.get("followup")
    if followup and followup.get("raised"):
        risk.update(risk_level=followup["level"], followup_raised=True)
    bn = build_bangla_report(result["counts"], result["weather"], risk, result["location"]["display_name"])
    lines = ["MosquitoWatch AI — Survey inspection report", result["location"]["display_name"],
             f"Analysis time: {result['created_at']}",
             f"Inspection priority: {risk['risk_level'].title() if risk['status'] == 'OK' else 'Unable to assess'}",
             bn["headline"], bn["summary"],
             f"Usable images analyzed: {result['usable_images']} of {result['submitted_images']}"]
    if result["partial_coverage"]:
        lines.append("Provisional result: some images were excluded or failed. Re-survey missing coverage.")
    if result.get("observed_at"):
        lines += [f'Survey observed at: {result["observed_at"]}', f'Water reported by uploader: {result.get("water", "Unsure")}',
                  "This assessment describes the survey date, not necessarily current conditions."]
    if followup and followup.get("raised"):
        lines += [f'Follow-up inspection priority: {followup["level"].title()} (object/weather base: {followup["base_level"].title()})',
                  "Prototype rule: raised once for water reported on distinct-photo visits at least 3 days apart.",
                  "Continuous water presence is unconfirmed. This is not a confirmed water-age estimate."]
    lines += ["", "Detections in usable images (may repeat across overlapping views)"]
    lines += [f"{DISPLAY_NAMES[k]}: {v}" for k, v in result["counts"].items()]
    weather = result.get("weather")
    if weather:
        lines += ["", "Previous 72 hours — Open-Meteo weather model data",
                  f"Window: {weather['start_time']} to {weather['end_time']} (end excluded)",
                  f"Precipitation: {weather['total_rainfall_mm']} mm",
                  f"Average temperature: {weather['avg_temperature_c']} C",
                  f"Average humidity: {weather['avg_humidity_percent']}%"]
    else:
        lines.append("Complete recent weather unavailable; no inspection priority assigned.")
    lines += ["", "কারণ"] + [f"- {s}" for s in bn["reasons"]]
    lines += ["", "করণীয়"] + [f"- {s}" for s in bn["actions"]]
    for image in result["images"]:
        lines += ["", f"Image: {image['name']} — {image['status']}"] + [f"- {s}" for s in image["issues"]]
    lines += ["", "This tool identifies potential breeding-risk objects. It does not directly detect mosquitoes, larvae, or dengue. Field inspection is required.",
              "Prototype inspection rules are not calibrated probabilities. Counts are not normalized by surveyed area.",
              "Weather source: https://open-meteo.com/"]
    return "\n".join(lines)
