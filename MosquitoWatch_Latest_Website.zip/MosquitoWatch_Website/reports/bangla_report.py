from __future__ import annotations
from typing import Any

BN_NAMES = {"cocunut_shell": "নারিকেলের খোসা", "drum": "ড্রাম", "other_containers": "অন্যান্য পাত্র", "tire": "টায়ার", "water_tank": "পানির ট্যাংক"}


def build_bangla_report(counts: dict[str, int], weather: dict[str, Any] | None, risk: dict[str, Any], area_name: str = "নির্বাচিত এলাকা") -> dict[str, Any]:
    if risk["status"] != "OK":
        missing_images = risk.get("cause") == "images"
        return {
            "headline": "মূল্যায়ন অসম্পূর্ণ",
            "summary": "পরিদর্শনের অগ্রাধিকার নির্ধারণের জন্য ব্যবহারযোগ্য ছবি ও সম্পূর্ণ আবহাওয়ার তথ্য প্রয়োজন।",
            "reasons": ["কোনো ব্যবহারযোগ্য ছবি বিশ্লেষণ করা যায়নি।" if missing_images else "আগের ৭২ ঘণ্টার সম্পূর্ণ আবহাওয়ার তথ্য পাওয়া যায়নি।"],
            "actions": ["পরিষ্কার ও পর্যাপ্ত আলোতে তোলা ছবি দিয়ে আবার বিশ্লেষণ করুন।" if missing_images else "ইন্টারনেট সংযোগ পরীক্ষা করে আবার Analyze Area চাপুন।", "প্রয়োজনে সরেজমিনে পাত্রে পানি জমে আছে কি না যাচাই করুন।"],
        }
    reasons = []
    found = [f"{BN_NAMES[k]} {int(counts.get(k, 0))}টি" for k in ("tire", "water_tank", "drum", "other_containers", "cocunut_shell") if counts.get(k, 0)]
    if found:
        reasons.append("ছবিতে সম্ভাব্য পানি জমার বস্তু শনাক্ত হয়েছে: " + ", ".join(found) + "।")
    else:
        reasons.append("ব্যবহারযোগ্য ছবিতে নির্ধারিত পাঁচ ধরনের বস্তু শনাক্ত হয়নি। এতে এলাকায় এসব বস্তু নেই বলে নিশ্চিত হওয়া যায় না।")
    rain = weather["total_rainfall_mm"]
    reasons.append(f"আবহাওয়ার মডেল অনুযায়ী আগের ৭২ ঘণ্টায় মোট বৃষ্টিপাত {rain:.1f} মিমি।")
    reasons.append(f"গড় তাপমাত্রা {weather['avg_temperature_c']:.1f}°C এবং গড় আর্দ্রতা {weather['avg_humidity_percent']:.0f}%।")
    if not found and risk["risk_level"] == "MEDIUM" and not risk.get("followup_raised"):
        reasons.append("এই অগ্রাধিকার আবহাওয়ার কারণে বেড়েছে; ছবিতে প্রজননস্থলের প্রমাণ পাওয়া যায়নি।")
    level = risk["risk_level"]
    if level == "HIGH":
        headline = "পরিদর্শনের উচ্চ অগ্রাধিকার"
        actions = ["চিহ্নিত স্থানগুলো অগ্রাধিকার দিয়ে সরেজমিনে পরিদর্শন করুন।", "পাত্র বা টায়ারে পানি জমে থাকলে তা অপসারণ করুন এবং ট্যাংকের ঢাকনা পরীক্ষা করুন।", "প্রয়োজনে প্রশিক্ষিত কর্মী দিয়ে লার্ভা পরীক্ষা ও ফলো-আপ জরিপ করুন।"]
    elif level == "MEDIUM":
        headline = "পরিদর্শনের মাঝারি অগ্রাধিকার"
        actions = ["চিহ্নিত বস্তু ও আশপাশের স্থান মাঠপর্যায়ে যাচাই করুন।", "পানি জমে থাকলে তা সরিয়ে ফেলুন; ব্যবহৃত পাত্র ঢেকে রাখুন।", "বৃষ্টির পরে আবার পর্যবেক্ষণ করুন।"]
    else:
        headline = "পরিদর্শনের কম অগ্রাধিকার"
        actions = ["নিয়মিত পর্যবেক্ষণ চালিয়ে যান।", "বৃষ্টির পরে পাত্র ও পানি জমার সম্ভাব্য স্থান পরীক্ষা করুন।", "কম অগ্রাধিকার মানে মশার অনুপস্থিতি নিশ্চিত নয়।"]
    return {"headline": headline, "summary": "এটি ছবি ও সাম্প্রতিক আবহাওয়ার ভিত্তিতে প্রাথমিক পরিদর্শনের অগ্রাধিকার। মাঠপর্যায়ে যাচাই প্রয়োজন।", "reasons": reasons, "actions": actions}
