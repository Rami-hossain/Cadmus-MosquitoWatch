"""Supabase persistence reusing the local store's access and validation rules.

Postgres holds metadata and hashed credentials/tokens. Private Storage holds
compressed report payloads. Only authenticated server code receives credentials.
"""
from __future__ import annotations

from contextlib import contextmanager
import gzip
import hashlib
import io
import json
import logging
from pathlib import Path
import re
import secrets
from urllib.parse import urlsplit

import requests

from services.store import ReportStore, decode

LOGGER = logging.getLogger(__name__)
BUCKET = 'mosquitowatch-private'
MAX_PAYLOAD = 60 * 1024 * 1024
MAX_OBJECT = 45 * 1024 * 1024
OBJECT_PATH = re.compile(r'reports/[a-f0-9]{24}/[a-f0-9]{64}\.json\.gz\Z')


def startup_diagnostic(error):
    """Return only fixed labels; never disclose exception text or settings."""
    message = str(error).lower()
    for fragment, label in (
        ('certificate verify failed', 'database_tls_certificate'),
        ('certificate verification failed', 'database_tls_certificate'),
        ('password authentication failed', 'database_password'),
        ('tenant or user not found', 'database_pooler_identity'),
        ('connection timeout', 'database_timeout'),
        ('timeout expired', 'database_timeout'),
        ('could not translate host', 'database_dns'),
        ('secret key', 'storage_key_configuration'),
        ('at least 12 characters', 'admin_credentials_configuration'),
        ('session pooler', 'database_url_configuration'),
        ('does not exist', 'database_schema'),
        ('unsupported startup parameter', 'database_startup_options'),
    ):
        if fragment in message:
            return label
    if isinstance(error, KeyError):
        return 'missing_deployment_setting'
    return 'storage_initialization'


class PrivatePayloads:
    def __init__(self, url, key):
        parsed = urlsplit(url)
        if (parsed.scheme != 'https' or not parsed.hostname or not parsed.hostname.endswith('.supabase.co')
                or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/')):
            raise ValueError('Use the HTTPS Supabase project URL from its settings.')
        if not key or len(key) < 40 or not key.startswith(('sb_secret_', 'eyJ')):
            raise ValueError('Configure the server-only Supabase secret key.')
        self.url = url.rstrip('/')
        self.headers = {'apikey': key}
        # Modern secret keys are not JWTs. Legacy service-role JWTs remain
        # compatible, but new projects should use sb_secret_ on apikey only.
        if key.startswith('eyJ'):
            self.headers['Authorization'] = 'Bearer ' + key

    def _request(self, method, path, **kwargs):
        try:
            response = requests.request(method, self.url + '/storage/v1/' + path,
                                        headers={**self.headers, **kwargs.pop('headers', {})},
                                        timeout=kwargs.pop('timeout', (5, 60)), allow_redirects=False, **kwargs)
        except requests.RequestException:
            raise RuntimeError('Private photo storage is unavailable. Please retry.') from None
        if not response.ok:
            response.close()
            raise RuntimeError('Private photo storage did not complete the request. Check deployment settings and quota.')
        return response

    @staticmethod
    def check_path(path):
        if not isinstance(path, str) or not OBJECT_PATH.fullmatch(path):
            raise ValueError('Invalid private report reference.')

    def upload(self, path, data):
        self.check_path(path)
        if len(data) > MAX_OBJECT:
            raise ValueError('This report is too large to save. Submit fewer photos.')
        self._request('POST', 'object/' + BUCKET + '/' + path, data=data,
                      headers={'Content-Type': 'application/gzip', 'x-upsert': 'false'}).close()

    def download(self, path):
        self.check_path(path)
        # Stream the body with a hard cap even if the origin omits Content-Length.
        with self._request('GET', 'object/authenticated/' + BUCKET + '/' + path, stream=True) as response:
            parts, size = [], 0
            for part in response.iter_content(64 * 1024):
                size += len(part)
                if size > MAX_OBJECT:
                    raise ValueError('Stored report exceeds the supported size.')
                parts.append(part)
        with gzip.GzipFile(fileobj=io.BytesIO(b''.join(parts))) as source:
            raw = source.read(MAX_PAYLOAD + 1)
        if len(raw) > MAX_PAYLOAD:
            raise ValueError('Stored report exceeds the supported size.')
        if hashlib.sha256(raw).hexdigest() != path.split('/')[-1].split('.')[0]:
            raise ValueError('Stored report integrity check failed.')
        return json.loads(raw, object_hook=decode)

    def remove(self, path):
        self.check_path(path)
        self._request('DELETE', 'object/' + BUCKET, json={'prefixes': [path]}, timeout=(5, 15)).close()


class Row(dict):
    """Preserve SQLite Row's named and positional access for shared store logic."""
    def __getitem__(self, key):
        return tuple(self.values())[key] if isinstance(key, int) else super().__getitem__(key)


class Cursor:
    def __init__(self, cursor):
        self.cursor = cursor

    def fetchone(self):
        value = self.cursor.fetchone()
        return Row(value) if value is not None else None

    def fetchall(self):
        return [Row(row) for row in self.cursor.fetchall()]

    def __iter__(self):
        return (Row(row) for row in self.cursor)


def postgres_sql(query):
    """Translate only the fixed SQL emitted by ReportStore, never user input."""
    if query == 'BEGIN IMMEDIATE':
        return 'SELECT pg_advisory_xact_lock(491744201)'
    query = query.replace("json_remove(result,'$.images')", "((result::jsonb - 'images')::text)")
    if query.startswith('INSERT OR REPLACE INTO config VALUES'):
        query = query.replace('INSERT OR REPLACE', 'INSERT') + ' ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value'
    elif query.startswith('INSERT OR REPLACE INTO admin_priorities VALUES'):
        query = query.replace('INSERT OR REPLACE', 'INSERT') + ' ON CONFLICT (site_id) DO UPDATE SET priority=EXCLUDED.priority,updated_at=EXCLUDED.updated_at'
    return query.replace('?', '%s')


class Database:
    def __init__(self, store, db):
        self.store, self.db, self.deleted = store, db, False

    def execute(self, query, parameters=()):
        parameters = tuple(parameters)
        if query.startswith('INSERT INTO observations VALUES'):
            # Validation and duplicate checks in ReportStore run before this point.
            raw = parameters[6].encode('utf-8')
            compressed = gzip.compress(raw)
            if len(compressed) > MAX_OBJECT:
                raise ValueError('This report is too large to save. Submit fewer photos.')
            path = 'reports/' + parameters[0] + '/' + hashlib.sha256(raw).hexdigest() + '.json.gz'
            # Commit a reservation before upload. A rollback/crash leaves a queued
            # orphan that cleanup can safely remove after 24 hours.
            with self.store.raw_connection() as reservation:
                reservation.execute('INSERT INTO cloud_files(path) VALUES (%s)', (path,))
            self.store.payloads.upload(path, compressed)
            metadata = json.loads(raw)
            metadata.pop('images', None)
            metadata['_cloud_payload'] = path
            parameters = (*parameters[:6], json.dumps(metadata, allow_nan=False), *parameters[7:])
            cursor = self.db.execute(postgres_sql(query), parameters)
            self.db.execute('UPDATE cloud_files SET site_id=%s WHERE path=%s', (parameters[1], path))
            return Cursor(cursor)
        if query == 'DELETE FROM sites WHERE id=?':
            # Already authorized by shared delete_site. FK keeps cleanup rows.
            self.db.execute('UPDATE cloud_files SET cleanup_after=CURRENT_TIMESTAMP WHERE site_id=%s', parameters)
            self.deleted = True
        return Cursor(self.db.execute(postgres_sql(query), parameters))


class CloudReportStore(ReportStore):
    cloud = True

    def __init__(self, settings):
        from psycopg.conninfo import conninfo_to_dict
        values = conninfo_to_dict(settings['database_url'])
        host = values.get('host', '')
        if not host.endswith('.pooler.supabase.com') or values.get('port', '5432') != '5432':
            raise ValueError('Use Supabase Connect → Session pooler (port 5432).')
        self.connection_values = {key: values[key] for key in ('host', 'port', 'user', 'password', 'dbname') if key in values}
        if settings.get('database_password'):
            self.connection_values['password'] = settings['database_password']
        self.payloads = PrivatePayloads(settings['url'], settings.get('secret_key') or settings.get('service_role_key'))
        self.directory = Path('.local')  # compatibility only; no file is read/written
        with self.raw_connection() as db:
            db.execute('SELECT 1 FROM sites LIMIT 1')  # fail closed if migration is missing
        # First-time cloud setup can only use deployment secrets, never a public form.
        if not self.configured():
            access_code, password = settings.get('admin_code', ''), settings.get('admin_password', '')
            if not 4 <= len(access_code) <= 128 or not 12 <= len(password) <= 200:
                raise ValueError('Set a cloud admin code and a password of at least 12 characters in deployment secrets.')
            from services.store import credential_hash
            with self.connection() as db:
                db.execute('BEGIN IMMEDIATE')
                if not db.execute("SELECT 1 FROM config WHERE key='password'").fetchone():
                    db.execute("INSERT INTO config VALUES ('password',?)", (credential_hash(password),))
                    db.execute("INSERT INTO config VALUES ('access_code',?)", (credential_hash(access_code),))
        self.cleanup()

    @contextmanager
    def raw_connection(self):
        import psycopg
        from psycopg.rows import dict_row
        # Explicit verified TLS and fixed options override any DSN options.
        with psycopg.connect(**self.connection_values, connect_timeout=10,
                             sslmode='verify-full', sslrootcert=str(Path(__file__).resolve().parents[1] / 'deploy/supabase-ca.crt'),
                             prepare_threshold=None, row_factory=dict_row) as db:
            # Supavisor may discard libpq startup options. Set these inside
            # every transaction so queries always use the private app schema.
            db.execute('SET LOCAL search_path TO mosquitowatch, pg_catalog')
            db.execute("SET LOCAL statement_timeout TO '20s'")
            db.execute("SET LOCAL idle_in_transaction_session_timeout TO '120s'")
            yield db

    @contextmanager
    def connection(self):
        with self.raw_connection() as db:
            wrapper = Database(self, db)
            yield wrapper
        if wrapper.deleted:
            self.cleanup()

    def setup_admin(self, *args, **kwargs):
        raise PermissionError('Cloud admin access is configured through deployment secrets.')

    def set_local_admin(self, *args, **kwargs):
        raise PermissionError('Local credential changes are unavailable in the cloud store.')

    def _case(self, db, site, include_images=True):
        value = super()._case(db, site, include_images=include_images)
        if value and include_images:
            for observation in value['observations']:
                path = observation['result'].get('_cloud_payload')
                if path:
                    observation['result'] = self.payloads.download(path)
        return value

    def cleanup(self):
        """Retry queued object deletion without turning committed saves into failures."""
        try:
            with self.raw_connection() as db:
                rows = db.execute('SELECT path FROM cloud_files WHERE site_id IS NULL AND cleanup_after<=CURRENT_TIMESTAMP LIMIT 3').fetchall()
                for row in rows:
                    self.payloads.remove(row['path'])
                    db.execute('DELETE FROM cloud_files WHERE path=%s AND site_id IS NULL', (row['path'],))
        except Exception:
            # Keep durable queue entries for retry on startup or next admin visit.
            # Do not log connection strings, keys, response bodies or photo paths.
            LOGGER.warning('Private photo cleanup is pending; check cloud storage connectivity and quota.')

    def summaries(self, admin_token):
        rows = super().summaries(admin_token)
        self.cleanup()
        return rows
