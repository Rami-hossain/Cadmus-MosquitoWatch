"""Follow-up decisions use reported observations, never inferred water duration."""
from datetime import datetime

LEVELS = ("LOW", "MEDIUM", "HIGH")


def followup_priority(observations: list[dict]) -> dict:
    ordered = sorted(observations, key=lambda item: datetime.fromisoformat(item["observed_at"]))
    if not ordered:
        return {"level": None, "base_level": None, "raised": False, "span_days": 0, "wet_visits": 0}
    latest = ordered[-1]
    risk = latest["result"].get("risk", {})
    base = risk.get("risk_level") if risk.get("status") == "OK" else None
    wet, seen = [], set()
    for row in ordered:
        if row["water"] == "Dry":
            wet = []
            # Keep seen hashes: an old photo reused after a dry report isn't new evidence.
        fingerprints = set(row["result"].get("fingerprints", []))
        fresh = bool(fingerprints - seen)
        seen.update(fingerprints)
        if row["water"] == "Water present" and fresh:
            wet.append(datetime.fromisoformat(row["observed_at"]))
    span = (wet[-1] - wet[0]).total_seconds() / 86400 if len(wet) > 1 else 0
    eligible = (latest["water"] == "Water present" and len(wet) >= 2 and span >= 3
                and wet[-1] == datetime.fromisoformat(latest["observed_at"]))
    raised = eligible and base in LEVELS[:2]
    level = LEVELS[LEVELS.index(base) + 1] if raised else base
    return {"level": level, "base_level": base, "raised": raised,
            "span_days": round(span, 2), "span_hours":round(span * 24, 1), "wet_visits": len(wet),
            "reason": "Water reported on distinct-photo visits at least 3 days apart. Continuity unconfirmed. Prototype follow-up rule." if raised else
                      "Reported observations do not establish continuous water presence."}
