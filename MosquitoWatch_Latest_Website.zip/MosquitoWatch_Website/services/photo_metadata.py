"""Read optional EXIF hints without trusting them as verified site evidence."""
from datetime import datetime
import io
import math
import warnings

from PIL import Image

from services.analysis import MAX_FILE_BYTES, MAX_IMAGE_PIXELS
from services.weather import BD_TIME


def photo_metadata(data: bytes) -> dict:
    if not data or len(data) > MAX_FILE_BYTES:
        return {}
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as image:
                if image.width * image.height > MAX_IMAGE_PIXELS or image.format not in {"JPEG", "PNG", "WEBP"}:
                    return {}
                exif = image.getexif()
                result = {}
                date = exif.get(36867) or exif.get(306)
                if date:
                    # EXIF dates often lack an offset. Offer a hint, never silently adopt it.
                    try:
                        result["capture_time_hint"] = datetime.strptime(str(date), "%Y:%m:%d %H:%M:%S").replace(tzinfo=BD_TIME).isoformat()
                    except ValueError:
                        pass
                gps = exif.get_ifd(34853) if exif.get(34853) else {}
                if gps:
                    def degrees(key, ref, negative):
                        parts = [float(v) for v in gps[key]]
                        if len(parts) != 3 or not (0 <= parts[1] < 60 and 0 <= parts[2] < 60):
                            raise ValueError
                        value = parts[0] + parts[1] / 60 + parts[2] / 3600
                        return -value if gps[ref] == negative else value
                    lat, lon = degrees(2, 1, "S"), degrees(4, 3, "W")
                    if math.isfinite(lat) and math.isfinite(lon) and 20.5 <= lat <= 26.7 and 88 <= lon <= 92.7:
                        result["latitude"], result["longitude"] = lat, lon
                return result
    except (ValueError, TypeError, KeyError, OSError, ZeroDivisionError, OverflowError,
            Image.DecompressionBombError, Image.DecompressionBombWarning):
        return {}
