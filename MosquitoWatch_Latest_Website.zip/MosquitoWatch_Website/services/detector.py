from __future__ import annotations
from collections import Counter
from functools import lru_cache
from pathlib import Path
from threading import RLock
from typing import Any
import cv2
import numpy as np
from PIL import Image

DISPLAY_NAMES = {
    "cocunut_shell": "Coconut shells", "drum": "Drums", "other_containers": "Other containers",
    "tire": "Tires", "water_tank": "Water tanks",
}
MODEL_LOCK = RLock()


@lru_cache(maxsize=1)
def load_model(model_path: str | Path):
    from ultralytics import YOLO
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError("The local model file is missing.")
    with MODEL_LOCK:
        model = YOLO(str(path))
        names = model.names.values() if isinstance(model.names, dict) else model.names
        if set(names) != set(DISPLAY_NAMES):
            raise ValueError("The local model does not have the expected five classes.")
    return model


def assess_image_quality(image: Image.Image) -> dict[str, Any]:
    gray = cv2.cvtColor(np.asarray(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
    blur_score = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    brightness = float(gray.mean())
    h, w = gray.shape
    issues = []
    if min(h, w) < 320:
        issues.append("Image is too small; use at least 320 pixels on each side.")
    if blur_score < 35:
        issues.append("Image may be blurry; take a sharper photo.")
    if brightness < 35:
        issues.append("Image is too dark; use a better-lit photo.")
    if brightness > 225:
        issues.append("Image is too bright; reduce exposure.")
    return {"usable": not issues, "issues": issues, "blur_score": round(blur_score, 1),
            "brightness": round(brightness, 1), "width": w, "height": h}


def detect_image(model, image: Image.Image, confidence: float = .30, iou: float = .60, image_size: int = 1024) -> dict[str, Any]:
    bgr = cv2.cvtColor(np.asarray(image.convert("RGB")), cv2.COLOR_RGB2BGR)
    # A shared Ultralytics predictor has mutable state. Serialize inference.
    with MODEL_LOCK:
        result = model.predict(source=bgr, conf=float(confidence), iou=float(iou), imgsz=int(image_size), verbose=False)[0]
        names = dict(enumerate(result.names)) if isinstance(result.names, list) else result.names
        counts = Counter({name: 0 for name in DISPLAY_NAMES})
        detections = []
        if result.boxes is not None:
            for cid, conf, box in zip(result.boxes.cls.detach().cpu().tolist(), result.boxes.conf.detach().cpu().tolist(), result.boxes.xyxy.detach().cpu().tolist()):
                raw_name = str(names[int(cid)])
                if raw_name not in DISPLAY_NAMES:
                    raise ValueError("Unexpected detector class.")
                counts[raw_name] += 1
                detections.append({"class_name": raw_name, "confidence": float(conf), "xyxy": box})
        # Reassign only this result's labels, leaving model class names intact.
        result.names = {cid: DISPLAY_NAMES[name] for cid, name in names.items()}
        annotated_bgr = result.plot(conf=False, labels=True)
        annotated = cv2.cvtColor(annotated_bgr, cv2.COLOR_BGR2RGB)
    return {"counts": dict(counts), "detections": detections, "annotated_rgb": annotated,
            "quality": assess_image_quality(image)}
