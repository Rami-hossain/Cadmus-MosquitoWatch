"""Batch analysis independent of Streamlit, with explicit per-image outcomes."""
from __future__ import annotations

import hashlib
import io
import logging
import warnings
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from PIL import Image, ImageOps, UnidentifiedImageError

from risk.risk_engine import calculate_risk
from services.detector import DISPLAY_NAMES, assess_image_quality, detect_image

LOGGER = logging.getLogger(__name__)
MAX_IMAGES = 10
MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_BATCH_BYTES = 100 * 1024 * 1024
MAX_IMAGE_PIXELS = 32_000_000


@dataclass(frozen=True)
class SurveyImage:
    name: str
    data: bytes


def input_signature(uploads: list[SurveyImage], area: str) -> str:
    digest = hashlib.sha256(" ".join(area.split()).casefold().encode("utf-8"))
    for upload in uploads:
        digest.update(upload.name.encode("utf-8"))
        digest.update(hashlib.sha256(upload.data).digest())
    return digest.hexdigest()


def open_survey_image(data: bytes) -> Image.Image:
    if not data or len(data) > MAX_FILE_BYTES:
        raise ValueError("Use an image file smaller than 20 MB.")
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        with Image.open(io.BytesIO(data)) as source:
            if source.format not in {"JPEG", "PNG", "WEBP"}:
                raise ValueError("Use a JPG, PNG, or WebP image.")
            if source.width * source.height > MAX_IMAGE_PIXELS:
                raise ValueError("This image is too large to process. Resize it to 32 megapixels or less.")
            image = ImageOps.exif_transpose(source).convert("RGB")
            image.load()
    return image


def preview_png(image: Image.Image) -> bytes:
    copy = image.copy()
    # Pillow can otherwise carry EXIF GPS into PNG previews after RGB conversion.
    copy.info.clear()
    copy.thumbnail((1600, 1600))
    output = io.BytesIO()
    copy.save(output, format="PNG")
    return output.getvalue()


def analyze_images(uploads: list[SurveyImage], model, weather: dict | None, *, progress: Callable | None = None) -> dict:
    if not uploads or len(uploads) > MAX_IMAGES:
        raise ValueError("Upload between 1 and 10 images from one survey area.")
    if sum(len(u.data) for u in uploads) > MAX_BATCH_BYTES:
        raise ValueError("The combined upload is too large. Keep the survey below 100 MB.")
    counts = Counter({name: 0 for name in DISPLAY_NAMES})
    results, seen = [], {}
    for index, uploaded in enumerate(uploads):
        item = {"name": uploaded.name, "status": "failed", "issues": [], "counts": {}, "annotated_png": None}
        image = None
        try:
            image = open_survey_image(uploaded.data)
            fingerprint = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
            if fingerprint in seen:
                item.update(status="duplicate", issues=[f"Same image as {seen[fingerprint]}; counted once."])
            else:
                seen[fingerprint] = uploaded.name
                item["fingerprint"] = fingerprint
                quality = assess_image_quality(image)
                item["annotated_png"] = preview_png(image)
                item["original_png"] = item["annotated_png"]
                if not quality["usable"]:
                    item.update(status="excluded", issues=quality["issues"])
                else:
                    detection = detect_image(model, image)
                    annotated_png = preview_png(Image.fromarray(detection["annotated_rgb"]))
                    item.update(status="analyzed", counts=detection["counts"],
                                annotated_png=annotated_png)
                    counts.update(detection["counts"])
        except (ValueError, UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
            LOGGER.warning("Unreadable/oversized survey image %r", uploaded.name, exc_info=True)
            item["issues"] = ["This image could not be opened safely. Export it again as JPG or PNG, below 20 MB and 32 megapixels."]
        except Exception:
            LOGGER.exception("Inference failed for survey image %r", uploaded.name)
            item["issues"] = ["This image could not be analyzed. Retry it, or use another image."]
        finally:
            if image is not None:
                image.close()
        results.append(item)
        if progress:
            progress(index + 1, len(uploads))
    usable = sum(item["status"] == "analyzed" for item in results)
    risk = calculate_risk(dict(counts), weather or {}, all_images_unusable=usable == 0)
    return {"counts": dict(counts), "images": results, "risk": risk, "weather": weather,
            "fingerprints": [item["fingerprint"] for item in results if item["status"] == "analyzed"],
            "usable_images": usable, "submitted_images": len(uploads),
            "partial_coverage": any(item["status"] in {"failed", "excluded"} for item in results),
            "duplicate_images": sum(item["status"] == "duplicate" for item in results),
            "created_at": datetime.now(timezone.utc).isoformat()}
