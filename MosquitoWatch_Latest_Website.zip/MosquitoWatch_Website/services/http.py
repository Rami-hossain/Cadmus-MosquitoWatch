"""Small, bounded retries for public weather services."""
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


def get_json(url: str, params: dict, *, headers: dict | None = None) -> dict:
    retries = Retry(total=2, backoff_factor=0.4, status_forcelist=(429, 500, 502, 503, 504),
                    allowed_methods=("GET",), respect_retry_after_header=False)
    with requests.Session() as session:
        session.mount("https://", HTTPAdapter(max_retries=retries))
        response = session.get(url, params=params, headers=headers, timeout=(5, 15))
        response.raise_for_status()
        data = response.json()
    if not isinstance(data, dict) or data.get("error"):
        raise ValueError("The service returned an invalid response.")
    return data
