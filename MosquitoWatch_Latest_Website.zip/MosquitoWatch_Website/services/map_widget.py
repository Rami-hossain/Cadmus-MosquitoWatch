from pathlib import Path
import math

from streamlit.components.v1 import declare_component

_map = declare_component("mosquitowatch_map", path=str(Path(__file__).resolve().parents[1] / "assets/map_component"))


def valid_pin(value):
    try:
        return (isinstance(value, dict) and not isinstance(value["latitude"], bool)
                and not isinstance(value["longitude"], bool)
                and math.isfinite(float(value["latitude"])) and math.isfinite(float(value["longitude"]))
                and 20.5 <= float(value["latitude"]) <= 26.7 and 88 <= float(value["longitude"]) <= 92.7
                and value.get("source") in {"Map pin", "Device location", "Photo GPS", "Saved site"})
    except (KeyError, TypeError, ValueError):
        return False


def site_map(*, key, pin=None, markers=None, editable=False, request_id="", request_location=False, reset_id="", compact=False, controls=True, height=360):
    return _map(key=key, pin=pin, markers=markers or [], editable=editable,
                request_id=request_id, request_location=request_location, reset_id=reset_id, compact=compact, controls=controls, height=height, default=None)
