"""Native selection-only dropdown for the small, fixed admin option lists."""
from pathlib import Path
import streamlit as st
from streamlit.components.v1 import declare_component

_choice = declare_component("mosquitowatch_choice", path=str(Path(__file__).resolve().parents[1]/"assets/choice_component"))


def select_choice(label, options, *, index=0, format_func=str, key):
    options = list(options)
    initial = st.session_state.get(key, options[index])
    if initial not in options:
        initial = options[index]
    value = _choice(label=label, options=[{"value":v,"label":format_func(v)} for v in options],
                    value=initial, key=key, default=initial)
    return value if isinstance(value,str) and value in options else initial
