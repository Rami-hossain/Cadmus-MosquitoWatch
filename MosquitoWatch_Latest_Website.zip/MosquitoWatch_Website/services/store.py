"""Local SQLite reports. Public access uses unguessable bearer tracking codes.

Admin methods check server-side sessions. No credentials or reports belong in a release ZIP.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import math
from pathlib import Path
import secrets
import sqlite3

STATUSES = ("New", "Scheduled", "Inspected", "Resolved")
WATER_STATES = ("Water present", "Dry", "Unsure")
PRIORITIES = ("HIGH", "MEDIUM", "LOW")
_UNCHANGED = object()


def utcnow():
    return datetime.now(timezone.utc)


def token_hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


def credential_hash(value):
    salt=secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac("sha256",value.encode(),bytes.fromhex(salt),600_000).hex()
    return salt+":"+digest


def credential_matches(value,stored):
    salt,expected=stored.split(":")
    actual=hashlib.pbkdf2_hmac("sha256",value.encode(),bytes.fromhex(salt),600_000).hex()
    return hmac.compare_digest(actual,expected)


def encode(value):
    if isinstance(value, bytes):
        return {"__image_bytes__": base64.b64encode(value).decode("ascii")}
    raise TypeError("Unsupported report field")


def decode(value):
    if set(value) == {"__image_bytes__"}:
        return base64.b64decode(value["__image_bytes__"], validate=True)
    return value


class ReportStore:
    def __init__(self, directory: Path):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "reports.sqlite3"
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, expires TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS sites (id TEXT PRIMARY KEY, tracking TEXT UNIQUE NOT NULL,
                    area TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL,
                    location_source TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS observations (id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
                    observed_at TEXT NOT NULL, submitted_at TEXT NOT NULL, water TEXT NOT NULL,
                    notes TEXT NOT NULL, result TEXT NOT NULL, submission_key TEXT UNIQUE NOT NULL);
                CREATE TABLE IF NOT EXISTS events (site_id TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
                    created_at TEXT NOT NULL, status TEXT NOT NULL, note TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS admin_priorities (
                    site_id TEXT PRIMARY KEY REFERENCES sites(id) ON DELETE CASCADE,
                    priority TEXT NOT NULL CHECK(priority IN ('HIGH','MEDIUM','LOW')),
                    updated_at TEXT NOT NULL);
            """)
            configured = db.execute("SELECT 1 FROM config WHERE key='password'").fetchone()
        if not configured:
            # Local filesystem possession is required for first-time setup; never expose this code in the UI.
            try:
                with (self.directory / "admin_setup_code.txt").open("x", encoding="utf-8") as file:
                    file.write(secrets.token_urlsafe(24))
            except FileExistsError:
                pass

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA secure_delete=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def configured(self):
        with self.connection() as db:
            return db.execute("SELECT 1 FROM config WHERE key='password'").fetchone() is not None

    def setup_admin(self, code: str, password: str, access_code: str | None = None):
        if not 12 <= len(password) <= 200:
            raise ValueError("Choose an admin password of 12–200 characters.")
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM config WHERE key='password'").fetchone():
                raise PermissionError("Admin access is already configured.")
            path = self.directory / "admin_setup_code.txt"
            if not path.exists() or not hmac.compare_digest(code.strip(), path.read_text().strip()):
                raise PermissionError("The local setup code is incorrect.")
            db.execute("INSERT INTO config VALUES ('password', ?)", (credential_hash(password),))
            if access_code is not None:
                if not 4<=len(access_code)<=128:
                    raise ValueError("Choose an admin code of 4–128 characters.")
                db.execute("INSERT INTO config VALUES ('access_code',?)",(credential_hash(access_code),))
        path.unlink(missing_ok=True)

    def set_local_admin(self, access_code: str, password: str, *, allow_short_password=False):
        """Local filesystem administration only; never called by a public widget.

        A short-password override exists only for an explicitly requested localhost demo.
        Credentials are never bundled with source or ZIP defaults.
        """
        if not 4<=len(access_code)<=128 or not (5 if allow_short_password else 12)<=len(password)<=200:
            raise ValueError("Check the code and password length.")
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT OR REPLACE INTO config VALUES ('password',?)",(credential_hash(password),))
            db.execute("INSERT OR REPLACE INTO config VALUES ('access_code',?)",(credential_hash(access_code),))
            db.execute("DELETE FROM sessions")
            db.execute("DELETE FROM config WHERE key IN ('failures','locked_until')")
        (self.directory/"admin_setup_code.txt").unlink(missing_ok=True)

    def login(self, password: str, access_code: str | None = None):
        if len(password) > 200 or len(access_code or "")>128:
            return None
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            lock = db.execute("SELECT value FROM config WHERE key='locked_until'").fetchone()
            if lock and datetime.fromisoformat(lock[0]) > utcnow():
                return None
            row = db.execute("SELECT value FROM config WHERE key='password'").fetchone()
            if not row:
                return None
            code=db.execute("SELECT value FROM config WHERE key='access_code'").fetchone()
            password_ok=credential_matches(password,row[0])
            code_ok=credential_matches(access_code or "",code[0]) if code else True
            if not (password_ok and code_ok):
                fail = db.execute("SELECT value FROM config WHERE key='failures'").fetchone()
                failures = int(fail[0]) + 1 if fail else 1
                db.execute("INSERT OR REPLACE INTO config VALUES ('failures', ?)", (str(failures % 5),))
                if failures >= 5:
                    db.execute("INSERT OR REPLACE INTO config VALUES ('locked_until', ?)", ((utcnow() + timedelta(minutes=1)).isoformat(),))
                return None
            db.execute("DELETE FROM config WHERE key IN ('failures','locked_until')")
            db.execute("DELETE FROM sessions WHERE expires <= ?", (utcnow().isoformat(),))
            token = secrets.token_urlsafe(32)
            db.execute("INSERT INTO sessions VALUES (?,?)", (token_hash(token), (utcnow() + timedelta(hours=8)).isoformat()))
            return token

    def authorize(self, db, token):
        row = db.execute("SELECT expires FROM sessions WHERE token=?", (token_hash(token or ""),)).fetchone()
        if not row or datetime.fromisoformat(row[0]) <= utcnow():
            raise PermissionError("Sign in to the admin dashboard.")

    def logout(self, token):
        with self.connection() as db:
            db.execute("DELETE FROM sessions WHERE token=?", (token_hash(token or ""),))

    def submit(self, *, area, latitude, longitude, location_source, observed_at, water, notes, result,
               tracking_code=None, submission_key=None):
        lat, lon = float(latitude), float(longitude)
        observed = datetime.fromisoformat(observed_at)
        if (not area.strip() or len(area) > 160 or len(notes) > 2000 or water not in WATER_STATES
                or not math.isfinite(lat) or not math.isfinite(lon) or not (20.5 <= lat <= 26.7 and 88 <= lon <= 92.7)
                or observed.tzinfo is None or observed > utcnow() + timedelta(minutes=1)
                or observed.year < 2020 or location_source not in {"Map pin", "Photo GPS", "Device location", "Saved site"}):
            raise ValueError("Check the Bangladesh site, survey date, water observation, and report length.")
        # Never persist bearer codes or ephemeral form state inside the report JSON.
        persisted = {key: value for key, value in result.items() if key not in {"followup_code", "submission_key", "context", "signature"}}
        payload = json.dumps(persisted, default=encode, allow_nan=False)
        if len(payload.encode()) > 60 * 1024 * 1024:
            raise ValueError("This report is too large to save. Submit fewer photos.")
        tracking = tracking_code or secrets.token_urlsafe(24)
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM sites WHERE tracking=?", (token_hash(tracking),)).fetchone()
            if tracking_code and not existing:
                raise PermissionError("The tracking code is invalid.")
            site_id = existing["id"] if existing else secrets.token_hex(6).upper()
            key = submission_key or secrets.token_hex(24)
            duplicate = db.execute("SELECT site_id FROM observations WHERE submission_key=?", (key,)).fetchone()
            if duplicate:
                if duplicate["site_id"] != site_id:
                    raise ValueError("This submission was already saved.")
                return site_id, tracking
            if not existing:
                db.execute("INSERT INTO sites VALUES (?,?,?,?,?,?,?,?)", (site_id, token_hash(tracking), area.strip(), lat, lon, location_source, "New", utcnow().isoformat()))
            else:
                last = db.execute("SELECT MAX(observed_at) FROM observations WHERE site_id=?", (site_id,)).fetchone()[0]
                if existing["status"] == "Resolved" and water == "Water present" and (not last or observed.astimezone(timezone.utc).isoformat() > last):
                    db.execute("UPDATE sites SET status='New' WHERE id=?", (site_id,))
                    db.execute("INSERT INTO events VALUES (?,?,?,?)", (site_id, utcnow().isoformat(), "New", "Reopened after a newer water-present report."))
            db.execute("INSERT INTO observations VALUES (?,?,?,?,?,?,?,?)", (secrets.token_hex(12), site_id,
                       observed.astimezone(timezone.utc).isoformat(), utcnow().isoformat(), water, notes.strip(), payload, key))
        return site_id, tracking

    def _case(self, db, site, include_images=True):
        if not site:
            return None
        value = dict(site)
        value.pop("tracking", None)
        priority = db.execute("SELECT priority,updated_at FROM admin_priorities WHERE site_id=?", (site["id"],)).fetchone()
        value["admin_priority"] = priority["priority"] if priority else None
        value["admin_priority_updated_at"] = priority["updated_at"] if priority else None
        value["observations"] = []
        columns = "*" if include_images else "id,site_id,observed_at,submitted_at,water,notes,json_remove(result,'$.images') AS result"
        for row in db.execute(f"SELECT {columns} FROM observations WHERE site_id=? ORDER BY observed_at,submitted_at", (site["id"],)):
            obs = dict(row)
            obs.pop("submission_key", None)
            obs["result"] = json.loads(obs["result"], object_hook=decode)
            value["observations"].append(obs)
        value["events"] = [dict(row) for row in db.execute("SELECT * FROM events WHERE site_id=? ORDER BY created_at", (site["id"],))]
        return value

    def case(self, tracking_code):
        with self.connection() as db:
            return self._case(db, db.execute("SELECT * FROM sites WHERE tracking=?", (token_hash(tracking_code.strip()),)).fetchone())

    def sites(self, admin_token):
        with self.connection() as db:
            self.authorize(db, admin_token)
            return [dict(row) for row in db.execute("SELECT id,area,latitude,longitude,location_source,status,created_at FROM sites ORDER BY created_at DESC")]

    def admin_case(self, admin_token, site_id):
        with self.connection() as db:
            self.authorize(db, admin_token)
            return self._case(db, db.execute("SELECT * FROM sites WHERE id=?", (site_id,)).fetchone())

    def summaries(self, admin_token):
        with self.connection() as db:
            self.authorize(db, admin_token)
            sites = db.execute("SELECT * FROM sites ORDER BY created_at DESC").fetchall()
            return [self._case(db, site, include_images=False) for site in sites]

    def update_site(self, admin_token, site_id, status, note, *, priority=_UNCHANGED):
        if status not in STATUSES or len(note) > 2000 or (priority is not _UNCHANGED and priority is not None and priority not in PRIORITIES):
            raise ValueError("Invalid inspection update.")
        with self.connection() as db:
            self.authorize(db, admin_token)
            if not db.execute("SELECT 1 FROM sites WHERE id=?", (site_id,)).fetchone():
                raise ValueError("Report no longer exists.")
            db.execute("UPDATE sites SET status=? WHERE id=?", (status, site_id))
            when = utcnow().isoformat()
            audit_note = note.strip()
            if priority is not _UNCHANGED:
                if priority is None:
                    db.execute("DELETE FROM admin_priorities WHERE site_id=?", (site_id,))
                    message = "Using automated inspection priority."
                else:
                    db.execute("INSERT OR REPLACE INTO admin_priorities VALUES (?,?,?)", (site_id, priority, when))
                    message = "Admin inspection priority: " + priority.title() + "."
                audit_note = message + (" " + audit_note if audit_note else "")
            db.execute("INSERT INTO events VALUES (?,?,?,?)", (site_id, when, status, audit_note))

    def delete_site(self, admin_token, site_id):
        with self.connection() as db:
            self.authorize(db, admin_token)
            db.execute("DELETE FROM sites WHERE id=?", (site_id,))
