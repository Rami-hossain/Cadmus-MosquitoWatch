from __future__ import annotations
import math
import unicodedata
from functools import lru_cache
import os
import threading
import time
from typing import Any
from services.http import get_json

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
_REVERSE_LOCK = threading.Lock()
_LAST_REVERSE = 0.0


def _plain(value: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", value.casefold()) if not unicodedata.combining(c)).strip()


class LocationUnavailable(ValueError):
    pass


def find_locations(location_name: str) -> list[dict[str, Any]]:
    name = " ".join(str(location_name or "").split())
    if len(name) < 2 or len(name) > 160:
        raise LocationUnavailable("Enter a Bangladesh place name between 2 and 160 characters.")
    data = get_json(GEOCODING_URL, {"name": name, "count": 10, "countryCode": "BD", "language": "en", "format": "json"})
    locations, seen = [], set()
    for result in data.get("results") or []:
        if str(result.get("country_code", "")).upper() != "BD":
            continue
        try:
            lat, lon = float(result["latitude"]), float(result["longitude"])
        except (KeyError, TypeError, ValueError):
            continue
        if not (math.isfinite(lat) and math.isfinite(lon) and 20 <= lat <= 27 and 88 <= lon <= 93):
            continue
        identifier = str(result.get("id") or f"{lat},{lon}")
        if identifier in seen:
            continue
        seen.add(identifier)
        parts = [result.get("name"), result.get("admin2"), result.get("admin1"), "Bangladesh"]
        display = ", ".join(dict.fromkeys(str(p) for p in parts if p))
        locations.append({"id": identifier, "latitude": lat, "longitude": lon, "display_name": display,
                          "country": "Bangladesh", "timezone": "Asia/Dhaka", "name": str(result.get("name", "")),
                          "district": str(result.get("admin2", "")), "division": str(result.get("admin1", ""))})
    if not locations:
        raise LocationUnavailable("No matching Bangladesh location was found. Try the area with its district, or the nearest town.")
    terms = [_plain(part) for part in name.split(",")]
    exact = [place for place in locations if _plain(place["name"]) == terms[0]]
    if exact:
        locations = exact
    qualifiers = [q for q in terms[1:] if q not in {"bangladesh", "bd"}]
    if qualifiers:
        def match_score(place):
            return sum(2 if q in _plain(place["district"]) else 1 if q in _plain(place["division"]) else 0 for q in qualifiers)
        best = max(match_score(place) for place in locations)
        if best:
            locations = [place for place in locations if match_score(place) == best]
    return locations


def geocode_location(location_name: str) -> dict[str, Any]:
    results = find_locations(location_name)
    if len(results) != 1:
        raise LocationUnavailable("Several places match. Choose the survey area before analysis.")
    return results[0]


def reverse_location(latitude: float, longitude: float) -> str:
    """Area-level OSM label, independent of the exact survey pin. No IP inference."""
    lat,lon=float(latitude),float(longitude)
    if not (math.isfinite(lat) and math.isfinite(lon) and 20.5<=lat<=26.7 and 88<=lon<=92.7):
        raise LocationUnavailable("Choose a site inside Bangladesh.")
    # Area labels need no house-level precision. Full coordinates remain on the pin.
    return _reverse_area(round(lat,3),round(lon,3))


@lru_cache(maxsize=512)
def _reverse_area(latitude: float, longitude: float) -> str:
    global _LAST_REVERSE
    with _REVERSE_LOCK:
        pause=1.05-(time.monotonic()-_LAST_REVERSE)
        if pause>0:
            time.sleep(pause)
        _LAST_REVERSE=time.monotonic()
        data=get_json(os.environ.get("MOSQUITOWATCH_REVERSE_URL","https://photon.komoot.io/reverse"),
                      {"lat":latitude,"lon":longitude,"lang":"en","limit":1},
                      headers={"User-Agent":"MosquitoWatch/1.0 local survey demo"})
    features=data.get("features") or []
    for feature in features:
        place=feature.get("properties") or {}
        if str(place.get("countrycode","")).upper()!="BD":
            continue
        area=place.get("district") or place.get("locality") or place.get("name")
        city=place.get("city") or place.get("county")
        parts=[str(value).strip() for value in (area,city,"Bangladesh") if isinstance(value,str) and value.strip()]
        parts=list(dict.fromkeys(parts))
        if len(parts)>1:
            return ", ".join(parts)[:160]
    raise LocationUnavailable("Area name is unavailable. Enter the area name yourself; the pin is retained.")


def clear_reverse_cache():
    _reverse_area.cache_clear()
