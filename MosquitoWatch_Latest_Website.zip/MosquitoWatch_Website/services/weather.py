from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from statistics import mean
from typing import Any
from services.http import get_json

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
BD_TIME = timezone(timedelta(hours=6), "Asia/Dhaka")


class WeatherUnavailable(ValueError):
    """Missing, stale, or invalid weather must not produce a priority."""


def validate_weather(weather: dict[str, Any]) -> None:
    if weather.get("hours") != 72 or weather.get("coverage_complete") is not True:
        raise WeatherUnavailable("A complete 72-hour weather window is required.")
    for key, lower, upper in (("avg_temperature_c", -90, 65), ("avg_humidity_percent", 0, 100), ("total_rainfall_mm", 0, 10000)):
        try:
            value = float(weather[key])
        except (KeyError, TypeError, ValueError) as exc:
            raise WeatherUnavailable("Weather values are missing or invalid.") from exc
        if not math.isfinite(value) or not lower <= value <= upper:
            raise WeatherUnavailable("Weather values are outside valid bounds.")


def fetch_previous_72h_weather(latitude: float, longitude: float, *, now: datetime | None = None) -> dict[str, Any]:
    """Weather for 72 completed hourly intervals through the UTC hour boundary.

    Precipitation timestamps close the preceding hour; use (start, end] sample
    timestamps for [start, end) rainfall intervals. Temperature/humidity are
    instantaneous samples at those closing timestamps. Never use a future point.
    """
    lat, lon = float(latitude), float(longitude)
    if not (math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180):
        raise WeatherUnavailable("The survey location is invalid.")
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        raise ValueError("now must include a timezone")
    end = current.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    start = end - timedelta(hours=72)
    params = {
        "latitude": lat, "longitude": lon,
        "hourly": "temperature_2m,relative_humidity_2m,precipitation",
        "start_hour": (start + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M"),
        "end_hour": end.strftime("%Y-%m-%dT%H:%M"),
        "timezone": "GMT", "timeformat": "unixtime",
    }
    # Recent observations use forecast API history; older surveys use reanalysis.
    historical = end < datetime.now(timezone.utc) - timedelta(days=5)
    if historical:
        params.pop("start_hour")
        params.pop("end_hour")
        params.update(start_date=start.strftime("%Y-%m-%d"), end_date=end.strftime("%Y-%m-%d"))
    data = get_json(ARCHIVE_URL if historical else OPEN_METEO_URL, params)
    hourly = data.get("hourly") or {}
    arrays = [hourly.get(k) for k in ("time", "temperature_2m", "relative_humidity_2m", "precipitation")]
    if any(not isinstance(a, list) for a in arrays) or len({len(a) for a in arrays}) != 1:
        raise WeatherUnavailable("Weather records are incomplete.")
    expected = {int((start + timedelta(hours=i + 1)).timestamp()) for i in range(72)}
    rows = {}
    for timestamp, temp, humidity, rain in zip(*arrays):
        try:
            if isinstance(timestamp, bool) or int(timestamp) != float(timestamp):
                raise ValueError
            stamp = int(timestamp)
        except (TypeError, ValueError, OverflowError) as exc:
            raise WeatherUnavailable("Weather timestamps are invalid.") from exc
        if stamp not in expected:
            continue
        if stamp in rows:
            raise WeatherUnavailable("Weather contains duplicate hourly records.")
        values = []
        for value, lower, upper in ((temp, -90, 65), (humidity, 0, 100), (rain, 0, 1000)):
            try:
                number = float(value)
            except (TypeError, ValueError) as exc:
                raise WeatherUnavailable("An hourly weather value is missing.") from exc
            if not math.isfinite(number) or not lower <= number <= upper:
                raise WeatherUnavailable("An hourly weather value is invalid.")
            values.append(number)
        rows[stamp] = values
    if set(rows) != expected:
        raise WeatherUnavailable("The previous 72 hours are not fully available. Try again later.")
    temperatures, humidities, rainfalls = zip(*(rows[k] for k in sorted(rows)))
    weather = {
        "hours": 72, "coverage_complete": True,
        "start_time": start.astimezone(BD_TIME).isoformat(),
        "end_time": end.astimezone(BD_TIME).isoformat(),
        "last_sample_time": end.astimezone(BD_TIME).isoformat(),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "avg_temperature_c": round(mean(temperatures), 1),
        "min_temperature_c": round(min(temperatures), 1),
        "max_temperature_c": round(max(temperatures), 1),
        "avg_humidity_percent": round(mean(humidities), 1),
        "total_rainfall_mm": round(sum(rainfalls), 1),
        "rainy_hours": sum(r > 0 for r in rainfalls),
        "timezone": "Asia/Dhaka", "source": "Open-Meteo weather model data",
    }
    validate_weather(weather)
    return weather


def fetch_rainfall_history(latitude: float, longitude: float, start: datetime, end: datetime) -> list[dict]:
    """Complete rainfall intervals between visits, bounded to 90 days per request."""
    if start.tzinfo is None or end.tzinfo is None:
        raise WeatherUnavailable("Survey dates need a timezone.")
    start = start.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    end = end.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    hours = int((end - start).total_seconds() / 3600)
    if not 1 <= hours <= 90 * 24 or end > datetime.now(timezone.utc):
        raise WeatherUnavailable("Choose visits between one hour and 90 days apart.")
    if not (20.5 <= float(latitude) <= 26.7 and 88 <= float(longitude) <= 92.7):
        raise WeatherUnavailable("Choose a Bangladesh site.")
    params = {"latitude": latitude, "longitude": longitude, "hourly": "precipitation", "timezone": "GMT", "timeformat": "unixtime"}
    historical = start < datetime.now(timezone.utc) - timedelta(days=5)
    if historical:
        params.update(start_date=start.strftime("%Y-%m-%d"), end_date=end.strftime("%Y-%m-%d"))
    else:
        params.update(start_hour=(start + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M"), end_hour=end.strftime("%Y-%m-%dT%H:%M"))
    data = get_json(ARCHIVE_URL if historical else OPEN_METEO_URL, params).get("hourly") or {}
    stamps, rain = data.get("time"), data.get("precipitation")
    if not isinstance(stamps, list) or not isinstance(rain, list) or len(stamps) != len(rain):
        raise WeatherUnavailable("Rainfall history is incomplete.")
    expected = {int((start + timedelta(hours=i + 1)).timestamp()) for i in range(hours)}
    rows = {}
    for stamp, value in zip(stamps, rain):
        if isinstance(stamp, bool) or not isinstance(stamp, (int, float)) or not math.isfinite(stamp) or int(stamp) != stamp:
            raise WeatherUnavailable("Invalid rainfall timestamp.")
        if stamp not in expected:
            continue
        if stamp in rows or isinstance(value, bool) or value is None:
            raise WeatherUnavailable("Rainfall history is incomplete.")
        try:
            number = float(value)
        except (TypeError, ValueError) as exc:
            raise WeatherUnavailable("Rainfall history is incomplete.") from exc
        if not math.isfinite(number) or not 0 <= number <= 1000:
            raise WeatherUnavailable("Rainfall history is invalid.")
        rows[stamp] = number
    if set(rows) != expected:
        raise WeatherUnavailable("The full rainfall interval is not available yet. Retry later.")
    return [{"Hour ending": datetime.fromtimestamp(stamp, BD_TIME).isoformat(), "Rainfall (mm)": rows[stamp]} for stamp in sorted(rows)]
